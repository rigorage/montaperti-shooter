'use strict';
// No native blocking dialog: the renderer keeps simulating and sending packets.
class ExitGuard {
 constructor(send){this.send=send;this.serial=0;this.pending=null;this.allowed=false;}
 request(action){if(this.allowed||!['quit','menu'].includes(action))return;
  if(!this.pending)this.pending={id:++this.serial,action};this.send({...this.pending});}
 cancel(id){if(this.pending?.id!==id)return false;this.pending=null;return true;}
 finish(id){if(this.pending?.id!==id)return null;const action=this.pending.action;this.pending=null;if(action==='quit')this.allowed=true;return action;}
}
function protectedKey(input){const key=String(input.key||'').toLowerCase();
 if(input.type!=='keyDown')return null;
 if(key==='f11')return 'fullscreen';
 if((input.control||input.meta)&&['w','q'].includes(key)||input.alt&&key==='f4')return 'quit';
 if(key==='f5'||(input.control||input.meta)&&key==='r')return 'menu';
 if(input.alt&&['left','right','arrowleft','arrowright','home'].includes(key)||['browserback','browserforward','browserrefresh','browserhome'].includes(key))return 'block';
 return null;
}
module.exports={ExitGuard,protectedKey};
