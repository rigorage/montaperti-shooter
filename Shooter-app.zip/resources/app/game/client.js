'use strict';
// Caricato solo dal client Windows, dopo gli script del gioco (che restano identici alla versione browser).
// Chiedere conferma prima di chiudere o ricaricare durante una partita.
(()=>{
 const bridge=window.MontapertiClient;if(!bridge)return;
 const dialog=document.getElementById('clientExit'),title=document.getElementById('clientExitTitle'),message=document.getElementById('clientExitMessage'),stay=document.getElementById('clientStay'),exit=document.getElementById('clientExitConfirm');
 let pending=null,finishing=false;
 const inRun=()=>GAME.state==='wave'||GAME.state==='over'||GAME.state==='inter';
 function closeDialog(){if(dialog.open)dialog.close();KEYS.clear();}
 function cancel(){if(!pending||finishing)return;bridge.cancel(pending.id);pending=null;closeDialog();}
 function finish(){if(!pending||finishing)return;finishing=true;exit.disabled=stay.disabled=true;bridge.finish(pending.id);}
 function request(value){if(finishing)return;if(pending){stay.focus();return;}pending=value;
  if(!inRun()){finish();return;}
  if(GAME.state==='wave')pause();
  title.textContent=value.action==='quit'?'Vuoi chiudere Montaperti Shooter?':'Vuoi tornare al menu?';
  message.textContent='La partita in corso andrà persa.';
  exit.textContent=value.action==='quit'?'Esci dal gioco':'Torna al menu';
  KEYS.clear();dialog.showModal();stay.focus();}
 stay.onclick=cancel;exit.onclick=finish;dialog.addEventListener('cancel',e=>{e.preventDefault();cancel();});
 document.addEventListener('keydown',e=>{if(!dialog.open)return;e.stopImmediatePropagation();if(e.key==='Escape'){e.preventDefault();cancel();}},true);
 bridge.onExitRequest(request);bridge.ready();
})();
