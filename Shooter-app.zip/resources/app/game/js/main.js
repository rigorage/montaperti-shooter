'use strict';
// ===================== avvio, tastiera e ciclo del gioco =====================
// mode: 'solo' (da solo), 'host' (ospita e fa girare la partita), 'guest' (entra nella partita di un altro).
const GAME={state:'menu',mode:'solo',run:null,W:null,paused:false,acc:0,last:0,overT:0,jumpTo:0,lastChar:'firenze',lastDanger:0};
const KEYS=new Set();
function moveInput(){let x=0,y=0;
 if(KEYS.has('KeyA')||KEYS.has('ArrowLeft'))x--;if(KEYS.has('KeyD')||KEYS.has('ArrowRight'))x++;
 if(KEYS.has('KeyW')||KEYS.has('ArrowUp'))y--;if(KEYS.has('KeyS')||KEYS.has('ArrowDown'))y++;return {x,y};}

function toMenu(msg){if(netOn())netLeave();GAME.state='menu';GAME.mode='solo';GAME.W=null;GAME.run=null;GAME.jumpTo=0;KEYS.clear();resetFx();showMenu(startRun,msg);}
function startRun(charId,danger){GAME.mode='solo';GAME.run=newRun(charId,(Date.now()%2147480000)+1,danger);sfx('bell');startWave();}
function startWave(){startWaveWith(newWorld(GAME.run));}
function startWaveWith(W){GAME.W=W;GAME.state='wave';GAME.paused=false;GAME.acc=0;GAME.overT=0;resetFx();hideUI();waveBanner(GAME.run.wave);}
function waveBanner(w){showBanner('Ondata '+w,w===LAST_WAVE?'Arriva il Carroccio nero!':WAVES[w-1].g.some(g=>ENEMIES[g.e].elite)?'Un Capitano di ventura guida l\'attacco':null,'#ffd84a',1.6);}
// multigiocatore: chiamate da net.js
function netGameStart(charId,seed,danger){GAME.mode=NET.role;GAME.run=newRun(charId,seed,danger);sfx('bell');GAME.state='inter';showWaiting();}
function startGuestWave(){GAME.W=NET.view;GAME.state='wave';GAME.paused=false;GAME.overT=0;resetFx();hideUI();waveBanner(GAME.run.wave);}
function guestWaveOver(){overBanner(GAME.W);GAME.state='over';GAME.overT=0;}
function netAbort(msg){toMenu(msg);}

function overBanner(W){if(W.over==='dead')showBanner(W.net?'Siete caduti':'Sei caduto',null,'#ff6a4a',2);
 else showBanner(W.wave===LAST_WAVE?'Vittoria!':'Ondata superata!',W.bossDead?'Il Carroccio nero è distrutto':null,'#ffd84a',1.4);}
function afterWave(){const run=GAME.run,W=GAME.W;
 if(W.over==='dead'){GAME.state='end';const keep=netOn();showEnd(run,false,()=>toMenu());if(keep)netLeave();return;}
 if(GAME.mode==='host')netHostWaveDone();
 endWave(run);
 if(run.result==='win'){GAME.state='end';showEnd(run,true,()=>toMenu());if(netOn())netLeave();return;}
 if(GAME.jumpTo){run.wave=Math.max(run.wave,GAME.jumpTo-1);GAME.jumpTo=0;run.gold+=150;openShop(run);}
 GAME.state='inter';intermission();}
function intermission(){const run=GAME.run;
 if(run.levelsPending>0)showLevelUp(run,intermission);
 else if(run.cratesPending>0)showCrate(run,intermission);
 else showShop(run,goNextWave);}
function goNextWave(){if(GAME.state!=='inter'||UI.screen==='waiting')return;const run=GAME.run;nextWave(run);
 if(GAME.mode==='solo'){startWave();return;}
 showWaiting();
 if(GAME.mode==='host')netHostReady();else netGuestSendRun();}
function pause(){if(GAME.state!=='wave'||GAME.paused)return;
 if(GAME.mode!=='solo'){showNetMenu(()=>hideUI(),()=>toMenu());return;} // in compagnia il gioco non si ferma
 GAME.paused=true;showPause(GAME,resume,()=>{GAME.paused=false;toMenu();});}
function resume(){GAME.paused=false;GAME.last=performance.now();hideUI();}

addEventListener('keydown',e=>{
 if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Space'].includes(e.code)&&!(e.target&&e.target.tagName==='INPUT'))e.preventDefault();
 if(e.target&&e.target.tagName==='INPUT'){if(UI.keyHandler&&e.key==='Enter')UI.keyHandler(e);return;}
 if(e.code==='KeyM'){AUDIO.on=!AUDIO.on;return;}
 if(UI.keyHandler&&!e.repeat){UI.keyHandler(e);return;}
 if(e.key==='Escape')pause();
 KEYS.add(e.code);});
addEventListener('keyup',e=>KEYS.delete(e.code));
addEventListener('blur',()=>{KEYS.clear();if(GAME.mode==='solo')pause();});

function frame(ts){const dt=Math.min(.1,(ts-(GAME.last||ts))/1000);GAME.last=ts;
 const W=GAME.W,inp=UI.root&&UI.root.classList.contains('show')?{x:0,y:0}:moveInput();
 if(GAME.state==='wave'&&GAME.mode==='guest'){guestSendInput(inp);advanceView(W,dt,inp);}
 else if(GAME.state==='wave'&&!GAME.paused){GAME.acc+=dt;
  while(GAME.acc>=DT){step(W,GAME.mode==='host'?hostInputs(inp):inp);GAME.acc-=DT;if(W.over)break;}
  if(GAME.mode==='host'){hostCollectEvents(W);hostTick(dt);}
  if(W.over){GAME.state='over';GAME.overT=0;overBanner(W);}}
 else if(GAME.state==='over'){GAME.overT+=dt;if(GAME.mode==='host')hostTick(dt);
  if(GAME.overT>(W.over==='dead'?1.8:1.3))afterWave();}
 render(GAME.state==='menu'?null:W,dt);
 requestAnimationFrame(frame);}

addEventListener('load',()=>{initRender(document.getElementById('cv'));initUI();toMenu();requestAnimationFrame(frame);});
