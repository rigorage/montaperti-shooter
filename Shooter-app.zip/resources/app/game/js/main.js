'use strict';
// ===================== avvio, tastiera e ciclo del gioco =====================
const GAME={state:'menu',run:null,W:null,paused:false,acc:0,last:0,overT:0,jumpTo:0};
const KEYS=new Set();
function moveInput(){let x=0,y=0;
 if(KEYS.has('KeyA')||KEYS.has('ArrowLeft'))x--;if(KEYS.has('KeyD')||KEYS.has('ArrowRight'))x++;
 if(KEYS.has('KeyW')||KEYS.has('ArrowUp'))y--;if(KEYS.has('KeyS')||KEYS.has('ArrowDown'))y++;return {x,y};}

function toMenu(){GAME.state='menu';GAME.W=null;GAME.run=null;resetFx();showMenu(startRun);}
function startRun(charId,danger){GAME.run=newRun(charId,(Date.now()%2147480000)+1,danger);sfx('bell');startWave();}
function startWave(){GAME.W=newWorld(GAME.run);GAME.state='wave';GAME.paused=false;GAME.acc=0;GAME.overT=0;resetFx();hideUI();
 showBanner('Ondata '+GAME.run.wave,GAME.run.wave===LAST_WAVE?'Arriva il Carroccio nero!':WAVES[GAME.run.wave-1].g.some(g=>ENEMIES[g.e].elite)?'Un Capitano di ventura guida l\'attacco':null,'#ffd84a',1.6);}
function afterWave(){const run=GAME.run,W=GAME.W;
 if(W.over==='dead'){GAME.state='end';showEnd(run,false,toMenu);return;}
 endWave(run);
 if(run.result==='win'){GAME.state='end';showEnd(run,true,toMenu);return;}
 if(GAME.jumpTo){run.wave=Math.max(run.wave,GAME.jumpTo-1);GAME.jumpTo=0;run.gold+=150;openShop(run);}
 GAME.state='inter';intermission();}
function intermission(){const run=GAME.run;
 if(run.levelsPending>0)showLevelUp(run,intermission);
 else if(run.cratesPending>0)showCrate(run,intermission);
 else showShop(run,()=>{nextWave(run);startWave();});}
function pause(){if(GAME.state!=='wave'||GAME.paused)return;GAME.paused=true;showPause(GAME,resume,()=>{GAME.paused=false;toMenu();});}
function resume(){GAME.paused=false;GAME.last=performance.now();hideUI();}

addEventListener('keydown',e=>{
 if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Space'].includes(e.code))e.preventDefault();
 if(e.code==='KeyM'){AUDIO.on=!AUDIO.on;return;}
 if(UI.keyHandler&&!e.repeat){UI.keyHandler(e);return;}
 if(e.key==='Escape')pause();
 KEYS.add(e.code);});
addEventListener('keyup',e=>KEYS.delete(e.code));
addEventListener('blur',()=>{KEYS.clear();pause();});

function frame(ts){const dt=Math.min(.1,(ts-(GAME.last||ts))/1000);GAME.last=ts;
 const W=GAME.W;
 if(GAME.state==='wave'&&!GAME.paused){GAME.acc+=dt;const inp=moveInput();
  while(GAME.acc>=DT){step(W,inp);GAME.acc-=DT;if(W.over)break;}
  if(W.over){GAME.state='over';GAME.overT=0;
   if(W.over==='dead')showBanner('Sei caduto',null,'#ff6a4a',2);else showBanner(W.wave===LAST_WAVE?'Vittoria!':'Ondata superata!',W.bossDead?'Il Carroccio nero è distrutto':null,'#ffd84a',1.4);}}
 else if(GAME.state==='over'){GAME.overT+=dt;
  // a fine ondata i fiorini rimasti volano verso il giocatore (finiscono nella borsa)
  if(GAME.overT>(W.over==='dead'?1.8:1.3))afterWave();}
 render(GAME.state==='menu'?null:W,dt,GAME.state!=='wave'||GAME.paused);
 requestAnimationFrame(frame);}

addEventListener('load',()=>{initRender(document.getElementById('cv'));initUI();toMenu();requestAnimationFrame(frame);});
