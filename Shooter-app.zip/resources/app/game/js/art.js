'use strict';
// ===================== disegni =====================
// Soldati, stemmi e dardi copiati da Montaperti (Documents\Codex\Montaperti\js\art.js e core.js, versione 1.9.1).
// Aggiunti qui: armi in mano, monete, bottini, pane, Carroccio nero, balestra da muro, trabucchetto.
function rr(g,x,y,w,h,r){r=Math.max(0,Math.min(r,w/2,h/2));g.beginPath();g.moveTo(x+r,y);g.arcTo(x+w,y,x+w,y+h,r);g.arcTo(x+w,y+h,x,y+h,r);g.arcTo(x,y+h,x,y,r);g.arcTo(x,y,x+w,y,r);g.closePath();}
function ell(g,x,y,rx,ry,rot){g.beginPath();g.ellipse(x,y,Math.max(.01,rx),Math.max(.01,ry),rot||0,0,TAU);}
function shade(hex,f){let n=parseInt(hex.slice(1),16),r=n>>16,g=n>>8&255,b=n&255;const t=f<0?0:255,p=Math.abs(f);
  r=Math.round((t-r)*p+r);g=Math.round((t-g)*p+g);b=Math.round((t-b)*p+b);return `rgb(${r},${g},${b})`;}
function mkCanvas(w,h){const c=document.createElement('canvas');c.width=Math.ceil(w);c.height=Math.ceil(h);return c;}

// fazioni: le prime sei come in Montaperti (stesso ordine per Firenze, Siena, Briganti, Napoli, Milano, Lucca),
// più due per i nemici: la Compagnia di ventura (nero e oro) e gli eretici (saio grigio).
const FAC=[
 {name:'Firenze',tunic:'#c8302c',tunic2:'#f1e7d0',cap:'#b02a24',helm:'#b8bec4',horse:'#7a5434',pat:'v',arms:'giglio',pen:'#c8302c'},
 {name:'Siena',tunic:'#efe8d8',tunic2:'#1e1c1c',cap:'#262222',helm:'#7c838a',horse:'#3e2e22',pat:'h',arms:'balzana',pen:'#1e1c1c'},
 {name:'Briganti',tunic:'#6b5a3a',tunic2:'#3e4a2a',cap:'#4a3a24',helm:'#6a6a60',horse:'#5a4030',pat:'v',arms:'brig',pen:'#c9a227'},
 {name:'Napoli',tunic:'#2a4a9a',tunic2:'#e8c34a',cap:'#1e3a7a',helm:'#c0c4c8',horse:'#6a4a30',pat:'v',arms:'angio',pen:'#2a4a9a'},
 {name:'Milano',tunic:'#f0ece0',tunic2:'#c02020',cap:'#c02020',helm:'#dfe3e8',horse:'#5a3a24',pat:'x',arms:'croce',pen:'#c02020'},
 {name:'Lucca',tunic:'#f0ece0',tunic2:'#c8302c',cap:'#a82424',helm:'#b8bec4',horse:'#6a4a2a',pat:'h',arms:'lucca',pen:'#c8302c'},
 {name:'Ventura',tunic:'#2a2624',tunic2:'#d9a520',cap:'#1c1a18',helm:'#5c6066',horse:'#2e2420',pat:'v',arms:'ventura',pen:'#d9a520'},
 {name:'Eretici',tunic:'#7d776a',tunic2:'#5a5448',cap:'#4c463c',helm:'#6a6a60',horse:'#5a4030',pat:'h',arms:'brig',pen:'#8a1a2a'},
];
// tipi di soldato usati dal disegno (in Montaperti c'erano anche costi e statistiche)
const UT={worker:{cls:'worker'},inf:{cls:'inf'},guard:{cls:'inf'},pike:{cls:'inf'},xb:{cls:'xb'},xbe:{cls:'xb'},cav:{cls:'cav'},ted:{cls:'cav'},ang:{cls:'cav'},
 hero_fi:{cls:'inf',hero:true,heroArt:'inf'},hero_si:{cls:'cav',hero:true,heroArt:'ted'},hero_lu:{cls:'xb',hero:true,heroArt:'xbe'}};

// ===================== stemmi =====================
function giglio(g,s,col){g.save();g.scale(s/22,s/22);g.fillStyle=col;
 g.beginPath();g.moveTo(0,-11);g.quadraticCurveTo(4.5,-4,1.6,2);g.lineTo(-1.6,2);g.quadraticCurveTo(-4.5,-4,0,-11);g.fill();
 for(const m of [1,-1]){g.beginPath();g.moveTo(1.6*m,1.5);g.quadraticCurveTo(9*m,-1,8*m,-8);g.quadraticCurveTo(11.5*m,-1,4.5*m,4.5);g.closePath();g.fill();
  g.beginPath();g.moveTo(2*m,-1);g.lineTo(5*m,-7.5);g.lineTo(3.2*m,-1);g.fill();}
 g.fillRect(-5.5,2.4,11,2.6);g.beginPath();g.moveTo(-1.6,5);g.lineTo(1.6,5);g.lineTo(3,11);g.lineTo(-3,11);g.closePath();g.fill();g.restore();}
function paintArms(g,fac,x,y,w,h){const s=Math.min(w,h);
 switch(FAC[fac].arms){
  case 'giglio':g.fillStyle='#f4efe2';g.fillRect(x,y,w,h);g.save();g.translate(x+w/2,y+h/2);giglio(g,s*.95,'#c8221e');g.restore();break;
  case 'balzana':g.fillStyle='#f4efe2';g.fillRect(x,y,w,h/2);g.fillStyle='#1c1a1a';g.fillRect(x,y+h/2,w,h/2+.5);break;
  case 'angio':g.fillStyle='#24418f';g.fillRect(x,y,w,h);g.save();g.translate(x+w/2,y+h*.56);giglio(g,s*.8,'#f0c84a');g.restore();g.fillStyle='#c8302c';g.fillRect(x,y,w,h*.14);break;
  case 'croce':g.fillStyle='#f4efe2';g.fillRect(x,y,w,h);g.fillStyle='#c02020';g.fillRect(x+w*.38,y,w*.24,h);g.fillRect(x,y+h*.38,w,h*.24);break;
  case 'lucca':g.fillStyle='#f4efe2';g.fillRect(x,y,w,h/2);g.fillStyle='#c8302c';g.fillRect(x,y+h/2,w,h/2+.5);break;
  case 'ventura':g.fillStyle='#1c1a18';g.fillRect(x,y,w,h);g.fillStyle='#d9a520';g.beginPath();g.moveTo(x,y);g.lineTo(x+w*.3,y);g.lineTo(x+w,y+h*.7);g.lineTo(x+w,y+h);g.lineTo(x+w*.7,y+h);g.lineTo(x,y+h*.3);g.closePath();g.fill();break;
  default:g.fillStyle='#6b5a3a';g.fillRect(x,y,w,h);g.fillStyle='#c9a227';g.fillRect(x+w*.4,y,w*.2,h);}}
function stemma(g,fac,x,y,w,h){g.save();rr(g,x,y,w,h,Math.min(w,h)*.25);g.clip();paintArms(g,fac,x,y,w,h);
 g.restore();rr(g,x,y,w,h,Math.min(w,h)*.25);g.strokeStyle='rgba(40,25,10,.8)';g.lineWidth=.8;g.stroke();}

// ===================== soldati (da Montaperti) =====================
const POSE={i:{},w0:{mv:1,walk:0,ph:0},w1:{mv:1,walk:1,ph:1.57},w2:{mv:1,walk:0,ph:3.14},w3:{mv:1,walk:-1,ph:4.71},a:{atk:1,lunge:4},b:{brace:1},k:{work:1}};
const isHorse=t=>t==='cav'||t==='ted'||t==='ang'||!!(UT[t]?.hero&&UT[t].cls==='cav');
function drawHeroArt(g,fac,type,p){const d=UT[type],base=d.heroArt,horse=d.cls==='cav',f=FAC[fac];
 g.save();g.scale(1.12,1.12);
 const y=horse?-26:-15;g.beginPath();g.moveTo(-3,y);g.lineTo(-10-(p.mv?2:0),y+17);g.lineTo(-1,y+14);g.lineTo(2,y+1);g.closePath();g.fillStyle=shade(f.tunic,-.25);g.fill();g.strokeStyle='#d5b567';g.lineWidth=1;g.stroke();
 drawUnitArt(g,fac,base,p);
 const head=horse?-33:-20;g.fillStyle='#d5b567';g.fillRect(-3,head,6,2);g.fillStyle=f.tunic2;g.beginPath();g.moveTo(-1,head);g.lineTo(-3,head-6);g.lineTo(3,head-4);g.lineTo(2,head);g.closePath();g.fill();g.strokeStyle='#332719';g.lineWidth=.7;g.stroke();
 if(fac===0){g.strokeStyle='#674827';g.lineWidth=1.6;g.beginPath();g.moveTo(-11,1);g.lineTo(-11,-42);g.stroke();paintArms(g,fac,-11,-41,11,13);}
 g.restore();}
function drawUnitArt(g,fac,type,p){if(UT[type]?.hero){drawHeroArt(g,fac,type,p);return;}const f=FAC[fac];const walk=p.walk||0,lunge=p.lunge||0;
 const pattern=(x,y,w,h)=>{g.fillStyle=f.tunic2;if(f.pat==='h')g.fillRect(x,y+h/2,w,h/2);else if(f.pat==='x'){g.fillRect(x+w/2-1,y,2,h);g.fillRect(x,y+h*.35,w,2);}else g.fillRect(x+w/2-1,y,2,h);};
 const body=(bx,by,cap,tunic,plain)=>{rr(g,bx-4,by-9,8,10,3);g.fillStyle=tunic||f.tunic;g.fill();
  if(!plain){g.save();rr(g,bx-4,by-9,8,10,3);g.clip();pattern(bx-4,by-9,8,10);g.restore();}
  g.strokeStyle='rgba(30,20,10,.5)';g.lineWidth=.7;rr(g,bx-4,by-9,8,10,3);g.stroke();
  ell(g,bx,by-12,3.2,3.2);g.fillStyle='#e2b88e';g.fill();g.beginPath();g.arc(bx,by-12.5,3.5,Math.PI,0);g.fillStyle=cap||f.helm;g.fill();};
 const big=isHorse(type);
 ell(g,big?2:1,0,big?14:7,big?4.5:3);g.fillStyle='rgba(25,30,10,.38)';g.fill();
 if(big){const heavy=type!=='cav',mv=p.mv,hc=heavy?'#5a5048':f.horse;
  g.strokeStyle=shade(heavy?'#6a6058':f.horse,-.3);g.lineWidth=2;g.lineCap='round';
  for(const [lx,ph] of [[-7,0],[-4,2],[5,1],[8,3]]){g.beginPath();g.moveTo(lx,-7);g.lineTo(lx+(mv?Math.sin((p.ph||0)+ph)*3:0),0);g.stroke();}
  g.strokeStyle=hc;g.lineWidth=2;g.beginPath();g.moveTo(-11,-10);g.quadraticCurveTo(-15,-6,-14,-2);g.stroke();
  ell(g,0,-10,11,5);g.fillStyle=hc;g.fill();
  g.beginPath();g.moveTo(7,-12);g.lineTo(12,-19);g.lineTo(15,-18);g.lineTo(11,-10);g.closePath();g.fill();ell(g,15,-18,4,2.4,.3);g.fill();
  g.save();ell(g,0,-10,11.5,5.5);g.clip();
  if(heavy){paintArms(g,fac,-12,-13,24,10);g.fillStyle='#d4b04a';g.fillRect(-12,-4,24,1);}
  else{g.fillStyle=f.tunic;g.fillRect(-12,-11,24,7);pattern(-12,-11,24,7);}g.restore();
  if(heavy){body(-1,-14,'#8a9096');g.fillStyle='#9aa1a8';g.fillRect(-4.5,-31,7,6);g.fillStyle='#222';g.fillRect(-3.5,-28.5,5,1);g.fillStyle=f.pen;g.fillRect(-2,-34,3,3);}
  else body(-1,-14,f.helm);
  const ang=p.atk?-.08:p.mv?-.08:-.9;g.save();g.translate(2+lunge,-19);g.rotate(ang);
  g.strokeStyle='#6b4a28';g.lineWidth=1.6;g.beginPath();g.moveTo(-8,0);g.lineTo(24,0);g.stroke();
  g.fillStyle='#d8dde2';g.beginPath();g.moveTo(24,-1.5);g.lineTo(29,0);g.lineTo(24,1.5);g.fill();
  g.fillStyle=f.pen;g.beginPath();g.moveTo(19,0);g.lineTo(14,-1);g.lineTo(13,4);g.lineTo(19,1.6);g.fill();g.restore();
  stemma(g,fac,-6,-19,6,8);return;}
 g.strokeStyle='#3d2c1c';g.lineWidth=2;g.lineCap='round';g.beginPath();g.moveTo(-1.5,-6);g.lineTo(-1.5-walk*2,0);g.moveTo(1.5,-6);g.lineTo(1.5+walk*2,0);g.stroke();
 if(type==='worker'){body(0,-5,f===FAC[0]?'#d9b86a':f.cap,f.tunic,fac!==7);
  if(fac===7){ell(g,0,-17,4.2,3.6);g.fillStyle=f.cap;g.fill();g.fillStyle='#e2b88e';ell(g,0,-16.4,2.4,2.2);g.fill();}
  g.save();g.translate(3,-10);g.rotate(p.work?-1.9:-.5);g.strokeStyle='#6b4a28';g.lineWidth=1.4;g.beginPath();g.moveTo(0,0);g.lineTo(13,0);g.stroke();
  if(fac===7){g.strokeStyle='#d8c070';g.lineWidth=1.2;g.beginPath();g.moveTo(10,-3);g.lineTo(10,3);g.moveTo(8,-1);g.lineTo(12,-1);g.stroke();}
  else{g.fillStyle='#9aa1a8';g.beginPath();g.moveTo(10,-1);g.lineTo(14,0);g.lineTo(10,1.6);g.fill();}g.restore();return;}
 if(type==='inf'||type==='guard'){const gd=type==='guard';body(0,p.brace?-3:-5,gd?'#d8c070':f.helm);
  if(gd){g.fillStyle='#d8c070';g.fillRect(-4.5,-6,9,2.5);g.fillStyle=f.tunic;ell(g,0,-19,1.6,3);g.fill();}
  g.save();g.translate(3+lunge,-12);g.rotate(p.atk?1.35:p.brace?1.15:0);g.strokeStyle='#6b4a28';g.lineWidth=1.4;g.beginPath();g.moveTo(0,10);g.lineTo(0,gd?-16:-20);g.stroke();
  if(gd){g.fillStyle='#d8dde2';g.beginPath();g.moveTo(-3.5,-16);g.lineTo(0,-23);g.lineTo(3.5,-16);g.lineTo(0,-13);g.fill();}
  else{g.fillStyle='#d8dde2';g.beginPath();g.moveTo(-1.6,-20);g.lineTo(0,-25);g.lineTo(1.6,-20);g.fill();}g.restore();
  g.fillStyle='rgba(0,0,0,.25)';rr(g,4.5+lunge*.5,-20,8,17,2.5);g.fill();stemma(g,fac,(p.brace?7:4)+lunge*.5,p.brace?-19:-21,p.brace?10:8,gd?14:17);return;}
 if(type==='pike'){body(0,p.brace?-3:-5,f.helm);
  g.save();g.translate(2+Math.min(lunge,.5),-12);g.rotate(p.atk?1.05:p.brace?1.3:p.mv?1.05:.12);g.strokeStyle='#6b4a28';g.lineWidth=1.5;g.beginPath();g.moveTo(0,12);g.lineTo(0,-34);g.stroke();
  // l'Alfiere porta un vessillo in cima all'asta
  if(fac===6){g.save();g.translate(0,-30);paintArms(g,fac,0,0,11,8);g.restore();}
  g.fillStyle='#e0e4e8';g.beginPath();g.moveTo(-1.8,-34);g.lineTo(0,-40);g.lineTo(1.8,-34);g.fill();g.restore();
  stemma(g,fac,-7,-14,5,8);return;}
 if(type==='xb'||type==='xbe'){const el=type==='xbe';
  body(0,-5,el?f.helm:f.cap);if(el){g.fillStyle='rgba(0,0,0,.2)';rr(g,-9,-19,6,14,2);g.fill();stemma(g,fac,-9.5,-20,6,14);}
  const rec=p.atk?-2:0;g.save();g.translate(rec,0);
  g.strokeStyle='#6b4a28';g.lineWidth=2;g.beginPath();g.moveTo(-1,-12);g.lineTo(el?11:10,-13);g.stroke();
  g.strokeStyle=el?'#3d4248':'#5d6268';g.lineWidth=el?2:1.6;g.beginPath();g.arc(7,-13,el?6:5,-1.2,1.2);g.stroke();
  g.strokeStyle='rgba(240,240,220,.8)';g.lineWidth=.6;g.beginPath();g.moveTo(8.8,-17.6);g.lineTo(p.atk?2:7.5,-13);g.lineTo(8.8,-8.4);g.stroke();g.restore();
  if(!el){g.fillStyle='#8a5a2a';g.fillRect(-6,-12,3,7);}}}

// Sprite in memoria: ogni posa si disegna una volta sola, poi si incolla (veloce anche con 100 nemici).
// Il foglio è 84×64 unità con l'origine (i piedi) in (42,54), disegnato a risoluzione doppia.
const USPR={};
function unitSpr(fac,type,pose,flip){const k=fac+type+pose+(flip?'f':'');let c=USPR[k];if(c)return c;
 c=mkCanvas(168,128);const g=c.getContext('2d');g.scale(2,2);g.translate(42,54);if(flip)g.scale(-1,1);drawUnitArt(g,fac,type,POSE[pose]);USPR[k]=c;return c;}
// stessa sagoma tutta bianca, per il lampo quando un nemico viene colpito
const WSPR={};
function whiteSpr(src,key){let c=WSPR[key];if(c)return c;c=mkCanvas(src.width,src.height);const g=c.getContext('2d');
 g.drawImage(src,0,0);g.globalCompositeOperation='source-in';g.fillStyle='#fff8ea';g.fillRect(0,0,c.width,c.height);WSPR[key]=c;return c;}

// ===================== dardi (da Montaperti) =====================
function drawBoltArt(g,fire,crit){g.save();
 if(!fire){g.lineCap='round';g.strokeStyle='#2a1d12';g.lineWidth=2.4;g.beginPath();g.moveTo(-9,0);g.lineTo(3,0);g.stroke();
  g.strokeStyle=crit?'#ffe27a':'#d9b97a';g.lineWidth=1;g.beginPath();g.moveTo(-8.5,0);g.lineTo(2,0);g.stroke();
  g.fillStyle='#c8ccd0';g.beginPath();g.moveTo(5,0);g.lineTo(1.5,-1.8);g.lineTo(1.5,1.8);g.closePath();g.fill();
  g.strokeStyle='#5a3a1e';g.lineWidth=1.2;g.beginPath();g.moveTo(-9,-2);g.lineTo(-7,0);g.lineTo(-9,2);g.stroke();g.restore();return;}
 g.lineCap='round';g.lineJoin='round';
 g.beginPath();g.moveTo(-13,0);g.lineTo(4,0);g.strokeStyle='#302016';g.lineWidth=3.2;g.stroke();g.strokeStyle='#e6c083';g.lineWidth=1.3;g.stroke();
 g.beginPath();g.moveTo(5.5,0);g.bezierCurveTo(5,-3.1,1,-4,-1,-2.7);g.lineTo(-5.7,-3.3);
 g.bezierCurveTo(-4.5,-1.4,-4,.1,-6,.2);g.bezierCurveTo(-3.7,.4,-4.2,2.3,-3.3,3.5);g.lineTo(-1.6,2.4);g.bezierCurveTo(1.2,4.2,4.8,3.3,5.5,0);g.closePath();
 g.fillStyle='#f47720';g.fill();g.strokeStyle='#3d2518';g.lineWidth=1.2;g.stroke();
 g.beginPath();g.moveTo(4.4,0);g.bezierCurveTo(3.2,-1.8,1.3,-2,-1.2,-.8);g.lineTo(-2.4,0);g.bezierCurveTo(.7,.6,1.7,2.6,4.4,0);g.closePath();g.fillStyle='#ffe57b';g.fill();
 g.restore();}
// piccola fiamma, stessa forma della punta del dardo incendiario
function flame(g,x,y,s){g.save();g.translate(x,y);g.rotate(-Math.PI/2);g.scale(s,s);
 g.beginPath();g.moveTo(5.5,0);g.bezierCurveTo(5,-3.1,1,-4,-1,-2.7);g.lineTo(-5.7,-3.3);g.bezierCurveTo(-4.5,-1.4,-4,.1,-6,.2);g.bezierCurveTo(-3.7,.4,-4.2,2.3,-3.3,3.5);g.lineTo(-1.6,2.4);g.bezierCurveTo(1.2,4.2,4.8,3.3,5.5,0);g.closePath();
 g.fillStyle='#f47720';g.fill();g.strokeStyle='#3d2518';g.lineWidth=1;g.stroke();
 g.beginPath();g.moveTo(4.4,0);g.bezierCurveTo(3.2,-1.8,1.3,-2,-1.2,-.8);g.lineTo(-2.4,0);g.bezierCurveTo(.7,.6,1.7,2.6,4.4,0);g.closePath();g.fillStyle='#ffe57b';g.fill();g.restore();}

// ===================== armi in mano =====================
// Disegnate lungo l'asse x, impugnatura nell'origine. fac serve per gonfalone e stemmi.
const WOOD='#6b4a28',STEEL='#d8dde2',INK='#2a1d12';
function shaft(g,x0,x1,w=1.8){g.strokeStyle=INK;g.lineWidth=w+1.4;g.lineCap='round';g.beginPath();g.moveTo(x0,0);g.lineTo(x1,0);g.stroke();
 g.strokeStyle=WOOD;g.lineWidth=w;g.stroke();}
function blade(g,pts){g.beginPath();pts.forEach(([x,y],i)=>g[i?'lineTo':'moveTo'](x,y));g.closePath();g.fillStyle=STEEL;g.fill();g.strokeStyle=INK;g.lineWidth=.9;g.stroke();}
function drawWeaponArt(g,id,fac,tier){g.save();g.lineJoin='round';
 switch(id){
  case 'pugnale':shaft(g,-3,3,2.2);g.fillStyle='#8a6a3a';g.fillRect(3,-2.5,1.6,5);blade(g,[[4.6,-1.4],[15,0],[4.6,1.4]]);break;
  case 'spada':shaft(g,-4,3,2.4);g.fillStyle='#b89a4a';g.fillRect(3,-4,2,8);g.strokeStyle=INK;g.lineWidth=.6;g.strokeRect(3,-4,2,8);blade(g,[[5,-1.8],[24,-1],[27,0],[24,1],[5,1.8]]);
   g.strokeStyle='rgba(60,60,70,.5)';g.lineWidth=.6;g.beginPath();g.moveTo(6,0);g.lineTo(23,0);g.stroke();break;
  case 'lancia':shaft(g,-8,30);blade(g,[[28,-2.2],[37,0],[28,2.2]]);break;
  case 'alabarda':shaft(g,-6,30,2);blade(g,[[22,-1],[22,-8],[28,-7],[30,-1]]);blade(g,[[30,-1.6],[36,0],[30,1.6]]);blade(g,[[23,1],[26,4.5],[28,1]]);break;
  case 'mazza':shaft(g,-4,14,2.2);ell(g,17,0,5,5);g.fillStyle='#8a9096';g.fill();g.strokeStyle=INK;g.lineWidth=1;g.stroke();
   for(let k=0;k<6;k++){const a=k/6*TAU;g.beginPath();g.moveTo(17+Math.cos(a)*4.5,Math.sin(a)*4.5);g.lineTo(17+Math.cos(a)*7.5,Math.sin(a)*7.5);g.stroke();}break;
  case 'forcone':shaft(g,-6,24);g.strokeStyle='#5d6268';g.lineWidth=1.4;g.beginPath();g.moveTo(24,-4);g.lineTo(24,4);
   for(const y of [-4,0,4]){g.moveTo(24,y);g.lineTo(32,y);}g.stroke();break;
  case 'torcia':shaft(g,-4,12,2.6);g.fillStyle='#4a3020';g.fillRect(11,-3,4,6);flame(g,19,0,1);break;
  case 'gonfalone':{shaft(g,-6,30,1.6);g.save();g.translate(26,0);g.rotate(Math.PI/2);paintArms(g,fac,-1,-14,10,13);g.strokeStyle=INK;g.lineWidth=.6;g.strokeRect(-1,-14,10,13);g.restore();
   g.fillStyle='#d9a520';ell(g,31,0,1.6,1.6);g.fill();break;}
  case 'mazzuolo':shaft(g,-4,12,2.2);g.fillStyle='#8a6a3a';rr(g,11,-5,7,10,1.5);g.fill();g.strokeStyle=INK;g.lineWidth=1;g.stroke();break;
  case 'fionda':g.strokeStyle=WOOD;g.lineWidth=2.4;g.lineCap='round';g.beginPath();g.moveTo(-2,0);g.lineTo(6,0);g.moveTo(6,0);g.lineTo(11,-5);g.moveTo(6,0);g.lineTo(11,5);g.stroke();
   g.strokeStyle='#8a6a3a';g.lineWidth=.8;g.beginPath();g.moveTo(11,-5);g.lineTo(8,0);g.lineTo(11,5);g.stroke();break;
  case 'arco':g.strokeStyle=INK;g.lineWidth=3;g.beginPath();g.arc(2,0,12,-1.25,1.25);g.stroke();g.strokeStyle='#8a5a2a';g.lineWidth=1.8;g.stroke();
   g.strokeStyle='rgba(240,240,220,.85)';g.lineWidth=.6;g.beginPath();g.moveTo(2+Math.cos(-1.25)*12,Math.sin(-1.25)*12);g.lineTo(2+Math.cos(1.25)*12,Math.sin(1.25)*12);g.stroke();break;
  case 'balestra':case 'staffa':{const big=id==='staffa';shaft(g,-6,big?16:13,big?3:2.4);
   g.strokeStyle=big?'#3d4248':'#5d6268';g.lineWidth=big?2.6:1.8;g.beginPath();g.arc(big?9:7,0,big?8:6.5,-1.25,1.25);g.stroke();
   g.strokeStyle='rgba(240,240,220,.85)';g.lineWidth=.6;g.beginPath();const R=big?8:6.5,cx=big?9:7;g.moveTo(cx+Math.cos(-1.25)*R,Math.sin(-1.25)*R);g.lineTo(cx-2,0);g.lineTo(cx+Math.cos(1.25)*R,Math.sin(1.25)*R);g.stroke();
   if(big){g.strokeStyle='#5d6268';g.lineWidth=1.4;g.beginPath();g.arc(18,0,2.5,-Math.PI/2,Math.PI/2);g.stroke();}break;}
  case 'pignatta':ell(g,6,0,6,6);g.fillStyle='#b4683a';g.fill();g.strokeStyle=INK;g.lineWidth=1;g.stroke();g.fillStyle='#8a4a2a';g.fillRect(1,-1,10,2);
   g.fillStyle='#d9b97a';g.fillRect(4,-8,4,3);flame(g,6,-10,.6);break;
 }
 if(tier>0){g.fillStyle=RARITY_COL[tier];for(let i=0;i<tier;i++){ell(g,-2-i*3.2,-4,1.2,1.2);g.fill();}}
 g.restore();}
const WICON={};
function weaponIcon(id,fac,tier,size){const k=id+fac+tier+size;if(WICON[k])return WICON[k];const c=mkCanvas(size,size),g=c.getContext('2d');
 g.translate(size*.14,size*.86);g.rotate(-Math.PI/4);const len={pugnale:17,spada:28,lancia:44,alabarda:42,mazza:24,forcone:38,torcia:24,gonfalone:38,mazzuolo:22,fionda:15,arco:16,balestra:22,staffa:24,pignatta:14}[id]||30;
 const k2=size*1.2/Math.max(len+8,22);g.scale(k2,k2);g.translate(id==='pignatta'?4:4,0);drawWeaponArt(g,id,fac,0);WICON[k]=c;return c;}

// ===================== icone degli oggetti =====================
// Ogni oggetto ha un piccolo disegno fatto di forme semplici, nello stesso stile.
function drawItemArt(g,id){g.save();g.lineJoin='round';g.lineCap='round';const st=(c,w=1.2)=>{g.strokeStyle=c;g.lineWidth=w;g.stroke();};
 switch(id){
  case 'pagnotta':ell(g,0,2,11,7);g.fillStyle='#c98a3c';g.fill();st(INK);g.strokeStyle='#f0d49a';g.lineWidth=1.4;for(const x of [-5,0,5]){g.beginPath();g.moveTo(x-2,-2);g.lineTo(x+2,4);g.stroke();}break;
  case 'chianti':ell(g,0,4,8,8);g.fillStyle='#8a1a2a';g.fill();st(INK);g.fillStyle='#d9b97a';g.fillRect(-8,0,16,8);g.strokeStyle='#a8874a';g.lineWidth=.8;for(let x=-7;x<8;x+=3){g.beginPath();g.moveTo(x,0);g.lineTo(x+2,8);g.stroke();}
   g.fillStyle='#3a5a2a';g.fillRect(-2,-11,4,8);g.fillStyle='#6b4a28';g.fillRect(-2,-13,4,2);break;
  case 'maglia':rr(g,-9,-10,18,20,4);g.fillStyle='#9aa1a8';g.fill();st(INK);g.strokeStyle='rgba(40,40,50,.5)';g.lineWidth=.7;for(let y=-7;y<9;y+=3){g.beginPath();g.moveTo(-8,y);g.lineTo(8,y);g.stroke();}break;
  case 'stivali':g.fillStyle='#7a4a28';g.beginPath();g.moveTo(-6,-11);g.lineTo(2,-11);g.lineTo(2,4);g.lineTo(10,6);g.lineTo(10,10);g.lineTo(-6,10);g.closePath();g.fill();st(INK);break;
  case 'cote':rr(g,-11,-4,22,8,3);g.fillStyle='#8a8378';g.fill();st(INK);g.save();g.rotate(-.5);blade(g,[[-4,-12],[1,-12],[-1,2]]);g.restore();break;
  case 'penne':for(const [a,c] of [[-.3,'#f0ece0'],[.2,'#d8d2c0']]){g.save();g.rotate(a);ell(g,0,-2,3.5,10);g.fillStyle=c;g.fill();st(INK,.9);g.beginPath();g.moveTo(0,-12);g.lineTo(0,12);st('#6b4a28',.9);g.restore();}break;
  case 'zolfo':for(const [x,y,r] of [[-4,3,6],[4,2,5],[0,-4,5]]){ell(g,x,y,r,r*.8);g.fillStyle='#e8d040';g.fill();st('#6a5a10');}break;
  case 'corno':g.beginPath();g.moveTo(-11,4);g.quadraticCurveTo(-2,-12,10,-6);g.lineTo(11,1);g.quadraticCurveTo(0,-5,-8,8);g.closePath();g.fillStyle='#e8dcc0';g.fill();st(INK);g.fillStyle='#b89a4a';g.fillRect(-2,-6,3,8);break;
  case 'ferro':g.beginPath();g.arc(0,0,9,Math.PI*.15,Math.PI*.85,true);st(INK,6);g.beginPath();g.arc(0,0,9,Math.PI*.15,Math.PI*.85,true);st('#8a9096',4);break;
  case 'falce':g.beginPath();g.moveTo(-9,10);g.lineTo(2,-4);st(WOOD,2.4);g.beginPath();g.moveTo(2,-4);g.quadraticCurveTo(10,-14,12,-2);g.quadraticCurveTo(8,-8,2,-4);g.fillStyle=STEEL;g.fill();st(INK,.9);break;
  case 'occhiali':for(const x of [-6,6]){ell(g,x,0,5,5);g.fillStyle='rgba(200,230,255,.5)';g.fill();st(INK,1.6);}g.beginPath();g.moveTo(-1,-1);g.lineTo(1,-1);st(INK,1.6);break;
  case 'scapolare':g.beginPath();g.moveTo(-7,-12);g.lineTo(0,-2);g.lineTo(7,-12);st(INK,1);rr(g,-6,-2,12,12,2);g.fillStyle='#6a4a3a';g.fill();st(INK);g.fillStyle='#e0c060';g.fillRect(-1,0,2,8);g.fillRect(-3,2,6,2);break;
  case 'sanguisuga':g.beginPath();g.moveTo(-10,3);g.quadraticCurveTo(-4,-8,4,-3);g.quadraticCurveTo(10,1,10,5);g.quadraticCurveTo(0,6,-10,3);g.fillStyle='#4a2a2a';g.fill();st(INK);g.fillStyle='#c02020';ell(g,9,4,1.5,1.5);g.fill();break;
  case 'squadra':g.beginPath();g.moveTo(-9,-11);g.lineTo(-9,9);g.lineTo(11,9);st(INK,5);g.beginPath();g.moveTo(-9,-11);g.lineTo(-9,9);g.lineTo(11,9);st('#c0a060',3);break;
  case 'lanterna':rr(g,-6,-7,12,15,2);g.fillStyle='#f0c040';g.fill();st(INK);g.strokeStyle=INK;g.lineWidth=1;g.beginPath();g.moveTo(0,-7);g.lineTo(0,8);g.stroke();g.beginPath();g.arc(0,-9,3,Math.PI,0);st(INK);break;
  case 'barbuta':g.beginPath();g.moveTo(-9,10);g.lineTo(-9,-3);g.quadraticCurveTo(0,-15,9,-3);g.lineTo(9,10);g.lineTo(3,10);g.lineTo(3,0);g.lineTo(-3,0);g.lineTo(-3,10);g.closePath();g.fillStyle='#b8bec4';g.fill();st(INK);break;
  case 'sella':g.beginPath();g.moveTo(-11,-2);g.quadraticCurveTo(-8,-10,-4,-4);g.quadraticCurveTo(0,0,4,-4);g.quadraticCurveTo(8,-10,11,-2);g.lineTo(9,6);g.lineTo(-9,6);g.closePath();g.fillStyle='#8a3a2a';g.fill();st(INK);g.fillStyle='#d9a520';g.fillRect(-1,6,2,6);break;
  case 'reliquiario':rr(g,-8,-4,16,12,2);g.fillStyle='#d9a520';g.fill();st(INK);g.beginPath();g.moveTo(-9,-4);g.lineTo(0,-11);g.lineTo(9,-4);g.closePath();g.fill();st(INK);g.fillStyle='#8a1a2a';g.fillRect(-1,-2,2,8);g.fillRect(-3,0,6,2);break;
  case 'fuocogreco':ell(g,0,4,7,7);g.fillStyle='#4a6a3a';g.fill();st(INK);g.fillStyle='#4a6a3a';g.fillRect(-2,-6,4,5);flame(g,0,-8,.7);break;
  case 'dadi':for(const [x,y,a] of [[-4,2,.2],[5,-3,-.3]]){g.save();g.translate(x,y);g.rotate(a);rr(g,-5,-5,10,10,2);g.fillStyle='#f0ece0';g.fill();st(INK);g.fillStyle=INK;ell(g,-2,-2,1,1);g.fill();ell(g,2,2,1,1);g.fill();g.restore();}break;
  case 'alloro':for(const m of [1,-1])for(let k=0;k<5;k++){const a=Math.PI*(.6+k*.17)*m;ell(g,Math.cos(a)*8*m,Math.sin(a)*8,3,1.6,a);g.fillStyle='#4a7a3a';g.fill();st('#2a4a1a',.6);}break;
  case 'fiorinofalso':case 'moneta':ell(g,0,0,9,9);g.fillStyle='#d9a520';g.fill();st('#6a4a10',1.4);g.save();g.translate(0,.5);giglio(g,13,'#8a5a10');g.restore();break;
  case 'balestramuro':g.fillStyle='#8a6a3a';g.fillRect(-9,0,18,9);st(INK);g.save();g.translate(-4,-3);drawWeaponArt(g,'balestra',0,0);g.restore();break;
  case 'abaco':rr(g,-10,-9,20,18,2);st('#6b4a28',2.4);for(const y of [-4,1,6]){g.beginPath();g.moveTo(-9,y);g.lineTo(9,y);st('#8a8378',.7);for(let k=0;k<4;k++){ell(g,-6+k*4+(y>0?2:0),y,1.6,1.6);g.fillStyle=k%2?'#c02020':'#f0ece0';g.fill();}}break;
  case 'brocchiere':ell(g,0,0,10,10);g.fillStyle='#8a9096';g.fill();st(INK,1.4);ell(g,0,0,3.5,3.5);g.fillStyle='#d9a520';g.fill();st(INK);break;
  case 'elmetto':g.beginPath();g.moveTo(-12,4);g.lineTo(12,4);g.lineTo(8,1);g.quadraticCurveTo(0,-14,-8,1);g.closePath();g.fillStyle='#9aa1a8';g.fill();st(INK);break;
  case 'martinella':g.beginPath();g.moveTo(-8,8);g.quadraticCurveTo(-7,-10,0,-10);g.quadraticCurveTo(7,-10,8,8);g.closePath();g.fillStyle='#b8862a';g.fill();st(INK);ell(g,0,9,2,2);g.fillStyle=INK;g.fill();g.fillRect(-1,-13,2,3);break;
  case 'vessillo':g.beginPath();g.moveTo(-8,-12);g.lineTo(-8,12);st(WOOD,1.8);g.save();g.beginPath();g.moveTo(-7,-11);g.lineTo(9,-9);g.lineTo(5,-4);g.lineTo(9,0);g.lineTo(-7,1);g.closePath();g.clip();paintArms(g,0,-7,-12,16,14);g.restore();break;
  case 'pietrafocaia':g.beginPath();g.moveTo(-9,4);g.lineTo(-3,-8);g.lineTo(6,-6);g.lineTo(9,5);g.lineTo(0,9);g.closePath();g.fillStyle='#5a5a62';g.fill();st(INK);g.strokeStyle='#ffe27a';g.lineWidth=1.2;g.beginPath();g.moveTo(5,-9);g.lineTo(10,-13);g.moveTo(7,-6);g.lineTo(12,-7);g.stroke();break;
  case 'acquasanta':g.beginPath();g.moveTo(0,-11);g.quadraticCurveTo(9,1,0,10);g.quadraticCurveTo(-9,1,0,-11);g.fillStyle='#8ac8f0';g.fill();st(INK);g.fillStyle='#fff';g.fillRect(-.6,-3,1.2,7);g.fillRect(-2.5,-1,5,1.2);break;
  case 'pece':rr(g,-8,-10,16,20,4);g.fillStyle='#6b4a28';g.fill();st(INK);for(const y of [-5,4]){g.fillStyle='#3a3a3a';g.fillRect(-8,y,16,2);}g.fillStyle='#1c1a18';ell(g,0,-10,5,2);g.fill();break;
  case 'trabucchetto':g.beginPath();g.moveTo(-10,9);g.lineTo(0,-6);g.lineTo(10,9);st('#5c3e22',2.4);g.beginPath();g.moveTo(-8,-10);g.lineTo(10,-2);st('#7a5430',2);g.fillStyle='#4e4a44';g.fillRect(-11,-11,5,6);break;
  case 'speroni':g.beginPath();g.moveTo(-10,0);g.lineTo(4,0);st('#d9a520',2.4);for(let k=0;k<8;k++){const a=k/8*TAU;g.beginPath();g.moveTo(7,0);g.lineTo(7+Math.cos(a)*5,Math.sin(a)*5);st('#d9a520',1.2);}break;
  case 'tamburo':ell(g,0,4,10,5);g.fillStyle='#8a3a2a';g.fill();g.fillRect(-10,-4,20,8);ell(g,0,-4,10,5);g.fillStyle='#e8dcc0';g.fill();st(INK);g.beginPath();g.moveTo(-6,-14);g.lineTo(-1,-5);g.moveTo(8,-13);g.lineTo(3,-5);st(WOOD,1.4);break;
  case 'anello':ell(g,0,3,8,8);st('#d9a520',3);g.fillStyle='#c02020';ell(g,0,-6,4,3.4);g.fill();st(INK);break;
  case 'carrocciomini':g.fillStyle='#c0c4c8';g.fillRect(-10,0,20,5);g.strokeStyle=INK;g.lineWidth=.8;g.strokeRect(-10,0,20,5);for(const x of [-7,7]){ell(g,x,7,3,3);g.fillStyle='#8a9096';g.fill();st(INK,.8);}
   g.beginPath();g.moveTo(0,0);g.lineTo(0,-13);st('#8a8a8a',1.2);g.fillStyle='#e8e8e8';g.fillRect(0,-13,9,6);g.fillStyle='#c02020';g.fillRect(3,-13,2,6);break;
  case 'sacrocuore':g.beginPath();g.moveTo(-6,12);g.lineTo(4,-10);st(WOOD,2.4);ell(g,6,-12,4,3);g.fillStyle='#e8dcc0';g.fill();st(INK);break;
  case 'lucerna':ell(g,0,0,10,10);g.fillStyle='#e8eef4';g.fill();st('#b8862a',2.4);g.strokeStyle='#f0c040';g.lineWidth=1;for(let k=0;k<8;k++){const a=k/8*TAU;g.beginPath();g.moveTo(Math.cos(a)*4,Math.sin(a)*4);g.lineTo(Math.cos(a)*8,Math.sin(a)*8);g.stroke();}break;
  default:ell(g,0,0,9,9);g.fillStyle='#8a7350';g.fill();st(INK);
 }
 g.restore();}
const IICON={};
function itemIcon(id,size){const k=id+size;if(IICON[k])return IICON[k];const c=mkCanvas(size,size),g=c.getContext('2d');
 g.translate(size/2,size/2);g.scale(size/30,size/30);drawItemArt(g,id);IICON[k]=c;return c;}
function heroIcon(charId,size){const ch=CHARS[charId],c=mkCanvas(size,size),g=c.getContext('2d');const big=isHorse(ch.art);
 g.translate(size*.5-(big?3:0),size*.88);const s=size/(big?62:56);g.scale(s,s);drawUnitArt(g,ch.fac,ch.art,POSE.i);return c;}

// ===================== raccoglibili e costruzioni =====================
function drawCoin(g,x,y,s,t){g.save();g.translate(x,y);const sq=Math.abs(Math.cos(t*4));g.scale(s*(.35+.65*sq),s);
 ell(g,0,0,4.6,4.6);g.fillStyle='#e0b030';g.fill();g.strokeStyle='#6a4a10';g.lineWidth=1.1;g.stroke();
 g.fillStyle='#f7dc7a';ell(g,-1.2,-1.4,1.5,1.3);g.fill();g.restore();}
function drawCrate(g,x,y,s){g.save();g.translate(x,y);g.scale(s,s);
 ell(g,0,1,11,3);g.fillStyle='rgba(25,30,10,.35)';g.fill();
 g.fillStyle='#7a4a1a';rr(g,-9,-12,18,12,2);g.fill();g.fillStyle='#e0a530';g.fillRect(-9,-9,18,2.5);g.fillRect(-1.5,-12,3,12);
 g.fillStyle='#9a6a2a';rr(g,-9,-17,18,6,3);g.fill();g.strokeStyle='#3a2410';g.lineWidth=.8;rr(g,-9,-17,18,17,2);g.stroke();g.restore();}
function drawBread(g,x,y,s){g.save();g.translate(x,y);g.scale(s,s);ell(g,0,1,8,2.5);g.fillStyle='rgba(25,30,10,.3)';g.fill();
 ell(g,0,-4,8,5);g.fillStyle='#c98a3c';g.fill();g.strokeStyle='#5a3410';g.lineWidth=1;g.stroke();
 g.strokeStyle='#f0d49a';g.lineWidth=1.2;for(const x0 of [-3,1]){g.beginPath();g.moveTo(x0,-7);g.lineTo(x0+2,-2);g.stroke();}g.restore();}
function drawStructArt(g,type,ang,anim){
 ell(g,0,1,16,5);g.fillStyle='rgba(25,30,10,.38)';g.fill();
 if(type==='balestra'){g.fillStyle='#6a4626';g.fillRect(-10,-8,20,8);g.strokeStyle='#3a2616';g.lineWidth=1;g.strokeRect(-10,-8,20,8);
  g.strokeStyle='#5c3e22';g.lineWidth=2;g.beginPath();g.moveTo(-7,0);g.lineTo(-4,-8);g.moveTo(7,0);g.lineTo(4,-8);g.stroke();
  g.save();g.translate(0,-12);g.scale(Math.cos(ang)<0?-1:1,1);g.rotate(Math.cos(ang)<0?Math.PI-ang:ang);g.translate(anim>0?-2:0,0);g.scale(1.1,1.1);drawWeaponArt(g,'balestra',0,0);g.restore();return;}
 // trabucchetto: come il trabucco di Montaperti, più piccolo
 const arm=anim>0?-2.2+anim*4:-.5;
 g.strokeStyle='#5c3e22';g.lineWidth=2.6;g.lineCap='round';g.beginPath();g.moveTo(-14,0);g.lineTo(14,0);g.moveTo(-9,0);g.lineTo(0,-26);g.lineTo(9,0);g.stroke();
 for(const wx of [-12,12]){ell(g,wx,0,3.2,3.2);g.fillStyle='#4a3020';g.fill();}
 g.save();g.translate(0,-26);g.rotate(arm);g.strokeStyle='#7a5430';g.lineWidth=2.2;g.beginPath();g.moveTo(-8,0);g.lineTo(22,0);g.stroke();g.fillStyle='#4e4a44';g.fillRect(-13,-2,8,10);g.restore();}

// Il Carroccio nero: il carro di guerra della Compagnia (in Montaperti è il carro sacro di Firenze).
function drawCarrArt(g,t,hurt){ell(g,4,2,32,8);g.fillStyle='rgba(25,30,10,.4)';g.fill();
 for(const wx of [-16,14]){ell(g,wx,-5,6,6);g.fillStyle='#3a2a1a';g.fill();ell(g,wx,-5,3,3);g.fillStyle='#8a6a3a';g.fill();
  g.strokeStyle='#2a1d12';g.lineWidth=1;for(let k=0;k<4;k++){const a=k/4*Math.PI+t*3;g.beginPath();g.moveTo(wx,-5);g.lineTo(wx+Math.cos(a)*5.5,-5+Math.sin(a)*5.5);g.stroke();}}
 g.fillStyle='#2a2624';g.fillRect(-24,-17,48,10);g.fillStyle='#d9a520';for(let i=-24;i<24;i+=8)g.fillRect(i,-17,4,10);
 g.strokeStyle='#2a1d12';g.lineWidth=2;g.beginPath();g.moveTo(-8,-17);g.lineTo(-8,-50);g.stroke();
 // campana
 g.fillStyle='#8a6a2a';g.beginPath();g.moveTo(-14,-36);g.quadraticCurveTo(-13,-48,-8,-48);g.quadraticCurveTo(-3,-48,-2,-36);g.closePath();g.fill();g.strokeStyle='#2a1d12';g.lineWidth=1;g.stroke();
 g.strokeStyle='#2a1d12';g.lineWidth=2;g.beginPath();g.moveTo(4,-17);g.lineTo(4,-66);g.stroke();
 g.save();const L=34,Hh=22,top=-64;g.beginPath();g.moveTo(4,top);for(let i=0;i<=8;i++){const u=i/8;g.lineTo(4+u*L,top+Math.sin(t*4+u*5)*u*3);}
 for(let i=8;i>=0;i--){const u=i/8;g.lineTo(4+u*L,top+Hh+Math.sin(t*4+u*5)*u*3);}g.closePath();g.clip();
 paintArms(g,6,4,top-5,L,Hh+10);g.restore();
 for(const by of [-2,5]){ell(g,-38,by-6,8,4);g.fillStyle='#3a3230';g.fill();ell(g,-46,by-8,3,2.5);g.fill();
  g.strokeStyle='#e8e0d0';g.lineWidth=1;g.beginPath();g.moveTo(-47,by-11);g.lineTo(-50,by-14);g.stroke();}
 if(hurt){g.fillStyle='rgba(255,90,40,.35)';g.fillRect(-24,-17,48,10);}}
