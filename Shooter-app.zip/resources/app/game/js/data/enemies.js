﻿'use strict';
// Nemici: la Compagnia della Malaventura, briganti e mercenari.
// hp/dmg crescono a ogni ondata: hp + hpW Ã— (ondata âˆ’ 1).  spd in punti al secondo.  val = fiorini lasciati.
// art: fazione e tipo del disegno di Montaperti, scala.  beh: comportamento.
const ENEMIES={
 brigante:{n:'Brigante',hp:3,hpW:2,dmg:1,dmgW:.6,spd:165,r:11,val:1,beh:'chase',art:{fac:2,type:'inf',s:1}},
 tagliagole:{n:'Tagliagole',hp:2,hpW:1.2,dmg:1,dmgW:.6,spd:215,r:10,val:1,beh:'chase',art:{fac:2,type:'worker',s:.95}},
 masnadiero:{n:'Masnadiero',hp:20,hpW:11,dmg:2,dmgW:.85,spd:170,r:17,val:3,beh:'chase',knockRes:.8,art:{fac:6,type:'guard',s:1.45}},
 balestriere:{n:'Balestriere brigante',hp:10,hpW:5,dmg:1,dmgW:.7,spd:120,r:11,val:2,beh:'shooter',range:270,cd:2.6,art:{fac:2,type:'xb',s:1}},
 rinnegato:{n:'Cavaliere rinnegato',hp:5,hpW:3,dmg:1,dmgW:.85,spd:190,r:15,val:1,beh:'charger',knockRes:.5,art:{fac:2,type:'cav',s:1}},
 frate:{n:'Frate eretico',hp:12,hpW:7,dmg:1,dmgW:.5,spd:200,r:11,val:2,beh:'healer',art:{fac:7,type:'worker',s:1.05}},
 alfiere:{n:'Alfiere',hp:18,hpW:4,dmg:1,dmgW:.6,spd:95,r:12,val:2,beh:'buffer',knockRes:.9,art:{fac:6,type:'pike',s:1.1}},
 reclutatore:{n:'Reclutatore',hp:14,hpW:6,dmg:1,dmgW:.5,spd:70,r:13,val:3,beh:'spawner',knockRes:.7,art:{fac:6,type:'xb',s:1.2}},
 capitano:{n:'Capitano di ventura',hp:400,hpW:130,dmg:3,dmgW:1.5,spd:150,r:24,val:20,beh:'elite',knockRes:1,elite:1,art:{fac:6,type:'ted',s:1.6}},
 carroccio:{n:'Il Carroccio nero',hp:2500,hpW:600,dmg:4,dmgW:1.6,spd:70,r:42,val:0,beh:'boss',knockRes:1,boss:1,art:{boss:1,s:1.9}},
};
for(const [id,e] of Object.entries(ENEMIES))e.id=id;

// Ondate: dur = durata in secondi. g = gruppi: e nemico, n [min,max] per volta, ogni `every` secondi,
// da `from` a `to` secondi (facoltativi). once = una volta sola.
const WV=(dur,...g)=>({dur,g});
const GR=(e,n0,n1,every,from=0,to=999,once=false)=>({e,n:[n0,n1],every,from,to,once});
const WAVES=[
 WV(20,GR('brigante',3,4,3)),
 WV(25,GR('brigante',4,5,3),GR('tagliagole',2,3,5,8)),
 WV(30,GR('brigante',5,5,3),GR('tagliagole',3,3,5,5),GR('rinnegato',1,2,8,14)),
 WV(35,GR('brigante',5,6,3),GR('balestriere',1,2,6,3),GR('tagliagole',3,3,6,10)),
 WV(40,GR('brigante',6,7,3),GR('tagliagole',3,3,5),GR('balestriere',2,2,7,10),GR('masnadiero',1,1,12,15)),
 WV(45,GR('brigante',6,6,3),GR('rinnegato',3,3,6),GR('reclutatore',1,1,20,5),GR('tagliagole',4,4,6,10)),
 WV(50,GR('brigante',7,8,3),GR('masnadiero',1,1,8,5),GR('balestriere',2,2,6),GR('frate',1,1,15,10)),
 WV(55,GR('tagliagole',5,6,4),GR('brigante',7,8,3),GR('rinnegato',3,3,6,8),GR('alfiere',1,1,15,10)),
 WV(60,GR('brigante',8,10,3),GR('masnadiero',2,2,8),GR('balestriere',3,3,6),GR('reclutatore',1,1,20,10)),
 WV(60,GR('brigante',9,10,3),GR('rinnegato',4,4,5),GR('tagliagole',5,6,4),GR('frate',1,1,15,5),GR('masnadiero',2,2,8,10)),
 WV(60,GR('capitano',1,1,0,4,999,true),GR('brigante',7,8,4),GR('tagliagole',4,4,5),GR('balestriere',2,2,8,20)),
 WV(60,GR('brigante',10,12,3),GR('masnadiero',3,3,7),GR('balestriere',3,3,5),GR('alfiere',2,2,15,5)),
 WV(60,GR('tagliagole',9,10,3),GR('rinnegato',5,5,5),GR('reclutatore',2,2,20,5),GR('frate',2,2,15,10)),
 WV(60,GR('brigante',12,14,3),GR('masnadiero',3,3,6),GR('balestriere',4,4,5),GR('rinnegato',4,4,6,10)),
 WV(60,GR('brigante',12,14,3),GR('tagliagole',7,8,4),GR('masnadiero',4,4,6),GR('alfiere',2,2,12),GR('frate',2,2,15,10)),
 WV(60,GR('brigante',14,16,3),GR('rinnegato',6,6,4),GR('balestriere',4,4,5),GR('reclutatore',2,2,15,5)),
 WV(60,GR('brigante',14,16,3),GR('masnadiero',5,5,5),GR('tagliagole',9,10,3),GR('frate',2,2,12),GR('alfiere',2,2,12,5)),
 WV(60,GR('capitano',1,1,0,4,999,true),GR('capitano',1,1,0,32,999,true),GR('brigante',10,12,3),GR('balestriere',4,4,5),GR('frate',1,1,15,10)),
 WV(60,GR('brigante',16,18,3),GR('masnadiero',6,6,5),GR('rinnegato',6,6,4),GR('balestriere',5,5,5),GR('tagliagole',9,10,3)),
 WV(90,GR('carroccio',1,1,0,3,999,true),GR('brigante',8,10,4),GR('tagliagole',5,6,5,10),GR('masnadiero',2,2,10,20)),
];
// Vita aggiuntiva: prime 7 ondate invariate, secondo incremento dalla 14.
// Boss ed élite hanno una curva distinta, per reggere il fuoco concentrato.
function lateEnemyHp(wave,enemy){if(wave<=7)return 1;
 if(enemy.boss)return wave<14?1.25+.025*(wave-8):1.5+.025*(wave-14);
 if(enemy.elite)return wave<14?1.5+.05*(wave-8):2+.05*(wave-14);
 return wave<14?1.1+.02*(wave-8):1.3+.02*(wave-14);}
const MAX_ENEMIES=120;
const ENEMY_ARRIVAL=.25;
// In compagnia la resistenza cresce gradualmente dalla 14, senza toccare
// danni, velocità o la partita in solitaria. Le build restano libere di crescere.
function coopLateHp(wave,players){return 1+Math.min(1,Math.max(0,(wave-13)/7))*.25*(players-1);}

// Endless riusa cinque composizioni avanzate senza aumentare il tetto di nemici.
// Le statistiche continuano a crescere; un Capitano ogni 5 ondate, un boss ogni 10.
function waveConfig(wave,gameMode='standard'){
 if(!Number.isSafeInteger(wave)||wave<1)throw Error('Ondata non valida');
 if(wave<=WAVES.length)return WAVES[wave-1];
 if(gameMode!=='endless')throw Error('La partita classica termina alla ventesima ondata');
 const boss=wave%10===0,elite=!boss&&wave%5===0;
 const base=WAVES[boss?19:[16,18,15,16,18][(wave-21)%5]];
 const groups=base.g.map(g=>({...g,n:[...g.n]}));
 if(elite)groups.unshift(GR('capitano',1,1,0,4,999,true));
 return WV(boss?90:60,...groups);
}
function endlessScaling(wave,gameMode){const extra=gameMode==='endless'?Math.max(0,wave-WAVES.length):0;
 return {hp:(1+.045*extra+.0015*extra*extra)*Math.pow(1.12,Math.min(extra,1000)),dmg:1+.02*extra};}

// Potenziamenti di livello: valore per raritÃ  (comune, non comune, rara, leggendaria).
const UPGRADES={maxhp:[3,6,9,12],regen:[2,3,4,5],lifesteal:[1,2,3,4],dmg:[5,8,12,16],melee:[2,4,6,8],
 ranged:[1,2,3,4],elem:[1,2,3,4],atkspd:[5,10,15,20],crit:[3,5,7,9],eng:[2,3,4,5],range:[10,20,30,40],
 armor:[1,2,3,4],dodge:[3,6,9,12],speed:[3,6,9,12],luck:[5,10,15,20],harvest:[5,8,10,12]};

// Livelli di pericolo: moltiplicano vita e danno dei nemici.
const DANGER=[{n:'Normale',hp:1,dmg:1},{n:'Difficile',hp:1.25,dmg:1.2},{n:'Infernale',hp:1.55,dmg:1.45}];
