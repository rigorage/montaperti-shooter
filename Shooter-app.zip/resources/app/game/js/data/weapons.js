'use strict';
// Armi. Ogni numero in elenco ha un valore per qualità I, II, III, IV.
// kind: melee (mischia) / ranged (distanza)   att: thrust (affondo), sweep (fendente), shot (tiro), lob (lancio a parabola)
// sc: statistiche che si sommano al danno, con il loro coefficiente.  cd: secondi fra due colpi.
// val: valore in bottega.  minT: qualità minima con cui si trova in bottega.
const WEAPONS={
 pugnale:{n:'Pugnale',fam:['Lama'],kind:'melee',att:'thrust',
  dmg:[7,11,17,26],cd:[.55,.5,.45,.4],range:95,sc:{melee:.8},crit:.2,cm:2.5,knock:2,val:[18,36,70,140]},
 spada:{n:'Spada',fam:['Lama'],kind:'melee',att:'sweep',
  dmg:[13,21,33,52],cd:[1,.92,.85,.78],range:115,sc:{melee:1},crit:.05,cm:2,knock:5,val:[25,48,92,180]},
 lancia:{n:'Lancia',fam:['Asta'],kind:'melee',att:'thrust',
  dmg:[11,17,27,42],cd:[.85,.8,.75,.7],range:150,sc:{melee:.9},crit:.03,cm:2,knock:6,val:[22,44,85,165]},
 alabarda:{n:'Alabarda',fam:['Asta','Pesante'],kind:'melee',att:'sweep',
  dmg:[22,34,52,80],cd:[1.45,1.35,1.25,1.15],range:140,sc:{melee:1.1},crit:.03,cm:2,knock:10,val:[30,58,110,210]},
 mazza:{n:'Mazza ferrata',fam:['Pesante'],kind:'melee',att:'thrust',
  dmg:[18,29,45,70],cd:[1.15,1.08,1,.92],range:100,sc:{melee:1.2},crit:.05,cm:2,knock:18,val:[24,46,90,175]},
 forcone:{n:'Forcone',fam:['Contadino','Asta'],kind:'melee',att:'thrust',
  dmg:[7,10,15,23],cd:[.8,.75,.7,.65],range:130,sc:{melee:.6},crit:.03,cm:2,knock:4,val:[12,25,50,100],
  fx:[{on:'kill',chance:[.1,.12,.15,.2],do:{gold:1}}]},
 torcia:{n:'Torcia',fam:['Fuoco'],kind:'melee',att:'sweep',
  dmg:[4,6,9,13],cd:[.9,.85,.8,.75],range:95,sc:{elem:1},crit:.03,cm:2,knock:2,val:[20,40,78,150],
  burn:{dmg:[3,5,7,10],n:4}},
 gonfalone:{n:'Gonfalone',fam:['Sacro'],kind:'melee',att:'sweep',
  dmg:[7,11,17,25],cd:[1.1,1.05,1,.95],range:125,sc:{melee:.5,maxhp:.15},crit:.03,cm:2,knock:6,val:[28,55,105,200],
  fx:[{s:'armor',v:[1,2,3,4]}]},
 mazzuolo:{n:'Mazzuolo del carpentiere',fam:['Ingegneria'],kind:'melee',att:'thrust',
  dmg:[6,9,13,19],cd:[.95,.9,.85,.8],range:100,sc:{eng:1},crit:.03,cm:2,knock:5,val:[25,50,95,185],
  fx:[{on:'waveStart',do:{summon:'balestra',n:[1,1,2,3]}}]},
 fionda:{n:'Fionda',fam:['Contadino','Tiro'],kind:'ranged',att:'shot',
  dmg:[9,13,19,28],cd:[.95,.9,.85,.8],range:240,sc:{ranged:.8},crit:.03,cm:2,knock:6,val:[14,28,55,110],
  proj:{speed:700,pierce:0,look:'sasso'}},
 arco:{n:'Arco lungo',fam:['Tiro'],kind:'ranged',att:'shot',
  dmg:[6,9,14,21],cd:[.6,.55,.5,.45],range:290,sc:{ranged:.8},crit:.05,cm:2,knock:2,val:[22,44,85,165],
  proj:{speed:950,pierce:0,look:'freccia'}},
 balestra:{n:'Balestra',fam:['Balestra'],kind:'ranged',att:'shot',
  dmg:[13,21,32,50],cd:[.95,.9,.85,.8],range:300,sc:{ranged:1},crit:.1,cm:2,knock:5,val:[26,50,96,185],
  proj:{speed:1050,pierce:1,pr:.5,look:'dardo'}},
 staffa:{n:'Balestra a staffa',fam:['Balestra','Pesante'],kind:'ranged',att:'shot',minT:1,
  dmg:[28,45,70,110],cd:[2.1,2,1.9,1.8],range:330,sc:{ranged:1.5},crit:.12,cm:2.5,knock:12,val:[30,60,115,220],
  proj:{speed:1200,pierce:3,pr:.35,look:'dardo'}},
 pignatta:{n:'Pignatta di fuoco greco',fam:['Fuoco'],kind:'ranged',att:'lob',
  dmg:[8,12,18,27],cd:[1.35,1.28,1.2,1.1],range:250,sc:{elem:1},crit:.03,cm:2,knock:4,val:[26,52,100,195],
  proj:{look:'pignatta',flight:.55},expl:{r:[55,60,65,75]},burn:{dmg:[2,3,4,6],n:3}},
};
for(const [id,w] of Object.entries(WEAPONS)){w.id=id;w.minT=w.minT||0;}

// Famiglie di armi: più armi della stessa famiglia hai, più bonus ricevi (da 2 a 6).
const FAMILIES={
 Lama:{ic:'🗡',s:'crit',v:[3,6,9,12,15]},
 Asta:{ic:'⟋',s:'range',v:[10,20,30,40,50]},
 Pesante:{ic:'⚒',s:'dmg',v:[5,10,15,20,25]},
 Contadino:{ic:'⚘',s:'harvest',v:[5,10,15,20,25]},
 Tiro:{ic:'➹',s:'atkspd',v:[3,6,9,12,15]},
 Balestra:{ic:'🏹',s:'ranged',v:[1,2,3,4,5]},
 Fuoco:{ic:'🔥',s:'elem',v:[1,2,3,4,5]},
 Sacro:{ic:'✝',s:'maxhp',v:[3,6,9,12,15]},
 Ingegneria:{ic:'⚙',s:'eng',v:[1,2,3,4,5]},
};
