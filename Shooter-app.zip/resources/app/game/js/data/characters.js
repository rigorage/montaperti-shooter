'use strict';
// I tre personaggi. fac = fazione di Montaperti (colori e stemma), art = disegno dell'eroe.
const CHARS={
 firenze:{n:'Gonfaloniere del Popolo',city:'Firenze',fac:0,art:'hero_fi',start:['lancia'],
  role:'Mischia robusta, bottega a buon prezzo',
  fx:[{s:'melee',v:3},{s:'armor',v:1},{s:'price',v:-10},{s:'ranged',v:-3},
   {flag:'popolo',t:'Popolo in armi: ogni arma da mischia dà +1 Armatura.'}]},
 siena:{n:'Capitano delle Contrade',city:'Siena',fac:1,art:'hero_si',start:['lancia'],
  role:'A cavallo: più corre, più colpisce forte',
  fx:[{s:'speed',v:15},{per:{s:'dmg',v:1},of:'speed',each:2},{s:'maxhp',v:-1},
   {flag:'charge',t:'Carica: dopo 1 secondo di corsa il colpo successivo fa +60% danni.'}]},
 lucca:{n:'Custode della Cerchia',city:'Lucca',fac:5,art:'hero_lu',start:['balestra','fionda'],
  role:'Balestriera: colpisce da lontano, ma è fragile',
  fx:[{s:'range',v:40},{s:'ranged',v:3},{s:'atkspd',v:10},{s:'maxhp',v:-2},{s:'melee',v:-3},
   {flag:'third',t:'Ogni terzo dardo trapassa 2 nemici in più e fa +30% danni.'}]},
};
for(const [id,c] of Object.entries(CHARS))c.id=id;
