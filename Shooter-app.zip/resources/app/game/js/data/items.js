'use strict';
// Oggetti. t = rarità (0 comune, 1 non comune, 2 rara, 3 leggendaria). val = valore in bottega.
// max = quante copie se ne possono avere (assente = senza limite). Il testo degli effetti si scrive da solo.
const ITEMS={
 // ---------- comuni ----------
 pagnotta:{n:'Pagnotta',t:0,val:15,fx:[{s:'maxhp',v:4}]},
 chianti:{n:'Fiasco di vino',t:0,val:18,fx:[{s:'regen',v:2},{s:'speed',v:-2}]},
 maglia:{n:'Cotta di maglia',t:0,val:20,fx:[{s:'armor',v:2},{s:'speed',v:-3}]},
 stivali:{n:'Stivali di cuoio',t:0,val:18,fx:[{s:'speed',v:6}]},
 cote:{n:'Cote per affilare',t:0,val:16,fx:[{s:'melee',v:2}]},
 penne:{n:'Penne d\'oca',t:0,val:16,fx:[{s:'ranged',v:2}]},
 zolfo:{n:'Zolfo',t:0,val:16,fx:[{s:'elem',v:2}]},
 corno:{n:'Corno da caccia',t:0,val:20,fx:[{s:'atkspd',v:8},{s:'dmg',v:-2}]},
 ferro:{n:'Ferro di cavallo',t:0,val:15,fx:[{s:'luck',v:10}]},
 falce:{n:'Falce',t:0,val:20,fx:[{s:'harvest',v:6}]},
 occhiali:{n:'Occhiali di Pisa',t:0,val:18,fx:[{s:'range',v:20},{s:'dodge',v:-1}]},
 scapolare:{n:'Scapolare',t:0,val:17,fx:[{s:'dodge',v:3}]},
 sanguisuga:{n:'Sanguisuga',t:0,val:18,fx:[{s:'lifesteal',v:2},{s:'maxhp',v:-1}]},
 squadra:{n:'Squadra da muratore',t:0,val:18,fx:[{s:'eng',v:2}]},
 lanterna:{n:'Lanterna',t:0,val:15,fx:[{s:'pickup',v:30},{s:'luck',v:5}]},
 // ---------- non comuni ----------
 barbuta:{n:'Elmo a barbuta',t:1,val:40,fx:[{s:'armor',v:3},{s:'maxhp',v:3},{s:'dodge',v:-2}]},
 sella:{n:'Sella da guerra',t:1,val:42,fx:[{s:'speed',v:8},{s:'dmg',v:4}]},
 reliquiario:{n:'Reliquiario',t:1,val:45,fx:[{s:'regen',v:3},{s:'maxhp',v:5}]},
 fuocogreco:{n:'Ampolla di fuoco greco',t:1,val:45,fx:[{s:'elem',v:3},{on:'hit',chance:.15,do:{burn:{dmg:3,n:3}}}]},
 dadi:{n:'Dadi truccati',t:1,val:40,fx:[{s:'crit',v:5},{s:'luck',v:10},{s:'dodge',v:-3}]},
 alloro:{n:'Corona d\'alloro',t:1,val:45,fx:[{on:'kill',chance:.08,do:{heal:1}}],max:3},
 fiorinofalso:{n:'Fiorino falso',t:1,val:40,fx:[{on:'pickup',chance:.1,do:{gold:1}}],max:3},
 balestramuro:{n:'Balestra da muro',t:1,val:55,fx:[{on:'waveStart',do:{summon:'balestra',n:1}}],max:4},
 abaco:{n:'Abaco del mercante',t:1,val:45,fx:[{s:'harvest',v:10},{s:'xp',v:10}]},
 brocchiere:{n:'Brocchiere',t:1,val:45,fx:[{s:'dodge',v:5},{s:'armor',v:1},{s:'ranged',v:-1}]},
 elmetto:{n:'Cappello d\'arme',t:1,val:38,fx:[{s:'maxhp',v:6},{s:'speed',v:-2}]},
 // ---------- rare ----------
 martinella:{n:'Martinella',t:2,val:70,fx:[{on:'waveStart',do:{temp:{s:'dmg',v:30},dur:8}},{s:'armor',v:1}],max:1,
  d:'La campana di guerra che accompagnava il Carroccio.'},
 vessillo:{n:'Vessillo strappato',t:2,val:75,fx:[{on:'waveEnd',do:{gain:{s:'maxhp',v:2}}},{s:'maxhp',v:2}],max:2},
 pietrafocaia:{n:'Pietra focaia',t:2,val:70,fx:[{on:'crit',chance:.25,do:{explode:{dmg:10,r:55}}},{s:'crit',v:3}]},
 acquasanta:{n:'Acqua santa',t:2,val:65,fx:[{on:'dodge',do:{heal:2}},{s:'dodge',v:4}]},
 pece:{n:'Barile di pece',t:2,val:65,fx:[{on:'hurt',do:{explode:{dmg:20,r:80}}},{s:'armor',v:2}]},
 trabucchetto:{n:'Trabucchetto',t:2,val:80,fx:[{on:'waveStart',do:{summon:'trabucco',n:1}},{s:'eng',v:2}],max:3},
 speroni:{n:'Speroni d\'oro',t:2,val:70,fx:[{per:{s:'dmg',v:1},of:'speed',each:3},{s:'speed',v:5}],max:1},
 tamburo:{n:'Tamburo',t:2,val:75,fx:[{on:'interval',every:10,do:{temp:{s:'atkspd',v:25},dur:4}},{s:'atkspd',v:5}]},
 // ---------- leggendarie ----------
 anello:{n:'Anello del Podestà',t:3,val:120,fx:[{s:'dmg',v:15},{s:'atkspd',v:10},{s:'maxhp',v:5}]},
 carrocciomini:{n:'Carroccio d\'argento',t:3,val:125,fx:[{per:{s:'armor',v:1},of:'maxhp',each:8},{s:'maxhp',v:8}],max:1},
 sacrocuore:{n:'Bastone del pellegrino',t:3,val:115,fx:[{s:'regen',v:6},{s:'lifesteal',v:4},{s:'speed',v:5}]},
 lucerna:{n:'Specchio ustorio',t:3,val:120,fx:[{s:'elem',v:6},{on:'kill',chance:.25,do:{explode:{dmg:12,r:60}}}],max:1},
};
for(const [id,it] of Object.entries(ITEMS))it.id=id;
