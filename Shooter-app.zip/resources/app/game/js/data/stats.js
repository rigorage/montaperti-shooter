'use strict';
// Le statistiche del personaggio. pct = si mostra con il segno %; cap = tetto di partenza.
const STATS={
 maxhp:   {n:'Vita massima',      ic:'❤', base:10},
 regen:   {n:'Rigenerazione',     ic:'✚'},
 lifesteal:{n:'Furto di vita',    ic:'🩸', pct:1},
 dmg:     {n:'Danno',             ic:'⚔', pct:1},
 melee:   {n:'Danno in mischia',  ic:'🗡'},
 ranged:  {n:'Danno a distanza',  ic:'🏹'},
 elem:    {n:'Danno del fuoco',   ic:'🔥'},
 atkspd:  {n:'Velocità d\'attacco',ic:'⏱', pct:1},
 crit:    {n:'Critico',           ic:'✦', pct:1},
 eng:     {n:'Ingegneria',        ic:'⚒'},
 range:   {n:'Portata',           ic:'◎'},
 armor:   {n:'Armatura',          ic:'🛡'},
 dodge:   {n:'Schivata',          ic:'↯', pct:1, cap:60},
 speed:   {n:'Velocità',          ic:'➶', pct:1},
 luck:    {n:'Fortuna',           ic:'☘'},
 harvest: {n:'Raccolta',          ic:'⚘'},
 // secondarie: si vedono solo se diverse da zero
 xp:      {n:'Esperienza',        pct:1, sec:1},
 pickup:  {n:'Raggio di raccolta',pct:1, sec:1},
 price:   {n:'Prezzi in bottega', pct:1, sec:1, bad:1},
 knock:   {n:'Respinta',          sec:1},
 expl:    {n:'Danno delle esplosioni',pct:1,sec:1},
 heal:    {n:'Cure ricevute',     pct:1, sec:1},
 pierce:  {n:'Perforazione',      sec:1},
 burnx:   {n:'Durata incendi',    pct:1, sec:1},
};
const STAT_KEYS=Object.keys(STATS);
const PRIMARY_STATS=STAT_KEYS.filter(k=>!STATS[k].sec);

// Costanti del giocatore (distanze in punti dell'arena, circa 2/3 di Brotato)
const PLAYER={speed:300,r:12,pickup:100};
const ARENA={w:1400,h:940};
