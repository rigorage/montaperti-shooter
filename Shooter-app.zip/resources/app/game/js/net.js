'use strict';
// ===================== multigiocatore (fino a 4) =====================
// Come in Montaperti: PeerJS collega i PC direttamente, il servizio pubblico 0.peerjs.com serve solo a trovarsi.
// Chi ospita (host) fa girare la partita vera; gli ospiti mandano i tasti e ricevono 15 "fotografie" al secondo.
// Bottega e livelli restano sul PC di ciascuno: a inizio ondata ognuno manda la sua scheda (runSnapshot).
// Prova senza internet: aggiungere ?locale=1 all'indirizzo e aprire più schede dello stesso browser.
const NET_PREFIX='mshooter-',NET_MAX=4,SNAP_MS=66,PLAYER_COL=['#64cfff','#ff866b','#c69bff','#9fe774'];
const NET={role:null,code:null,peer:null,bc:null,links:[],host:null,slot:0,lobby:[],phase:'idle',onChange:null,snapT:0,evq:[],inT:0,lastIn:'',view:null,msg:''};
const NET_LOCAL=typeof location!=='undefined'&&/[?&]locale=1/.test(location.search);
const CODE_CHARS='ABCDEFGHJKLMNPQRSTUVWXYZ';
const newCode=()=>Array.from({length:5},()=>CODE_CHARS[Math.floor(Math.random()*CODE_CHARS.length)]).join('');

// ---------- collegamenti (PeerJS oppure, per le prove, BroadcastChannel) ----------
// Un "link" ha send(obj), close() e chiama onData/onClose. I messaggi viaggiano come testo JSON: con la
// serializzazione "binary" PeerJS spezza da solo i messaggi grandi (stessa scelta fatta in Montaperti).
function linkFromConn(conn,onOpen){const L={open:false,conn,lastSeen:performance.now(),
  send(m){if(L.open)try{conn.send(JSON.stringify(m));}catch(e){}},close(){try{conn.close();}catch(e){}}};
 conn.on('open',()=>{L.open=true;onOpen&&onOpen(L);});
 conn.on('data',d=>{L.lastSeen=performance.now();let m=d;if(typeof m==='string'){if(m.length>4e6)return;try{m=JSON.parse(m);}catch(e){return;}}L.onData&&L.onData(m);});
 conn.on('close',()=>{if(!L.closed){L.closed=true;L.onClose&&L.onClose();}});conn.on('error',()=>{if(!L.closed){L.closed=true;L.onClose&&L.onClose();}});
 return L;}
function linkLocal(bc,me,other){const L={open:true,lastSeen:performance.now(),send(m){bc.postMessage({from:me,to:other,m});},close(){bc.postMessage({from:me,to:other,bye:1});}};return L;}

function netReset(){if(NET.peer)try{NET.peer.destroy();}catch(e){}if(NET.bc)try{NET.bc.close();}catch(e){}
 Object.assign(NET,{role:null,code:null,peer:null,bc:null,links:[],host:null,slot:0,lobby:[],phase:'idle',snapT:0,evq:[],inT:0,lastIn:'',view:null,msg:'',wantStart:null});}
const netOn=()=>NET.role!==null;
function netChanged(msg){if(msg!=null)NET.msg=msg;if(NET.onChange)NET.onChange();}

// ---------- chi ospita ----------
function hostRoom(charId,attempt=0){netReset();NET.role='host';NET.code=newCode();NET.phase='lobby';NET.slot=0;
 NET.lobby=[{slot:0,charId,me:true}];NET.danger=0;netChanged('Apro la stanza…');
 if(NET_LOCAL){const bc=new BroadcastChannel(NET_PREFIX+NET.code);NET.bc=bc;bc.onmessage=ev=>hostLocalMsg(ev.data);netChanged('');return;}
 if(!window.Peer){netChanged('PeerJS non disponibile.');return;}
 const peer=new Peer(NET_PREFIX+NET.code.toLowerCase());NET.peer=peer;
 peer.on('open',()=>netChanged(''));
 peer.on('error',e=>{if(e.type==='unavailable-id'&&attempt<3){hostRoom(charId,attempt+1);return;}if(NET.peer===peer)netChanged('Impossibile aprire la stanza: controlla internet e riprova.');});
 peer.on('connection',conn=>{if(NET.peer!==peer)return;const L=linkFromConn(conn);hostAdopt(L);});}
function hostLocalMsg(d){if(d.to!=='host')return;let L=NET.links.find(l=>l.rid===d.from);
 if(d.bye){if(L)hostDrop(L);return;}
 if(!L){L=linkLocal(NET.bc,'host',d.from);L.rid=d.from;hostAdopt(L);}
 L.lastSeen=performance.now();L.onData(d.m);}
function hostAdopt(L){L.onData=m=>hostData(L,m);L.onClose=()=>hostDrop(L);L.input={x:0,y:0};NET.links.push(L);}
function hostFreeSlot(){for(let s=1;s<NET_MAX;s++)if(!NET.lobby.some(p=>p.slot===s))return s;return -1;}
function hostData(L,m){if(!m||typeof m.t!=='string')return;
 switch(m.t){
  case 'hello':{if(L.slot!=null)return;
   if(m.v!==GAME_VERSION){L.send({t:'reject',reason:`Versione diversa: tu hai la ${m.v}, chi ospita la ${GAME_VERSION}. Aggiornate entrambi il gioco.`});setTimeout(()=>L.close(),300);return;}
   if(NET.phase!=='lobby'){L.send({t:'reject',reason:'La partita è già cominciata.'});setTimeout(()=>L.close(),300);return;}
   const slot=hostFreeSlot();if(slot<0){L.send({t:'reject',reason:'La stanza è piena (massimo 4 giocatori).'});setTimeout(()=>L.close(),300);return;}
   L.slot=slot;NET.lobby.push({slot,charId:CHARS[m.charId]?m.charId:'firenze'});NET.lobby.sort((a,b)=>a.slot-b.slot);
   L.send({t:'welcome',slot});hostLobbyPublish();sfx('click');break;}
  case 'pick':{const p=NET.lobby.find(p=>p.slot===L.slot);if(p&&CHARS[m.charId]&&NET.phase==='lobby'){p.charId=m.charId;hostLobbyPublish();}break;}
  case 'i':if(Number.isFinite(m.x)&&Number.isFinite(m.y))L.input={x:clamp(m.x,-1,1),y:clamp(m.y,-1,1)};break;
  case 'run':{if(NET.phase!=='waiting'&&NET.phase!=='lobby-start')return;try{L.run=runFromSnapshot(m.run);L.ready=true;}catch(e){return;}hostReadyPublish();hostMaybeStart();break;}
  case 'ping':L.send({t:'pong'});break;
  case 'bye':hostDrop(L);break;}}
function hostDrop(L){if(L.dropped)return;L.dropped=true;L.close();NET.links=NET.links.filter(l=>l!==L);
 if(L.slot!=null){NET.lobby=NET.lobby.filter(p=>p.slot!==L.slot);
  const W=GAME.W;if(W&&W.net){const P=W.P.find(P=>P.slot===L.slot);if(P&&!P.dead){P.dead=true;P.gone=true;W.events.push({k:'text',x:P.x,y:P.y-40,t:'si è scollegato',col:'#ffb0a0'});}}
  netChanged('Un giocatore ha lasciato la partita.');}
 if(NET.phase==='lobby')hostLobbyPublish();else{hostReadyPublish();hostMaybeStart();}}
function hostLobbyPublish(){const msg={t:'lobby',players:NET.lobby.map(p=>({slot:p.slot,charId:p.charId})),danger:NET.danger,code:NET.code};
 for(const L of NET.links)if(L.slot!=null)L.send(msg);netChanged();}
function hostPick(charId){const p=NET.lobby.find(p=>p.slot===0);if(p){p.charId=charId;hostLobbyPublish();}}
function hostDanger(d){NET.danger=d;hostLobbyPublish();}
// L'host preme Inizia: tutti creano la propria partita e mandano la scheda; quando sono arrivate tutte parte l'ondata 1.
function hostBegin(){if(NET.role!=='host'||NET.phase!=='lobby')return;NET.phase='lobby-start';NET.seed=(Date.now()%2147480000)+1;
 for(const L of NET.links)if(L.slot!=null)L.send({t:'start',seed:NET.seed,danger:NET.danger});
 netGameStart(NET.lobby.find(p=>p.slot===0).charId,NET.seed,NET.danger);NET.hostReady=true;hostMaybeStart();}
const hostGuests=()=>NET.links.filter(L=>L.slot!=null);
function hostReadyPublish(){const ready=[0,...hostGuests().filter(L=>L.ready).map(L=>L.slot)].filter(s=>s!==0||NET.hostReady);
 const msg={t:'ready',ready,all:[0,...hostGuests().map(L=>L.slot)]};for(const L of hostGuests())L.send(msg);NET.readyInfo=msg;netChanged();}
function hostMaybeStart(){if(NET.role!=='host'||!NET.hostReady)return;if(NET.phase!=='waiting'&&NET.phase!=='lobby-start')return;
 if(!hostGuests().every(L=>L.ready&&L.run))return;
 const run0=GAME.run,guests=hostGuests().sort((a,b)=>a.slot-b.slot);
 for(const L of guests){L.run.wave=run0.wave;L.run.danger=run0.danger;}
 const runs=[run0,...guests.map(L=>L.run)],slots=[0,...guests.map(L=>L.slot)];
 const W=newWorld(runs,makeRng(NET.seed*31+run0.wave));W.net=true;W.P.forEach((P,i)=>P.slot=slots[i]);
 for(const L of guests)L.ready=false;NET.hostReady=false;NET.phase='wave';NET.snapT=0;NET.evq=[];
 const roster=W.P.map(P=>({slot:P.slot,charId:P.run.charId,weapons:P.run.weapons.map(w=>({id:w.id,tier:w.tier}))}));
 for(const L of guests)L.send({t:'wave',wave:run0.wave,dur:W.dur,roster});
 startWaveWith(W);}
// Ogni passo della partita: gli ingressi arrivano dagli ospiti; ogni 66 ms parte una fotografia.
function hostInputs(local){const W=GAME.W;return W.P.map(P=>P.slot===0?local:(NET.links.find(L=>L.slot===P.slot)?.input||{x:0,y:0}));}
function hostCollectEvents(W){for(const e of W.events)NET.evq.push(e);if(NET.evq.length>400)NET.evq.splice(0,NET.evq.length-400);}
function hostTick(dt){const W=GAME.W;if(!W||NET.phase!=='wave')return;NET.snapT+=dt*1000;
 if(NET.snapT<SNAP_MS&&!W.over)return;NET.snapT=0;const snap=makeSnapshot(W,NET.evq);NET.evq=[];
 for(const L of hostGuests())L.send(snap);
 if(W.over){const res={};for(const P of W.P)if(P.slot)res[P.slot]=runResult(P.run);
  for(const L of hostGuests())L.send({t:'end',over:W.over,boss:!!W.bossDead,res});NET.phase='waiting';}}
function netHostWaveDone(){NET.hostReady=false;hostReadyPublish();}
function netHostReady(){NET.hostReady=true;hostReadyPublish();hostMaybeStart();}

// ---------- fotografie della partita ----------
const ETYPES=Object.keys(ENEMIES),STATE_CODE={walk:0,aim:1,dash:2,shoot:3},STATE_NAME=['walk','aim','dash','shoot'];
const LOOKS=['dardo','freccia','sasso','pignatta'],ATT=['thrust','sweep','shot'];
const r1=v=>Math.round(v*10)/10,r0=Math.round;
function makeSnapshot(W,ev){return {t:'s',tt:r1(W.t),dur:W.dur,
 P:W.P.map(P=>[P.slot,r0(P.x),r0(P.y),Math.ceil(P.hp),stats(P.run,W.t).maxhp,P.face,P.moving?1:0,P.iframes>0?1:0,P.dead?1:0,P.charge?1:0,r1(P.moveT),r1(P.walkT),
  Math.round(PLAYER.speed*Math.max(.25,1+stats(P.run,W.t).speed/100)),P.run.gold,r1(P.run.xp),P.run.level,P.run.bag,P.run.cratesPending,
  P.weapons.map(ws=>[Math.round(ws.ang*100),Math.round(ws.anim*1000),Math.round(ws.animDur*1000),ATT.indexOf(ws.att),r0(ws.reach)])]),
 E:W.enemies.filter(e=>!e.dead).map(e=>[e.id,ETYPES.indexOf(e.type),r0(e.x),r0(e.y),Math.ceil(e.hp),e.maxhp,e.face,STATE_CODE[e.state]||0,r1(e.anim),e.flash>0?1:0,e.burn?1:0,e.buff]),
 Q:W.projs.map(q=>[r0(q.x),r0(q.y),r0(q.vx||0),r0(q.vy||0),LOOKS.indexOf(q.look),q.lob?r0(q.h||0):-1,q.gold?1:0]),
 B:W.eprojs.map(q=>[r0(q.x),r0(q.y),r0(q.vx),r0(q.vy)]),
 K:W.pickups.map(k=>[k.kind==='gold'?0:k.kind==='crate'?1:2,r0(k.x),r0(k.y)]),
 T:W.pending.map(q=>[ETYPES.indexOf(q.type),r0(q.x),r0(q.y)]),
 S:W.structs.map(o=>[o.type==='trabucco'?1:0,r0(o.x),r0(o.y),Math.round(o.ang*100),o.anim>0?r1(o.anim):0]),
 V:ev.map(e=>e.k==='swing'?{...e,a:r1(e.a)}:e)};}

// ---------- ospite ----------
function joinRoom(code,charId){netReset();code=(code||'').trim().toUpperCase();
 if(!/^[A-Z]{5}$/.test(code)){netChanged('Scrivi le 5 lettere del codice che ti ha dato chi ospita.');return;}
 NET.role='guest';NET.code=code;NET.phase='joining';NET.charId=charId;netChanged('Cerco la stanza '+code+'…');
 const hello=()=>NET.host.send({t:'hello',v:GAME_VERSION,charId});
 if(NET_LOCAL){const bc=new BroadcastChannel(NET_PREFIX+code),me='g'+Math.random().toString(36).slice(2);NET.bc=bc;NET.host=linkLocal(bc,me,'host');
  NET.host.onData=guestData;bc.onmessage=ev=>{const d=ev.data;if(d.to!==me)return;NET.host.lastSeen=performance.now();guestData(d.m);};hello();
  setTimeout(()=>{if(NET.role==='guest'&&NET.phase==='joining')netChanged('Stanza non trovata: controlla il codice.');},3000);return;}
 if(!window.Peer){netChanged('PeerJS non disponibile.');return;}
 const peer=new Peer();NET.peer=peer;
 peer.on('error',e=>{if(NET.peer!==peer)return;netChanged(e.type==='peer-unavailable'?'Stanza non trovata: controlla il codice.':'Collegamento non riuscito: controlla internet e riprova.');});
 peer.on('open',()=>{if(NET.peer!==peer)return;const L=linkFromConn(peer.connect(NET_PREFIX+code.toLowerCase(),{reliable:true,serialization:'binary'}),hello);
  NET.host=L;L.onData=guestData;L.onClose=()=>guestLost('Il collegamento con chi ospita si è interrotto.');});}
function guestLost(msg){if(NET.role!=='guest')return;const was=NET.phase;netReset();netChanged(msg);if(was!=='joining'&&was!=='idle'&&GAME.state!=='end'&&GAME.state!=='over')netAbort(msg);}
function guestPick(charId){NET.charId=charId;if(NET.host)NET.host.send({t:'pick',charId});}
function guestData(m){if(!m||typeof m.t!=='string')return;
 switch(m.t){
  case 'reject':{const r=m.reason;netReset();netChanged(r);break;}
  case 'welcome':NET.slot=m.slot;NET.phase='lobby';netChanged('');break;
  case 'lobby':NET.lobby=m.players;NET.danger=m.danger;netChanged();break;
  case 'start':NET.phase='waiting';NET.seed=m.seed;netGameStart(NET.charId,m.seed+NET.slot*101,m.danger);netGuestSendRun();break;
  case 'ready':NET.readyInfo=m;netChanged();break;
  case 'wave':NET.phase='wave';NET.view=newView(m);startGuestWave();break;
  case 's':if(NET.view)applySnapshot(NET.view,m);break;
  case 'end':{if(!NET.view)return;NET.phase='waiting';const r=m.res[NET.slot];if(r)applyResult(GAME.run,r);
   NET.view.over=m.over;NET.view.bossDead=m.boss;guestWaveOver();break;}
  case 'bye':guestLost('Chi ospita ha chiuso la partita.');break;}}
function netGuestSendRun(){if(NET.host)NET.host.send({t:'run',run:runSnapshot(GAME.run)});}
function guestSendInput(inp){NET.inT+=1;const k=inp.x+','+inp.y;if(k===NET.lastIn&&NET.inT<6)return;NET.inT=0;NET.lastIn=k;NET.host&&NET.host.send({t:'i',x:inp.x,y:inp.y});}

// Il mondo "visto" dall'ospite: ricostruito dalle fotografie, con movimenti ammorbiditi.
function newView(m){const V={guest:true,net:true,wave:m.wave,dur:m.dur,t:0,over:null,events:[],enemies:[],projs:[],eprojs:[],pickups:[],pending:[],structs:[],emap:new Map(),
  P:m.roster.map((r,i)=>{const run=r.slot===NET.slot?GAME.run:{charId:r.charId,ch:CHARS[r.charId],gold:0,xp:0,level:0,bag:0,cratesPending:0};
   return {i,slot:r.slot,run,x:ARENA.w/2,y:ARENA.h/2,tx:null,ty:null,hp:1,maxhp:1,face:1,moving:false,iframes:0,dead:false,charge:false,moveT:0,walkT:0,speed:300,
    hasCharge:hasFlag({ch:CHARS[r.charId]},'charge'),weapons:r.weapons.map((w,k)=>({d:WEAPONS[w.id],tier:w.tier,i:k,ang:0,anim:0,animDur:.2,att:null,reach:0}))};})};
 V.me=V.P.find(P=>P.slot===NET.slot);return V;}
function applySnapshot(V,s){V.t=s.tt;V.dur=s.dur;
 for(const a of s.P){const P=V.P.find(P=>P.slot===a[0]);if(!P)continue;
  if(!P.seen){P.seen=true;P.x=a[1];P.y=a[2];}
  // il proprio personaggio si muove già sul PC dell'ospite: qui si corregge solo la piccola differenza
  if(P===V.me){const d=hyp(a[1]-P.x,a[2]-P.y);if(d>90||P.dead){P.x=a[1];P.y=a[2];}else{P.x+=(a[1]-P.x)*.12;P.y+=(a[2]-P.y)*.12;}}
  else{P.tx=a[1];P.ty=a[2];}
  P.hp=a[3];P.maxhp=a[4];if(P!==V.me)P.face=a[5];if(P!==V.me)P.moving=!!a[6];P.iframes=a[7]?.2:0;P.dead=!!a[8];P.charge=!!a[9];P.moveT=a[10];if(P!==V.me)P.walkT=a[11];P.speed=a[12];
  if(P!==V.me){P.run.gold=a[13];P.run.xp=a[14];P.run.level=a[15];P.run.bag=a[16];P.run.cratesPending=a[17];}
  else{P.hud={gold:a[13],xp:a[14],level:a[15],bag:a[16],crates:a[17]};}
  a[18].forEach((w,k)=>{const ws=P.weapons[k];if(!ws)return;ws.ang=w[0]/100;ws.anim=w[1]/1000;ws.animDur=w[2]/1000||.2;ws.att=ATT[w[3]]||null;ws.reach=w[4];});}
 const seen=new Set();
 for(const a of s.E){let e=V.emap.get(a[0]);const type=ETYPES[a[1]];
  if(!e){e={id:a[0],type,d:ENEMIES[type],x:a[2],y:a[3],r:ENEMIES[type].r};V.emap.set(a[0],e);}
  e.tx=a[2];e.ty=a[3];e.hp=a[4];e.maxhp=a[5];e.face=a[6];e.state=STATE_NAME[a[7]];e.anim=a[8];if(a[9])e.flash=.1;e.burn=!!a[10];e.buff=a[11];seen.add(a[0]);}
 for(const id of [...V.emap.keys()])if(!seen.has(id))V.emap.delete(id);
 V.enemies=[...V.emap.values()];
 V.projs=s.Q.map(a=>({x:a[0],y:a[1],vx:a[2],vy:a[3],look:LOOKS[a[4]],lob:a[5]>=0,h:Math.max(0,a[5]),gold:!!a[6]}));
 V.eprojs=s.B.map(a=>({x:a[0],y:a[1],vx:a[2],vy:a[3]}));
 V.pickups=s.K.map(a=>({kind:['gold','crate','bread'][a[0]],x:a[1],y:a[2]}));
 V.pending=s.T.map(a=>({type:ETYPES[a[0]],x:a[1],y:a[2]}));
 V.structs=s.S.map(a=>({type:a[0]?'trabucco':'balestra',x:a[1],y:a[2],ang:a[3]/100,anim:a[4]}));
 for(const e of s.V)V.events.push(e);}
// Tra una fotografia e l'altra: l'ospite muove subito il proprio personaggio (così non sente ritardo),
// gli altri e i nemici scivolano verso l'ultima posizione ricevuta; i proiettili proseguono in linea retta.
function advanceView(V,dt,inp){const k=1-Math.exp(-dt*14);V.t+=dt;
 for(const P of V.P){if(P===V.me){if(!P.dead){let mx=inp.x,my=inp.y;const l=Math.hypot(mx,my);if(l>1){mx/=l;my/=l;}
    P.x=clamp(P.x+mx*P.speed*dt,20,ARENA.w-20);P.y=clamp(P.y+my*P.speed*dt,24,ARENA.h-14);P.moving=l>.1;if(mx>.1)P.face=1;else if(mx<-.1)P.face=-1;if(P.moving)P.walkT+=dt;}}
  else if(P.tx!=null){P.x+=(P.tx-P.x)*k;P.y+=(P.ty-P.y)*k;if(P.moving)P.walkT+=dt;}
  for(const ws of P.weapons)if(ws.anim>0)ws.anim-=dt;}
 for(const e of V.enemies){e.x+=(e.tx-e.x)*k;e.y+=(e.ty-e.y)*k;if(e.flash>0)e.flash-=dt;}
 for(const q of V.projs)if(!q.lob){q.x+=q.vx*dt;q.y+=q.vy*dt;}
 for(const q of V.eprojs){q.x+=q.vx*dt;q.y+=q.vy*dt;}}

// ---------- uscita ----------
function netLeave(){if(NET.role==='host')for(const L of NET.links)L.send({t:'bye'});else if(NET.host)NET.host.send({t:'bye'});netReset();}
// Controllo periodico: chi non si fa sentire da 12 secondi è considerato scollegato.
setInterval(()=>{if(!netOn())return;const now=performance.now();
 if(NET.role==='host'){for(const L of [...NET.links])if(now-L.lastSeen>12000)hostDrop(L);}
 else if(NET.host){NET.host.send({t:'ping'});if(now-NET.host.lastSeen>12000&&NET.phase!=='joining')guestLost('Il collegamento con chi ospita si è interrotto.');}},2000);
addEventListener('beforeunload',()=>{if(netOn())netLeave();});
