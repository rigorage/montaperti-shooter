'use strict';
// ===================== utilità comuni (simulazione e disegno) =====================
const TAU=Math.PI*2;
const clamp=(v,a,b)=>v<a?a:v>b?b:v;
const lerp=(a,b,t)=>a+(b-a)*t;
const hyp=Math.hypot;
function angDiff(a,b){let d=(b-a)%TAU;if(d>Math.PI)d-=TAU;if(d<-Math.PI)d+=TAU;return d;}

// Numeri casuali con seme: la stessa partita si può rigiocare uguale.
function makeRng(seed){let s=(Math.abs(Math.floor(seed))%2147483646)+1;
 const r={next(){s=(s*16807)%2147483647;return (s-1)/2147483646;},
  range(a,b){return a+r.next()*(b-a);},
  int(a,b){return Math.floor(a+r.next()*(b-a+1));},
  pick(arr){return arr[Math.floor(r.next()*arr.length)];},
  chance(p){return r.next()<p;}};
 return r;}

// valore per qualità: un numero vale per tutte, un elenco ne ha uno per qualità I-IV
const byTier=(v,t)=>Array.isArray(v)?v[Math.min(t,v.length-1)]:v;
const TIER_NAMES=['I','II','III','IV'];
const RARITY=['comune','non comune','rara','leggendaria'];
const RARITY_COL=['#cfc6b0','#6fa8dc','#b07ce0','#e8513a'];
