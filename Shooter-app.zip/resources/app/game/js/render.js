'use strict';
// ===================== disegno dell'arena =====================
const R={cv:null,ctx:null,dpr:1,zoom:1,cw:0,ch:0,camX:0,camY:0,bg:null,BGM:320,
 texts:[],corpses:[],rings:[],swings:[],parts:[],shake:0,hurtFlash:0,t:0,banner:null};
const US=1.5;   // grandezza dei soldati rispetto ai disegni di Montaperti
const WS=1.35;  // grandezza delle armi in mano

function initRender(cv){R.cv=cv;R.ctx=cv.getContext('2d');resizeRender();addEventListener('resize',resizeRender);R.bg=buildBg();}
function resizeRender(){R.dpr=Math.min(2,window.devicePixelRatio||1);R.cw=innerWidth;R.ch=innerHeight;
 R.cv.width=Math.round(R.cw*R.dpr);R.cv.height=Math.round(R.ch*R.dpr);R.cv.style.width=R.cw+'px';R.cv.style.height=R.ch+'px';
 R.zoom=Math.min(R.cw/760,R.ch/700);}

// ---------- prato, strada, campi e boschi: disegnati una volta sola ----------
function buildBg(){const M=R.BGM,S=1.5,w=ARENA.w+M*2,h=ARENA.h+M*2;const c=mkCanvas(w*S,h*S),g=c.getContext('2d');g.scale(S,S);g.translate(M,M);
 const rnd=makeRng(1260);const rr2=(a,b)=>rnd.range(a,b);
 g.fillStyle='#55683a';g.fillRect(-M,-M,w,h);
 // fuori dall'arena: bosco fitto come nella mappa di Montaperti
 for(let i=0;i<2600;i++){const x=rr2(-M,ARENA.w+M),y=rr2(-M,ARENA.h+M);if(x>-20&&x<ARENA.w+20&&y>-20&&y<ARENA.h+20)continue;
  ell(g,x,y,rr2(9,15),rr2(8,13));g.fillStyle=rnd.chance(.5)?'#2f4a2a':'#36522e';g.fill();}
 // il prato
 const grd=g.createLinearGradient(0,0,ARENA.w,ARENA.h);grd.addColorStop(0,'#a7b46a');grd.addColorStop(1,'#9aaa5c');
 g.fillStyle=grd;g.fillRect(0,0,ARENA.w,ARENA.h);
 for(let i=0;i<70;i++){ell(g,rr2(0,ARENA.w),rr2(0,ARENA.h),rr2(40,140),rr2(25,80),rr2(0,3));g.fillStyle=rnd.chance(.5)?'rgba(120,140,60,.18)':'rgba(190,190,110,.14)';g.fill();}
 // campi coltivati agli angoli
 for(const [x,y,fw,fh,a] of [[60,70,190,120,.08],[ARENA.w-260,ARENA.h-200,200,130,-.06],[ARENA.w-230,90,160,110,.12],[90,ARENA.h-190,170,120,-.1]]){
  g.save();g.translate(x+fw/2,y+fh/2);g.rotate(a);rr(g,-fw/2,-fh/2,fw,fh,8);g.fillStyle='rgba(214,181,88,.55)';g.fill();g.clip();
  g.strokeStyle='rgba(150,120,50,.35)';g.lineWidth=3;for(let k=-fw/2;k<fw/2;k+=9){g.beginPath();g.moveTo(k,-fh/2);g.lineTo(k,fh/2);g.stroke();}g.restore();}
 // la strada di terra battuta
 g.lineCap='round';const road=[[-M,ARENA.h*.62],[ARENA.w*.25,ARENA.h*.55],[ARENA.w*.5,ARENA.h*.6],[ARENA.w*.75,ARENA.h*.45],[ARENA.w+M,ARENA.h*.38]];
 for(const [col,lw] of [['rgba(140,110,60,.35)',30],['#d8c79a',24],['rgba(235,220,180,.5)',8]]){g.strokeStyle=col;g.lineWidth=lw;g.beginPath();g.moveTo(...road[0]);
  for(let i=1;i<road.length-1;i++){const mx=(road[i][0]+road[i+1][0])/2,my=(road[i][1]+road[i+1][1])/2;g.quadraticCurveTo(road[i][0],road[i][1],mx,my);}g.lineTo(...road[road.length-1]);g.stroke();}
 // ciuffi d'erba e fiori
 g.lineWidth=1.3;for(let i=0;i<900;i++){const x=rr2(0,ARENA.w),y=rr2(0,ARENA.h);g.strokeStyle=rnd.chance(.5)?'#7d8f48':'#8c9c52';
  g.beginPath();g.moveTo(x,y);g.lineTo(x-2,y-5);g.moveTo(x,y);g.lineTo(x+1,y-6);g.moveTo(x,y);g.lineTo(x+3,y-4);g.stroke();}
 for(let i=0;i<160;i++){ell(g,rr2(0,ARENA.w),rr2(0,ARENA.h),1.4,1.4);g.fillStyle=rnd.pick(['#f0ece0','#e8d040','#d86a6a','#c8b0e8']);g.fill();}
 // alberelli sparsi dentro l'arena (solo decorazione, ai bordi)
 for(let i=0;i<14;i++){const side=i%4,x=side===0?rr2(15,60):side===1?rr2(ARENA.w-60,ARENA.w-15):rr2(40,ARENA.w-40),y=side===2?rr2(15,50):side===3?rr2(ARENA.h-50,ARENA.h-15):rr2(40,ARENA.h-40);
  ell(g,x+4,y+3,13,5);g.fillStyle='rgba(25,30,10,.3)';g.fill();ell(g,x,y-6,11,10);g.fillStyle='#3f5e30';g.fill();ell(g,x-3,y-9,5,4);g.fillStyle='#55753e';g.fill();}
 // palizzata sul bordo
 g.fillStyle='rgba(25,30,10,.25)';g.fillRect(0,0,ARENA.w,10);g.fillRect(0,0,10,ARENA.h);
 for(const [x0,y0,x1,y1] of [[0,0,ARENA.w,0],[0,ARENA.h,ARENA.w,ARENA.h],[0,0,0,ARENA.h],[ARENA.w,0,ARENA.w,ARENA.h]]){
  const L=hyp(x1-x0,y1-y0),n=Math.floor(L/14);g.strokeStyle='#5c3e22';g.lineWidth=3;g.beginPath();g.moveTo(x0,y0-6);g.lineTo(x1,y1-6);g.stroke();
  for(let i=0;i<=n;i++){const x=x0+(x1-x0)*i/n,y=y0+(y1-y0)*i/n;g.fillStyle='#7a5430';g.fillRect(x-2.5,y-14,5,15);g.fillStyle='#9a7448';g.beginPath();g.moveTo(x-2.5,y-14);g.lineTo(x,y-18);g.lineTo(x+2.5,y-14);g.fill();}}
 return c;}

// ---------- eventi della simulazione → effetti visivi e suoni ----------
function consumeEvents(W){for(const ev of W.events){switch(ev.k){
 case 'dmg':R.texts.push({x:ev.x+(Math.random()-.5)*14,y:ev.y,t:0,txt:String(ev.v),col:ev.crit?'#ffd84a':ev.burn?'#ff9a4a':'#fffaf0',big:ev.crit});
  if(!ev.burn)sfx(ev.crit?'crit':'hit');break;
 case 'death':{const e={x:ev.x,y:ev.y,d:ENEMIES[ev.type],face:ev.face};if(!e.d.art.boss&&!ev.quiet)R.corpses.push({x:e.x,y:e.y,fac:e.d.art.fac,big:isHorse(e.d.art.type),s:e.d.art.s,flip:e.face<0,t:0});
  for(let i=0;i<(ev.quiet?4:7);i++)R.parts.push({x:e.x,y:e.y-10,vx:(Math.random()-.5)*160,vy:-Math.random()*140,t:0,life:.5,col:'#c8b890',r:2.5});
  if(!ev.quiet)sfx('death');if(e.d.boss){R.shake=.6;sfx('expl');}break;}
 case 'expl':R.rings.push({x:ev.x,y:ev.y,r:ev.r,t:0,life:.35,fill:'rgba(244,119,32,',line:'#3d2518'});R.shake=Math.max(R.shake,.12);sfx('expl');break;
 case 'swing':R.swings.push({...ev,t:0,life:.18});break;
 case 'hurt':{const mine=ev.pl==null||ev.pl===R.meI;if(mine){R.hurtFlash=.25;R.shake=Math.max(R.shake,.15);sfx('hurt');}R.texts.push({x:ev.x,y:ev.y-40,t:0,txt:'-'+ev.v,col:'#ff5a4a',big:mine});break;}
 case 'pdead':R.texts.push({x:ev.x,y:ev.y-50,t:0,txt:'caduto!',col:'#ff5a4a',big:true});if(ev.pl===R.meI){R.shake=.4;sfx('hurt');}break;
 case 'text':R.texts.push({x:ev.x,y:ev.y,t:0,txt:ev.t,col:ev.col||'#fff'});break;
 case 'gold':R.texts.push({x:ev.x,y:ev.y,t:0,txt:'+'+ev.v+' ⚜',col:'#f0c040'});break;
 case 'coin':R.parts.push({x:ev.x,y:ev.y,vx:0,vy:-40,t:0,life:.25,col:'#ffe27a',r:2});if(ev.pl==null||ev.pl===R.meI)sfx('coin');break;
 case 'aura':R.rings.push({x:ev.x,y:ev.y,r:ev.r,t:0,life:.5,line:ev.col,thin:1});break;
 case 'heal':for(let i=0;i<3;i++)R.parts.push({x:ev.x+(Math.random()-.5)*16,y:ev.y-14,vx:0,vy:-50,t:0,life:.6,col:'#7fe07a',r:2,plus:1});break;
 case 'regen':R.parts.push({x:ev.x+(Math.random()-.5)*12,y:ev.y-20,vx:0,vy:-40,t:0,life:.6,col:'#7fe07a',r:2,plus:1});break;
 case 'charge':R.texts.push({x:ev.x,y:ev.y-52,t:0,txt:'Carica!',col:'#ffd84a'});sfx('crit');break;
 case 'shot':sfx(ev.look==='pignatta'?'lob':'shot');break;
 case 'waveEnd':sfx('wave');break;}}
 W.events.length=0;
 if(R.texts.length>140)R.texts.splice(0,R.texts.length-140);
 if(R.corpses.length>90)R.corpses.splice(0,R.corpses.length-90);
 if(R.parts.length>300)R.parts.splice(0,R.parts.length-300);}

// ---------- disegno di un fotogramma ----------
function render(W,dt){const g=R.ctx,z=R.zoom;R.t+=dt;R.dt=dt;const me=W?(W.me||W.P[0]):null;R.meI=me?me.i:0;
 if(W)consumeEvents(W);
 g.setTransform(R.dpr,0,0,R.dpr,0,0);g.fillStyle='#3b4a2c';g.fillRect(0,0,R.cw,R.ch);
 if(!W){const k=Math.max(R.cw/R.bg.width,R.ch/R.bg.height)*1.15;g.drawImage(R.bg,(R.cw-R.bg.width*k)/2+Math.sin(R.t*.05)*30,(R.ch-R.bg.height*k)/2,R.bg.width*k,R.bg.height*k);return;}
 const vw=R.cw/z,vh=R.ch/z,M=R.BGM;
 const cx=vw>=ARENA.w+M*2?ARENA.w/2:clamp(me.x,vw/2-M,ARENA.w+M-vw/2),cy=vh>=ARENA.h+M*2?ARENA.h/2:clamp(me.y,vh/2-M,ARENA.h+M-vh/2);
 R.camX+=(cx-R.camX)*(R.camX?Math.min(1,dt*8):1);R.camY+=(cy-R.camY)*(R.camY?Math.min(1,dt*8):1);
 let sx=0,sy=0;if(R.shake>0){R.shake-=dt;const k=R.shake*16;sx=(Math.random()-.5)*k;sy=(Math.random()-.5)*k;}
 g.setTransform(R.dpr*z,0,0,R.dpr*z,R.dpr*(R.cw/2+sx),R.dpr*(R.ch/2+sy));g.translate(-R.camX,-R.camY);
 g.drawImage(R.bg,-M,-M,ARENA.w+M*2,ARENA.h+M*2);
 // avvisi di comparsa
 for(const q of W.pending){const a=.5+.5*Math.sin(R.t*14);g.save();g.translate(q.x,q.y);g.strokeStyle=`rgba(150,20,15,${.55+.4*a})`;g.lineWidth=3.2;g.lineCap='round';
  const s=ENEMIES[q.type].boss?18:7;g.beginPath();g.moveTo(-s,-s*.7);g.lineTo(s,s*.7);g.moveTo(s,-s*.7);g.lineTo(-s,s*.7);g.stroke();g.restore();}
 // caduti
 for(const d of R.corpses){d.t+=dt;const a=Math.max(0,1-d.t/6)*.8;if(a<=0)continue;g.save();g.globalAlpha=a;g.translate(d.x,d.y);g.scale((d.flip?-1:1)*US*d.s,US*d.s);const f=FAC[d.fac];
  ell(g,0,0,d.big?12:7,3);g.fillStyle='rgba(30,30,10,.3)';g.fill();if(d.big){ell(g,0,-3,11,4);g.fillStyle=f.horse;g.fill();}
  g.rotate(-1.4);rr(g,-4,-9,8,10,3);g.fillStyle=f.tunic;g.fill();g.restore();}
 R.corpses=R.corpses.filter(d=>d.t<6);
 // raccoglibili
 for(const k of W.pickups){if(k.kind==='gold')drawCoin(g,k.x,k.y-3,1.25,R.t+k.x*.01);else if(k.kind==='crate')drawCrate(g,k.x,k.y,1.1);else drawBread(g,k.x,k.y,1.2);}
 // costruzioni, nemici e giocatore, dal più lontano al più vicino
 const list=[];for(const e of W.enemies)if(!e.dead)list.push(e);for(const o of W.structs)list.push(o);for(const P of W.P)list.push(P);list.sort((a,b)=>a.y-b.y);
 for(const o of list){if(o.run)drawPlayer(g,W,o,o===me);else if(o.d)drawEnemy(g,o);else{g.save();g.translate(o.x,o.y);g.scale(US*.85,US*.85);drawStructArt(g,o.type,o.ang,o.anim);g.restore();}}
 // armi
 for(const P of W.P)if(!P.dead)for(const ws of P.weapons)drawWeapon(g,P,ws,P.run.ch.fac);
 // colpi di fendente
 for(const s of R.swings){s.t+=dt;const u=s.t/s.life;if(u>=1)continue;g.save();g.globalAlpha=(1-u)*.55;g.strokeStyle=s.fire?'#f47720':'#fffaf0';g.lineWidth=5*(1-u)+1;g.lineCap='round';
  g.beginPath();g.arc(s.x,s.y,s.r*.85,s.a-1.1+u*.3,s.a+1.1-u*.3);g.stroke();g.restore();}
 R.swings=R.swings.filter(s=>s.t<s.life);
 // proiettili
 for(const q of W.projs){g.save();
  if(q.lob){ell(g,q.x,q.y,5,2);g.fillStyle='rgba(25,30,10,.35)';g.fill();g.translate(q.x,q.y-q.h);g.rotate(R.t*8);
   if(q.look==='pignatta'){g.scale(1.1,1.1);drawWeaponArt(g,'pignatta',0,0);}else{ell(g,0,0,4.5,4.5);g.fillStyle='#8a8378';g.fill();g.strokeStyle='#3a342c';g.lineWidth=1;g.stroke();}}
  else{g.translate(q.x,q.y);g.rotate(Math.atan2(q.vy,q.vx));
   if(q.look==='sasso'){ell(g,0,0,3.4,3.4);g.fillStyle='#8a8378';g.fill();g.strokeStyle='#3a342c';g.lineWidth=1;g.stroke();}
   else{g.scale(1.5,1.5);drawBoltArt(g,false,q.gold);}}
  g.restore();}
 for(const q of W.eprojs){ell(g,q.x,q.y,6,6);g.fillStyle='#2a0a08';g.fill();ell(g,q.x,q.y,4.6,4.6);g.fillStyle='#b8321e';g.fill();ell(g,q.x-1.4,q.y-1.4,1.6,1.6);g.fillStyle='#ff9a6a';g.fill();}
 // anelli (esplosioni, aure)
 for(const r of R.rings){r.t+=dt;const u=r.t/r.life;if(u>=1)continue;g.save();
  if(r.fill){ell(g,r.x,r.y,r.r*(.4+.6*u),r.r*(.4+.6*u)*.75);g.fillStyle=r.fill+(.5*(1-u))+')';g.fill();g.strokeStyle=r.line;g.globalAlpha=1-u;g.lineWidth=2;g.stroke();
   if(u<.5)for(let k=0;k<5;k++){const a=k/5*TAU+r.x;flame(g,r.x+Math.cos(a)*r.r*.5*u*2,r.y+Math.sin(a)*r.r*.35*u*2,.9*(1-u));}}
  else{g.globalAlpha=(1-u)*.8;g.strokeStyle=r.line;g.lineWidth=r.thin?2:3;ell(g,r.x,r.y,r.r*u,r.r*u*.7);g.stroke();}
  g.restore();}
 R.rings=R.rings.filter(r=>r.t<r.life);
 // particelle
 for(const p of R.parts){p.t+=dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=p.plus?0:420*dt;const a=1-p.t/p.life;if(a<=0)continue;g.globalAlpha=a;g.fillStyle=p.col;
  if(p.plus){g.fillRect(p.x-p.r*1.5,p.y-.6,p.r*3,1.2*p.r/2+.6);g.fillRect(p.x-.6,p.y-p.r*1.5,1.2*p.r/2+.6,p.r*3);}else{ell(g,p.x,p.y,p.r,p.r);g.fill();}}
 g.globalAlpha=1;R.parts=R.parts.filter(p=>p.t<p.life);
 // numeri
 g.textAlign='center';g.lineJoin='round';
 for(const t of R.texts){t.t+=dt;const life=t.big?.9:.7,u=t.t/life;if(u>=1)continue;const y=t.y-u*26,s=(t.big?17:13)*(u<.15?1+(.15-u)*3:1);
  g.globalAlpha=u>.6?(1-u)/.4:1;g.font=`800 ${s}px system-ui,"Segoe UI",sans-serif`;g.strokeStyle='#2a1d12';g.lineWidth=3.2;g.strokeText(t.txt,t.x,y);g.fillStyle=t.col;g.fillText(t.txt,t.x,y);}
 g.globalAlpha=1;R.texts=R.texts.filter(t=>t.t<(t.big?.9:.7));
 // interfaccia sopra
 g.setTransform(R.dpr,0,0,R.dpr,0,0);
 if(R.hurtFlash>0){R.hurtFlash-=dt;const v=g.createRadialGradient(R.cw/2,R.ch/2,R.ch*.3,R.cw/2,R.ch/2,R.ch*.8);v.addColorStop(0,'rgba(180,20,10,0)');v.addColorStop(1,`rgba(180,20,10,${R.hurtFlash*1.6})`);g.fillStyle=v;g.fillRect(0,0,R.cw,R.ch);}
 drawHud(g,W,me);}

function drawEnemy(g,e){const A=e.d.art,sc=US*A.s;
 if(A.boss){g.save();g.translate(e.x,e.y);g.scale(sc*(e.face<0?-1:1),sc);drawCarrArt(g,R.t,e.flash>0);g.restore();
  if(e.burn)flame(g,e.x,e.y-60,1.2);return;}
 let pose='i';if(e.state==='aim')pose='b';else if(e.state==='dash'||e.state==='shoot')pose='a';else pose='w'+(Math.floor(e.anim*2.2)%4);
 const flip=e.face<0,spr=unitSpr(A.fac,A.type,pose,flip);const w=84*sc,h=64*sc,x=e.x-42*sc,y=e.y-54*sc;
 if(e.buff){ell(g,e.x,e.y,e.r*1.1,e.r*.45);g.strokeStyle='rgba(224,176,48,.8)';g.lineWidth=2;g.stroke();}
 g.drawImage(spr,x,y,w,h);
 if(e.flash>0){g.globalAlpha=Math.min(1,e.flash*10);g.drawImage(whiteSpr(spr,A.fac+A.type+pose+flip),x,y,w,h);g.globalAlpha=1;}
 if(e.burn)flame(g,e.x+(flip?3:-3),e.y-30*A.s*1.1,.9);
 if(e.d.elite||e.hp<e.maxhp&&e.d.hpW>=4){const bw=e.d.elite?44:24,by=e.y-(isHorse(A.type)?40:30)*sc/US*1.15-8;
  g.fillStyle='rgba(30,20,10,.75)';g.fillRect(e.x-bw/2-1,by-1,bw+2,5);g.fillStyle=e.d.elite?'#d9a520':'#c8302c';g.fillRect(e.x-bw/2,by,bw*Math.max(0,e.hp/e.maxhp),3);}}
function drawPlayer(g,W,p,isMe){const ch=p.run.ch;const pose=p.moving?'w'+(Math.floor(p.walkT*9)%4):'i';const flip=p.face<0;
 if(W.P.length>1){ell(g,p.x,p.y+1,17,6);g.strokeStyle=PLAYER_COL[p.slot??p.i];g.lineWidth=isMe?3:2;g.stroke();
  g.font='800 11px system-ui,sans-serif';g.textAlign='center';g.lineWidth=3;g.strokeStyle='#2a1d12';g.strokeText('G'+((p.slot??p.i)+1),p.x,p.y+18);g.fillStyle=PLAYER_COL[p.slot??p.i];g.fillText('G'+((p.slot??p.i)+1),p.x,p.y+18);}
 if(p.dead){g.save();g.globalAlpha=.5;g.translate(p.x,p.y);g.rotate(-1.4);g.scale(US,US);rr(g,-4,-9,8,10,3);g.fillStyle=FAC[ch.fac].tunic;g.fill();g.restore();return;}
 const spr=unitSpr(ch.fac,ch.art,pose,flip),sc=US*1.05,x=p.x-42*sc,y=p.y-54*sc,w=84*sc,h=64*sc;
 if(p.charge){ell(g,p.x,p.y,22,8);g.strokeStyle=`rgba(255,216,74,${.5+.3*Math.sin(R.t*12)})`;g.lineWidth=2.5;g.stroke();}
 if(p.iframes>0&&Math.floor(R.t*20)%2)g.globalAlpha=.45;
 g.drawImage(spr,x,y,w,h);g.globalAlpha=1;}
function drawWeapon(g,P,ws,fac){const [wx,wy]=weaponPos(P,ws);let ang=ws.ang,off=0;const u=ws.anim>0?1-ws.anim/ws.animDur:0;
 if(ws.anim>0){if(ws.att==='thrust')off=Math.sin(u*Math.PI)*Math.max(0,ws.reach-20);else if(ws.att==='sweep'){ang+=-1.1+u*2.2;off=10;}else off=-4*(1-u);}
 g.save();g.translate(wx+Math.cos(ang)*off,wy+Math.sin(ang)*off);g.rotate(ang);if(Math.cos(ang)<0)g.scale(1,-1);g.scale(WS,WS);
 drawWeaponArt(g,ws.d.id,fac,ws.tier);g.restore();}

// ---------- barre e numeri in alto ----------
function drawHud(g,W,p){const run=p.run,hud=p.hud||run,maxhp=p.maxhp||stats(run,W.t).maxhp,crates=hud.crates??hud.cratesPending;const x0=16,y0=14;
 const panel=(x,y,w,h)=>{rr(g,x,y,w,h,8);g.fillStyle='rgba(239,230,212,.92)';g.fill();g.strokeStyle='#8a6a3a';g.lineWidth=2;g.stroke();};
 g.font='800 15px system-ui,"Segoe UI",sans-serif';g.textAlign='left';g.textBaseline='middle';
 panel(x0,y0,250,p.hasCharge?104:88);
 const bar=(y,frac,col,txt)=>{rr(g,x0+10,y,230,20,5);g.fillStyle='#3a2a1a';g.fill();rr(g,x0+12,y+2,226*clamp(frac,0,1),16,4);g.fillStyle=col;g.fill();
  g.fillStyle='#fffaf0';g.strokeStyle='#2a1d12';g.lineWidth=3;g.strokeText(txt,x0+18,y+10.5);g.fillText(txt,x0+18,y+10.5);};
 bar(y0+10,p.hp/maxhp,'#c8302c',p.dead?'caduto: torni alla prossima ondata':Math.max(0,Math.ceil(p.hp))+' / '+maxhp);
 bar(y0+34,hud.xp/xpNeeded(hud.level),'#6a9a3a','Livello '+hud.level);
 drawCoin(g,x0+22,y0+70,1.8,0);g.fillStyle='#3a2a1a';g.fillText(String(hud.gold),x0+36,y0+70);
 if(hud.bag>0){g.fillStyle='#7a5a2a';g.font='700 13px system-ui,sans-serif';g.fillText('borsa +'+hud.bag,x0+100,y0+70);}
 if(crates>0){drawCrate(g,x0+214,y0+79,.8);g.fillStyle='#3a2a1a';g.font='800 13px system-ui,sans-serif';g.fillText('×'+crates,x0+226,y0+70);}
 // compagni: una riga ciascuno con la vita
 let oy=y0+(p.hasCharge?112:96);for(const o of W.P){if(o===p)continue;const mh=o.maxhp||stats(o.run,W.t).maxhp;panel(x0,oy,250,26);
  g.font='800 12px system-ui,sans-serif';g.fillStyle=PLAYER_COL[o.slot??o.i];g.fillText('G'+((o.slot??o.i)+1),x0+10,oy+13);g.fillStyle='#3a2a1a';g.fillText(o.run.ch.city,x0+34,oy+13);
  rr(g,x0+100,oy+7,140,12,3);g.fillStyle='#3a2a1a';g.fill();if(!o.dead){rr(g,x0+101,oy+8,138*clamp(o.hp/mh,0,1),10,3);g.fillStyle='#c8302c';g.fill();}else{g.fillStyle='#efe6d4';g.font='700 10px system-ui,sans-serif';g.fillText('caduto',x0+150,oy+13);}
  oy+=30;}
 g.font='800 15px system-ui,"Segoe UI",sans-serif';
 if(p.hasCharge){g.font='700 12px system-ui,sans-serif';g.fillStyle='#3a2a1a';g.fillText('Carica',x0+12,y0+92);rr(g,x0+64,y0+86,176,10,3);g.fillStyle='#3a2a1a';g.fill();
  rr(g,x0+65,y0+87,174*Math.min(1,p.moveT),8,3);g.fillStyle=p.charge?'#ffd84a':'#b89a4a';g.fill();}
 // ondata e tempo
 g.textAlign='center';const left=Math.max(0,Math.ceil(W.dur-W.t));const tx=R.cw<720?R.cw-60:R.cw/2;
 g.font='800 15px system-ui,sans-serif';g.lineWidth=4;g.strokeStyle='#2a1d12';g.fillStyle='#efe6d4';
 g.strokeText('ONDATA '+W.wave+' / '+LAST_WAVE,tx,22);g.fillText('ONDATA '+W.wave+' / '+LAST_WAVE,tx,22);
 g.font='900 38px system-ui,sans-serif';g.lineWidth=6;g.fillStyle=left<=5&&!W.over?'#ff6a4a':'#fffaf0';
 g.strokeText(String(left),tx,54);g.fillText(String(left),tx,54);
 const boss=W.enemies.find(e=>e.d.boss&&!e.dead);
 if(boss){const bw=Math.min(520,R.cw-80),bx=R.cw/2-bw/2,by=R.cw<720?150:86;g.font='800 14px system-ui,sans-serif';g.lineWidth=4;g.strokeText(boss.d.n,R.cw/2,by-8);g.fillStyle='#efe6d4';g.fillText(boss.d.n,R.cw/2,by-8);
  rr(g,bx,by,bw,14,4);g.fillStyle='#2a1d12';g.fill();rr(g,bx+2,by+2,(bw-4)*Math.max(0,boss.hp/boss.maxhp),10,3);g.fillStyle='#d9a520';g.fill();}
 if(R.banner){R.banner.t+=R.dt||1/60;const a=Math.min(1,R.banner.t*4)*(R.banner.t>R.banner.life-.3?Math.max(0,(R.banner.life-R.banner.t)/.3):1);
  if(a>0){g.globalAlpha=a;g.font='900 44px system-ui,sans-serif';g.lineWidth=7;g.strokeStyle='#2a1d12';g.strokeText(R.banner.txt,R.cw/2,R.ch*.36);g.fillStyle=R.banner.col||'#ffd84a';g.fillText(R.banner.txt,R.cw/2,R.ch*.36);
   if(R.banner.sub){g.font='800 18px system-ui,sans-serif';g.lineWidth=4;g.strokeText(R.banner.sub,R.cw/2,R.ch*.36+40);g.fillStyle='#efe6d4';g.fillText(R.banner.sub,R.cw/2,R.ch*.36+40);}
   g.globalAlpha=1;}else if(R.banner.t>R.banner.life)R.banner=null;}
 g.textBaseline='alphabetic';}
function showBanner(txt,sub,col,life=1.6){R.banner={txt,sub,col,t:0,life};}
function resetFx(){R.texts=[];R.corpses=[];R.rings=[];R.swings=[];R.parts=[];R.shake=0;R.hurtFlash=0;R.camX=0;R.camY=0;}
