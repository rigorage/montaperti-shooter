'use strict';
// ===================== schermate (HTML sopra il disegno) =====================
const UI={root:null,tip:null,keyHandler:null};
function h(tag,cls,html){const e=document.createElement(tag);if(cls)e.className=cls;if(html!=null)e.innerHTML=html;return e;}
function initUI(){UI.root=document.getElementById('ui');UI.tip=document.getElementById('tip');
 addEventListener('mousemove',e=>{if(UI.tip.style.display==='block'){const x=Math.min(e.clientX+16,innerWidth-UI.tip.offsetWidth-8),y=Math.min(e.clientY+16,innerHeight-UI.tip.offsetHeight-8);UI.tip.style.left=x+'px';UI.tip.style.top=y+'px';}});}
function showUI(node,cls=''){UI.root.innerHTML='';UI.root.className='show '+cls;UI.root.appendChild(node);hideTip();UI.keyHandler=null;}
function hideUI(){UI.root.className='';UI.root.innerHTML='';hideTip();UI.keyHandler=null;}
function tipOn(el,fn){el.addEventListener('mouseenter',()=>{UI.tip.innerHTML='';UI.tip.appendChild(fn());UI.tip.style.display='block';});el.addEventListener('mouseleave',hideTip);}
function hideTip(){if(UI.tip)UI.tip.style.display='none';}
const canvasEl=c=>{const e=document.createElement('canvas');e.width=c.width;e.height=c.height;e.getContext('2d').drawImage(c,0,0);return e;};
const fmtN=v=>Math.round(v*100)/100;

// ---------- descrizione di un'arma o di un oggetto ----------
function fxList(lines){const ul=h('ul','fx');for(const l of lines)ul.appendChild(h('li',l.flag?'flag':l.good?'good':'bad',l.t));return ul;}
function weaponLines(run,id,tier){const d=WEAPONS[id],s=stats(run),st=calcWeaponStats(s,d,tier),out=[];
 const sc=Object.entries(d.sc).map(([k,c])=>`${Math.round(c*100)}% ${STATS[k].ic}`).join(' ');
 out.push({t:`Danno <b>${st.dmg}</b> <span class="dim">(${byTier(d.dmg,tier)} + ${sc})</span>`,good:true});
 out.push({t:`Colpo ogni <b>${fmtN(st.cd)} s</b> · Portata <b>${Math.round(st.range)}</b>`,good:true});
 out.push({t:`Critico <b>${Math.round(st.crit*100)}%</b> ×${d.cm}`,good:true});
 if(st.pierce)out.push({t:`Trapassa ${st.pierce} nemic${st.pierce>1?'i':'o'}`,good:true});
 if(st.expl)out.push({t:`Esplode (raggio ${st.expl})`,good:true});
 if(st.burn)out.push({t:`Incendia: ${st.burn.dmg} danni × ${st.burn.n}`,good:true});
 return out.concat(describeFx(d.fx,tier));}
function card(run,kind,id,tier,extra){const c=h('div','card t'+tier);
 const top=h('div','ctop');top.appendChild(canvasEl(kind==='w'?weaponIcon(id,run.ch.fac,tier,64):itemIcon(id,64)));
 const nm=h('div','cname');nm.appendChild(h('b','',kind==='w'?WEAPONS[id].n+' '+TIER_NAMES[tier]:ITEMS[id].n));
 nm.appendChild(h('span','rar',kind==='w'?'arma · '+WEAPONS[id].fam.map(f=>FAMILIES[f].ic+' '+f).join(', '):RARITY[tier]+(ITEMS[id].max?' · max '+ITEMS[id].max:'')));
 top.appendChild(nm);c.appendChild(top);
 c.appendChild(fxList(kind==='w'?weaponLines(run,id,tier):describeFx(ITEMS[id].fx,0)));
 if(kind==='i'&&ITEMS[id].d)c.appendChild(h('p','flav',ITEMS[id].d));
 if(extra)c.appendChild(extra);return c;}

// ---------- pannello statistiche ----------
function statsPanel(run){const s=stats(run),box=h('div','stats');box.appendChild(h('h3','','Statistiche'));
 const tb=h('table');
 for(const k of STAT_KEYS){const d=STATS[k],v=Math.round(s[k]*10)/10;if(d.sec&&!v)continue;const base=d.base||0;
  const tr=h('tr',(d.bad?v<0:v>base)?'good':v<base?'bad':'');tr.appendChild(h('td','ic',d.ic||'·'));tr.appendChild(h('td','',d.n));
  tr.appendChild(h('td','v',v+(d.pct?'%':'')+(k==='dodge'&&run.capsNow.dodge!=null&&s.dodge>=run.capsNow.dodge?' (max)':'')));tb.appendChild(tr);}
 box.appendChild(tb);return box;}

// ---------- menu iniziale ----------
function showMenu(onStart){const box=h('div','menu');let pick='firenze',danger=0;
 box.appendChild(h('h1','','Montaperti <span>Shooter</span>'));
 box.appendChild(h('p','sub','Venti ondate della Compagnia della Malaventura. Le tue armi colpiscono da sole: tu pensa a muoverti.'));
 const row=h('div','chars');
 for(const [id,ch] of Object.entries(CHARS)){const c=h('div','char'+(id===pick?' sel':''));c.dataset.id=id;
  c.appendChild(canvasEl(heroIcon(id,120)));c.appendChild(h('h2','',ch.n));c.appendChild(h('div','city',ch.city+' · '+ch.role));
  c.appendChild(fxList(describeFx(ch.fx)));
  const sw=h('div','start','Parte con: ');for(const w of ch.start){sw.appendChild(canvasEl(weaponIcon(w,ch.fac,0,28)));sw.appendChild(document.createTextNode(' '+WEAPONS[w].n));}c.appendChild(sw);
  c.onclick=()=>{pick=id;row.querySelectorAll('.char').forEach(x=>x.classList.toggle('sel',x.dataset.id===id));sfx('click');};
  c.ondblclick=()=>onStart(pick,danger);row.appendChild(c);}
 box.appendChild(row);
 const dg=h('div','danger');dg.appendChild(h('span','','Pericolo:'));
 DANGER.forEach((d,i)=>{const b=h('button',i===danger?'on':'',d.n);b.onclick=()=>{danger=i;dg.querySelectorAll('button').forEach((x,j)=>x.classList.toggle('on',j===i));sfx('click');};dg.appendChild(b);});
 box.appendChild(dg);
 const go=h('button','go','Inizia ▶');go.onclick=()=>onStart(pick,danger);box.appendChild(go);
 box.appendChild(h('p','keys','<b>WASD</b> o <b>frecce</b> per muoverti · <b>Esc</b> pausa · <b>M</b> audio sì/no · <b>F11</b> schermo intero<br><span class="dim">versione '+GAME_VERSION+'</span>'));
 showUI(box,'full');UI.keyHandler=e=>{if(e.key==='Enter')onStart(pick,danger);};}

// ---------- livello raggiunto ----------
function showLevelUp(run,done){const choices=levelChoices(run);const box=h('div','panel lvl');
 box.appendChild(h('h2','','Livello '+(run.level-run.levelsPending+1)+'!'+(run.levelsPending>1?` <span class="dim">(ancora ${run.levelsPending-1} dopo questo)</span>`:'')));
 box.appendChild(h('p','sub','Scegli un potenziamento. Vale per tutta la partita.'));
 const row=h('div','offers');
 choices.forEach((c,i)=>{const d=STATS[c.s],el=h('div','card up t'+c.tier);
  el.appendChild(h('div','bigic',d.ic));el.appendChild(h('b','',fmtStat(c.s,c.v)));el.appendChild(h('span','rar',RARITY[c.tier]));el.appendChild(h('span','keyhint',String(i+1)));
  el.onclick=()=>{applyUpgrade(run,c);sfx('level');done();};row.appendChild(el);});
 box.appendChild(row);const wrap=h('div','split');wrap.appendChild(box);wrap.appendChild(statsPanel(run));showUI(wrap);
 UI.keyHandler=e=>{const n=+e.key;if(n>=1&&n<=4){applyUpgrade(run,choices[n-1]);sfx('level');done();}};}

// ---------- bottino ----------
function showCrate(run,done){const id=openCrate(run);const box=h('div','panel crate');
 box.appendChild(h('h2','','Bottino!'));box.appendChild(h('p','sub','Hai trovato qualcosa fra le spoglie dei briganti.'));
 const btns=h('div','btns');const take=h('button','go','Prendi');const rec=h('button','','Ricicla (+'+recycleOf(run,ITEMS[id].val)+' ⚜)');
 take.onclick=()=>{takeItem(run,id);sfx('buy');done();};rec.onclick=()=>{recycleItem(run,id);sfx('coin');done();};
 btns.append(take,rec);box.appendChild(card(run,'i',id,ITEMS[id].t,btns));showUI(box);
 UI.keyHandler=e=>{if(e.key==='Enter'){takeItem(run,id);sfx('buy');done();}};}

// ---------- bottega ----------
function showShop(run,onGo){const box=h('div','shop');
 const draw=()=>{box.innerHTML='';const s=stats(run);
  const head=h('div','shead');head.appendChild(h('h2','','Bottega <span class="dim">· ondata '+run.wave+' superata</span>'));
  head.appendChild(h('div','gold','⚜ <b>'+run.gold+'</b> fiorini'+(run.bag?` <span class="dim">· borsa ${run.bag}</span>`:'')));
  const rp=rerollPrice(run),rb=h('button','','Rimescola · '+rp+' ⚜');rb.disabled=run.gold<rp;rb.onclick=()=>{if(reroll(run)){sfx('click');draw();}};head.appendChild(rb);box.appendChild(head);
  const offers=h('div','offers');
  run.shop.offers.forEach((o,i)=>{if(!o){offers.appendChild(h('div','card sold','venduto'));return;}
   const why=cantBuy(run,i),price=offerPrice(run,o),btns=h('div','btns');
   const b=h('button','buy',(o.kind==='w'&&run.weapons.length>=MAX_WEAPONS&&!why?'Compra e unisci · ':'Compra · ')+price+' ⚜');b.disabled=!!why;if(why)b.title=why;
   b.onclick=()=>{if(buy(run,i)){sfx('buy');draw();}};
   const lk=h('button','lock'+(run.shop.locked[i]?' on':''),run.shop.locked[i]?'🔒':'🔓');lk.title='Tieni questa offerta per il prossimo giro';lk.onclick=()=>{toggleLock(run,i);sfx('click');draw();};
   btns.append(b,lk);const c=card(run,o.kind,o.id,o.tier,btns);if(run.shop.locked[i])c.classList.add('locked');offers.appendChild(c);});
  box.appendChild(offers);
  const bottom=h('div','sbottom');const inv=h('div','inv');
  inv.appendChild(h('h3','','Armi <span class="dim">'+run.weapons.length+' / '+MAX_WEAPONS+'</span>'));
  const wrow=h('div','slots');
  for(let i=0;i<MAX_WEAPONS;i++){const w=run.weapons[i],sl=h('div','slot'+(w?' t'+w.tier:' empty'));
   if(w){sl.appendChild(canvasEl(weaponIcon(w.id,run.ch.fac,w.tier,52)));sl.appendChild(h('span','tier',TIER_NAMES[w.tier]));
    if(combineTarget(run,i)>=0)sl.appendChild(h('span','merge','unisci'));
    tipOn(sl,()=>card(run,'w',w.id,w.tier));
    sl.onclick=ev=>{ev.stopPropagation();weaponMenu(run,i,sl,draw);};}
   wrow.appendChild(sl);}
  inv.appendChild(wrow);
  const fams=Object.entries(familyCounts(run)).filter(([,n])=>n>=2);
  if(fams.length)inv.appendChild(h('div','fams',fams.map(([f,n])=>`${FAMILIES[f].ic} ${f} ×${n}: ${fmtStat(FAMILIES[f].s,FAMILIES[f].v[Math.min(n,6)-2])}`).join(' · ')));
  inv.appendChild(h('h3','','Oggetti'));const irow=h('div','items');
  for(const [id,n] of Object.entries(run.items)){if(!n)continue;const it=h('div','item t'+ITEMS[id].t);it.appendChild(canvasEl(itemIcon(id,40)));if(n>1)it.appendChild(h('span','cnt','×'+n));
   tipOn(it,()=>card(run,'i',id,ITEMS[id].t));irow.appendChild(it);}
  if(!Object.values(run.items).some(n=>n))irow.appendChild(h('span','dim','nessuno, per ora'));
  inv.appendChild(irow);bottom.appendChild(inv);bottom.appendChild(statsPanel(run));box.appendChild(bottom);
  const go=h('button','go big','Avanti: ondata '+(run.wave+1)+' ▶');go.onclick=onGo;box.appendChild(go);};
 draw();showUI(box,'full');UI.keyHandler=e=>{if(e.key==='Enter')onGo();if(e.key==='r'||e.key==='R'){if(reroll(run)){sfx('click');draw();}}};}
function weaponMenu(run,i,anchor,redraw){document.querySelectorAll('.wmenu').forEach(x=>x.remove());const w=run.weapons[i];const m=h('div','wmenu');
 const j=combineTarget(run,i);
 if(j>=0){const b=h('button','','Unisci → '+WEAPONS[w.id].n+' '+TIER_NAMES[w.tier+1]);b.onclick=()=>{combine(run,i);sfx('buy');redraw();};m.appendChild(b);}
 const s=h('button','','Ricicla (+'+recycleOf(run,weaponVal(w))+' ⚜)');s.disabled=run.weapons.length<=1;s.onclick=()=>{sellWeapon(run,i);sfx('coin');redraw();};m.appendChild(s);
 const c=h('button','dim','Annulla');c.onclick=()=>m.remove();m.appendChild(c);
 anchor.appendChild(m);setTimeout(()=>addEventListener('click',()=>m.remove(),{once:true}),0);}

// ---------- pausa e fine ----------
function showPause(G,onResume,onQuit){const box=h('div','panel pause');box.appendChild(h('h2','','Pausa'));
 const r=h('button','go','Riprendi');r.onclick=onResume;box.appendChild(r);
 const det=h('details','cheats');det.appendChild(h('summary','','Trucchi di prova'));
 const add=(t,fn)=>{const b=h('button','',t);b.onclick=()=>{fn();sfx('click');};det.appendChild(b);};
 add('Salta l\'ondata',()=>{if(G.W){G.W.t=G.W.dur;}onResume();});
 add('+100 fiorini',()=>{G.run.gold+=100;});
 add('+1 livello',()=>{addXp(G.run,xpNeeded(G.run.level)-G.run.xp);});
 add(G.W&&G.W.cheat.god?'Invincibile: sì':'Invincibile: no',()=>{G.W.cheat.god=!G.W.cheat.god;showPause(G,onResume,onQuit);});
 add('Vai all\'ondata 10',()=>{G.jumpTo=10;G.W.t=G.W.dur;onResume();});
 box.appendChild(det);box.appendChild(statsPanel(G.run));
 const q=h('button','dim','Abbandona la partita');q.onclick=onQuit;box.appendChild(q);showUI(box);
 UI.keyHandler=e=>{if(e.key==='Escape')onResume();};}
function showEnd(run,won,onAgain){const box=h('div','panel end');
 box.appendChild(h('h2','',won?'Vittoria!':'Sei caduto'));
 box.appendChild(h('p','sub',won?'Il Carroccio nero è distrutto e la Compagnia è in rotta.':'La Compagnia ti ha sopraffatto all\'ondata '+run.wave+'.'));
 box.appendChild(h('p','',`${run.ch.n} · livello ${run.level} · ${run.kills} nemici abbattuti · pericolo ${DANGER[run.danger].n}`));
 const wr=h('div','slots');for(const w of run.weapons){const sl=h('div','slot t'+w.tier);sl.appendChild(canvasEl(weaponIcon(w.id,run.ch.fac,w.tier,52)));tipOn(sl,()=>card(run,'w',w.id,w.tier));wr.appendChild(sl);}box.appendChild(wr);
 const ir=h('div','items');for(const [id,n] of Object.entries(run.items)){if(!n)continue;const it=h('div','item t'+ITEMS[id].t);it.appendChild(canvasEl(itemIcon(id,40)));if(n>1)it.appendChild(h('span','cnt','×'+n));tipOn(it,()=>card(run,'i',id,ITEMS[id].t));ir.appendChild(it);}box.appendChild(ir);
 const a=h('button','go','Nuova partita');a.onclick=onAgain;box.appendChild(a);showUI(box);
 UI.keyHandler=e=>{if(e.key==='Enter')onAgain();};}
