'use strict';
// ===================== schermate (HTML sopra il disegno) =====================
const UI={root:null,tip:null,keyHandler:null};
function h(tag,cls,html){const e=document.createElement(tag);if(cls)e.className=cls;if(html!=null)e.innerHTML=html;return e;}
function textNode(tag,cls,text){const e=h(tag,cls);e.textContent=text;return e;}
function initUI(){UI.root=document.getElementById('ui');UI.tip=document.getElementById('tip');
 addEventListener('mousemove',e=>{if(UI.tip.style.display==='block'){const x=Math.min(e.clientX+16,innerWidth-UI.tip.offsetWidth-8),y=Math.min(e.clientY+16,innerHeight-UI.tip.offsetHeight-8);UI.tip.style.left=x+'px';UI.tip.style.top=y+'px';}});}
function showUI(node,cls=''){UI.root.innerHTML='';UI.root.className='show '+cls;UI.root.appendChild(node);hideTip();UI.keyHandler=null;UI.screen=null;}
function hideUI(){UI.root.className='';UI.root.innerHTML='';hideTip();UI.keyHandler=null;UI.screen=null;}
function tipOn(el,fn){el.addEventListener('mouseenter',()=>{UI.tip.innerHTML='';UI.tip.appendChild(fn());UI.tip.style.display='block';});el.addEventListener('mouseleave',hideTip);}
function hideTip(){if(UI.tip)UI.tip.style.display='none';}
const canvasEl=c=>{const e=document.createElement('canvas');e.width=c.width;e.height=c.height;e.getContext('2d').drawImage(c,0,0);return e;};
const fmtN=v=>Math.round(v*100)/100;

// ---------- descrizione di un'arma o di un oggetto ----------
function fxList(lines){const ul=h('ul','fx');for(const l of lines)ul.appendChild(h('li',l.flag?'flag':l.good?'good':'bad',l.t));return ul;}
function weaponLines(run,id,tier){const d=WEAPONS[id],s=stats(run),st=calcWeaponStats(s,d,tier),out=[];
 const sc=Object.entries(d.sc).map(([k,c])=>`${Math.round(c*100)}% ${STATS[k].ic}`).join(' ');
 out.push({t:`Danno <b>${st.dmg}</b> <span class="dim">(${byTier(d.dmg,tier)} + ${sc})</span>`,good:true});
 out.push({t:`Colpo ogni <b>${fmtN(st.cd)} s</b> · Portata <b>${Math.round(st.range)}</b>`,good:true});
 out.push({t:`Critico <b>${Math.round(st.crit*100)}%</b> ×${d.cm}`,good:true});
 if(st.pierce)out.push({t:`Trapassa ${st.pierce} nemic${st.pierce>1?'i':'o'}`,good:true});
 if(st.expl)out.push({t:`Esplode (raggio ${st.expl})`,good:true});
 if(st.burn)out.push({t:`Incendia: ${st.burn.dmg} danni × ${st.burn.n}`,good:true});
 return out.concat(describeFx(d.fx,tier));}
function card(run,kind,id,tier,extra){const c=h('div','card t'+tier);
 const top=h('div','ctop');top.appendChild(canvasEl(kind==='w'?weaponIcon(id,run.ch.fac,tier,64):itemIcon(id,64)));
 const nm=h('div','cname');nm.appendChild(h('b','',kind==='w'?WEAPONS[id].n+' '+TIER_NAMES[tier]:ITEMS[id].n));
 nm.appendChild(h('span','rar',kind==='w'?'arma · '+WEAPONS[id].fam.map(f=>FAMILIES[f].ic+' '+f).join(', '):RARITY[tier]+(ITEMS[id].max?' · max '+ITEMS[id].max:'')));
 top.appendChild(nm);c.appendChild(top);
 c.appendChild(fxList(kind==='w'?weaponLines(run,id,tier):describeFx(ITEMS[id].fx,0)));
 if(kind==='i'&&ITEMS[id].d)c.appendChild(h('p','flav',ITEMS[id].d));
 if(extra)c.appendChild(extra);return c;}

// ---------- pannello statistiche ----------
function statsPanel(run){const s=stats(run),box=h('div','stats');box.appendChild(h('h3','','Statistiche'));
 const tb=h('table');
 for(const k of STAT_KEYS){const d=STATS[k],v=Math.round(s[k]*10)/10;if(d.sec&&!v)continue;const base=d.base||0;
  const tr=h('tr',(d.bad?v<0:v>base)?'good':v<base?'bad':'');tr.appendChild(h('td','ic',d.ic||'·'));tr.appendChild(h('td','',d.n));
  tr.appendChild(h('td','v',v+(d.pct?'%':'')+(k==='dodge'&&run.capsNow.dodge!=null&&s.dodge>=run.capsNow.dodge?' (max)':'')));tb.appendChild(tr);}
 box.appendChild(tb);return box;}

// ---------- menu iniziale ----------
function charCard(id,sel,onPick,onGo){const ch=CHARS[id],c=h('div','char'+(sel?' sel':''));c.dataset.id=id;
 c.appendChild(canvasEl(heroIcon(id,96)));c.appendChild(h('h2','',ch.n));c.appendChild(h('div','city',ch.city+' · '+ch.role));
 c.appendChild(fxList(describeFx(ch.fx)));
 const sw=h('div','start','Parte con: ');for(const w of ch.start){sw.appendChild(canvasEl(weaponIcon(w,ch.fac,0,26)));sw.appendChild(document.createTextNode(' '+WEAPONS[w].n+' '));}c.appendChild(sw);
 c.onclick=()=>{onPick(id);sfx('click');};if(onGo)c.ondblclick=()=>onGo();return c;}
function modePicker(value,onChange,disabled=false){const box=h('div','mode-picker'),row=h('div','danger'),desc=h('p','sub');
 row.appendChild(h('span','','Modalità:'));const draw=()=>{row.querySelectorAll('button').forEach(b=>{const selected=b.dataset.mode===value;b.classList.toggle('on',selected);b.setAttribute('aria-pressed',String(selected));});desc.textContent=RUN_MODES[value].d;};
 for(const [id,mode] of Object.entries(RUN_MODES)){const b=h('button','',mode.n);b.dataset.mode=id;b.disabled=disabled;b.onclick=()=>{value=id;draw();onChange(id);sfx('click');};row.appendChild(b);}
 box.append(row,desc);draw();return box;}
function showMenu(onStart,msg){const box=h('div','menu');let pick=GAME.lastChar,danger=GAME.lastDanger,gameMode=GAME.lastGameMode;
 box.appendChild(h('h1','','Montaperti <span>Shooter</span>'));
 box.appendChild(h('p','sub','Affronta la Compagnia della Malaventura in 20 ondate o senza fine. Le tue armi colpiscono da sole: tu pensa a muoverti. Da soli o fino a 4 amici.'));
 if(msg)box.appendChild(textNode('p','netmsg',msg));
 const row=h('div','chars');
 const setPick=id=>{pick=GAME.lastChar=id;row.querySelectorAll('.char').forEach(x=>x.classList.toggle('sel',x.dataset.id===id));};
 for(const id of Object.keys(CHARS))row.appendChild(charCard(id,id===pick,setPick,()=>onStart(pick,danger,gameMode)));
 const dg=h('div','danger');dg.appendChild(h('span','','Pericolo:'));
 DANGER.forEach((d,i)=>{const b=h('button',i===danger?'on':'',d.n);b.onclick=()=>{danger=GAME.lastDanger=i;dg.querySelectorAll('button').forEach((x,j)=>x.classList.toggle('on',j===i));sfx('click');};dg.appendChild(b);});
 const acts=h('div','acts');
 const go=h('button','go','Gioca da solo ▶');go.onclick=()=>onStart(pick,danger,gameMode);
 const host=h('button','','Crea partita online');host.onclick=()=>{hostRoom(pick,gameMode,danger);showLobby();};
 const code=h('input','code');code.placeholder='CODICE';code.maxLength=5;code.oninput=()=>{code.value=code.value.toUpperCase().replace(/[^A-Z]/g,'');};
 const join=h('button','','Entra');join.onclick=()=>{joinRoom(code.value,pick);showLobby();};
 acts.append(go,host,code,join);box.appendChild(acts);box.appendChild(dg);box.appendChild(modePicker(gameMode,id=>{gameMode=GAME.lastGameMode=id;}));box.appendChild(h('p','dim','Scegli il personaggio:'));box.appendChild(row);
 box.appendChild(h('p','keys','<b>WASD</b> o <b>frecce</b> per muoverti · <b>Esc</b> pausa · <b>M</b> audio sì/no · <b>F11</b> schermo intero<br><span class="dim">versione '+GAME_VERSION+(NET_LOCAL?' · prova locale (senza internet)':'')+'</span>'));
 showUI(box,'full');UI.keyHandler=e=>{if(e.key==='Enter'){if(e.target?.tagName==='BUTTON')return;if(document.activeElement===code)join.click();else onStart(pick,danger,gameMode);}};}

// ---------- stanza d'attesa (multigiocatore) ----------
function showLobby(){const box=h('div','panel lobby');UI.screen='lobby';
 const draw=()=>{box.innerHTML='';
  if(!netOn()){box.appendChild(h('h2','','Partita online'));box.appendChild(textNode('p','netmsg',NET.msg||'Collegamento chiuso.'));
   const b=h('button','go','Torna al menu');b.onclick=()=>toMenu();box.appendChild(b);return;}
  const host=NET.role==='host';
  box.appendChild(h('h2','',host?'Stanza '+'<span class="roomcode">'+NET.code+'</span>':'Stanza '+NET.code));
  box.appendChild(h('p','sub',host?'Passa queste 5 lettere agli amici: nel menu scrivono il codice e premono «Entra». Massimo 4 giocatori.':
   NET.phase==='joining'?'':'Sei dentro. Scegli il personaggio: la partita la fa partire chi ospita.'));
  if(NET.msg)box.appendChild(textNode('p','netmsg',NET.msg));
  if(NET.phase!=='joining'){
   const list=h('div','plist');
   for(let s=0;s<NET_MAX;s++){const p=NET.lobby.find(p=>p.slot===s),el=h('div','pslot'+(p?'':' empty'));
    if(p){el.appendChild(canvasEl(heroIcon(p.charId,56)));el.appendChild(h('div','',`<b style="color:${PLAYER_COL[s]}">G${s+1}</b> ${CHARS[p.charId].city}`+(s===NET.slot?' <span class="dim">(tu)</span>':'')+(s===0?' <span class="dim">· ospita</span>':'')));}
    else el.appendChild(h('div','dim','posto libero'));
    list.appendChild(el);}
   box.appendChild(list);
   box.appendChild(h('p','sub','XP e fiorini raccolti si dividono fra tutti, anche i caduti. Ognuno spende la propria quota; bonus XP e Raccolta restano personali.'));
   const mine=(NET.lobby.find(p=>p.slot===NET.slot)||{}).charId||GAME.lastChar;
   box.appendChild(h('h3','','Il tuo personaggio'));
   const pick=h('div','minipick');
   for(const id of Object.keys(CHARS)){const b=h('button',id===mine?'on':'');b.title=CHARS[id].n;b.appendChild(canvasEl(heroIcon(id,44)));b.appendChild(h('span','',CHARS[id].city));
    b.onclick=()=>{GAME.lastChar=id;if(host)hostPick(id);else{guestPick(id);const me=NET.lobby.find(p=>p.slot===NET.slot);if(me)me.charId=id;draw();}sfx('click');};pick.appendChild(b);}
   box.appendChild(pick);
   const dg=h('div','danger');dg.appendChild(h('span','','Pericolo:'));
   DANGER.forEach((d,i)=>{const b=h('button',i===NET.danger?'on':'',d.n);b.disabled=!host;if(host)b.onclick=()=>{hostDanger(i);sfx('click');};dg.appendChild(b);});
   box.appendChild(dg);box.appendChild(modePicker(NET.gameMode,id=>{GAME.lastGameMode=id;hostGameMode(id);},!host||NET.phase!=='lobby'));}
  const acts=h('div','acts');
  if(host){const n=NET.lobby.length,go=h('button','go','Inizia la partita ('+n+' giocator'+(n>1?'i':'e')+') ▶');go.onclick=()=>hostBegin();acts.appendChild(go);}
  else if(NET.phase==='lobby')acts.appendChild(h('span','dim','Aspetta che chi ospita faccia partire la partita…'));
  const out=h('button','dim','Esci');out.onclick=()=>toMenu();acts.appendChild(out);box.appendChild(acts);};
 NET.onChange=()=>{if(UI.screen==='lobby')draw();else if(UI.screen==='waiting')UI.redraw&&UI.redraw();};
 draw();showUI(box,'full');UI.screen='lobby';UI.keyHandler=e=>{if(e.key==='Escape')toMenu();};}
// Fra un'ondata e l'altra, quando hai finito in bottega: chi manca ancora.
function showWaiting(){const box=h('div','panel waiting');
 const draw=()=>{box.innerHTML='';box.appendChild(h('h2','','In attesa degli altri giocatori…'));
  const info=NET.readyInfo,list=h('div','plist');
  const slots=info?info.all:NET.lobby.map(p=>p.slot);
  for(const s of slots){const ok=info&&info.ready.includes(s),p=NET.lobby.find(p=>p.slot===s);
   list.appendChild(h('div','pslot',`<b style="color:${PLAYER_COL[s]}">G${s+1}</b> ${p?CHARS[p.charId].city:''} ${s===NET.slot?'<span class="dim">(tu)</span>':''} — ${ok?'✔ pronto':'in bottega…'}`));}
  box.appendChild(list);if(NET.msg)box.appendChild(textNode('p','netmsg',NET.msg));
  const out=h('button','dim','Abbandona la partita');out.onclick=()=>toMenu();box.appendChild(out);};
 UI.redraw=draw;draw();showUI(box);UI.screen='waiting';}
// In compagnia Esc non ferma il gioco: solo un piccolo menu.
function showNetMenu(onResume,onQuit){const box=h('div','panel pause');box.appendChild(h('h2','','Partita in compagnia'));
 box.appendChild(h('p','sub','Il gioco non si ferma: gli altri continuano a combattere.'));
 const r=h('button','go','Torna a combattere');r.onclick=onResume;const q=h('button','dim','Abbandona la partita');q.onclick=onQuit;
 box.append(r,q);showUI(box);UI.keyHandler=e=>{if(e.key==='Escape')onResume();};}
// ---------- livello raggiunto ----------
function showLevelUp(run,done){const choices=levelChoices(run);const box=h('div','panel lvl');
 box.appendChild(h('h2','','Livello '+(run.level-run.levelsPending+1)+'!'+(run.levelsPending>1?` <span class="dim">(ancora ${run.levelsPending-1} dopo questo)</span>`:'')));
 box.appendChild(h('p','sub','Scegli un potenziamento. Vale per tutta la partita.'));
 const row=h('div','offers');
 choices.forEach((c,i)=>{const d=STATS[c.s],el=h('div','card up t'+c.tier);
  el.appendChild(h('div','bigic',d.ic));el.appendChild(h('b','',fmtStat(c.s,c.v)));el.appendChild(h('span','rar',RARITY[c.tier]));el.appendChild(h('span','keyhint',String(i+1)));
  el.onclick=()=>{applyUpgrade(run,c);sfx('level');done();};row.appendChild(el);});
 box.appendChild(row);const wrap=h('div','split');wrap.appendChild(box);wrap.appendChild(statsPanel(run));showUI(wrap);
 UI.keyHandler=e=>{const n=+e.key;if(n>=1&&n<=4){applyUpgrade(run,choices[n-1]);sfx('level');done();}};}

// ---------- bottino ----------
function showCrate(run,done){const id=openCrate(run);const box=h('div','panel crate');
 box.appendChild(h('h2','','Bottino!'));box.appendChild(h('p','sub','Hai trovato qualcosa fra le spoglie dei briganti.'));
 const btns=h('div','btns');const take=h('button','go','Prendi');const rec=h('button','','Ricicla (+'+recycleOf(run,ITEMS[id].val)+' ⚜)');
 take.onclick=()=>{takeItem(run,id);sfx('buy');done();};rec.onclick=()=>{recycleItem(run,id);sfx('coin');done();};
 btns.append(take,rec);box.appendChild(card(run,'i',id,ITEMS[id].t,btns));showUI(box);
 UI.keyHandler=e=>{if(e.key==='Enter'){takeItem(run,id);sfx('buy');done();}};}

// ---------- bottega ----------
function showShop(run,onGo){const box=h('div','shop');
 const draw=()=>{box.innerHTML='';const s=stats(run);
  const head=h('div','shead');head.appendChild(h('h2','','Bottega'+(isEndless(run)?' · Endless':'')+' <span class="dim">· ondata '+run.wave+' superata</span>'));
  head.appendChild(h('div','gold','⚜ <b>'+run.gold+'</b> fiorini'+(GAME.mode!=='solo'?' · quota personale':'')+(run.bag?` <span class="dim">· borsa ${run.bag}</span>`:'')));
  const rp=rerollPrice(run),rb=h('button','','Rimescola · '+rp+' ⚜');rb.disabled=run.gold<rp;rb.onclick=()=>{if(reroll(run)){sfx('click');draw();}};head.appendChild(rb);box.appendChild(head);
  const offers=h('div','offers');
  run.shop.offers.forEach((o,i)=>{if(!o){offers.appendChild(h('div','card sold','venduto'));return;}
   const why=cantBuy(run,i),price=offerPrice(run,o),btns=h('div','btns');
   const b=h('button','buy',(o.kind==='w'&&run.weapons.length>=MAX_WEAPONS&&!why?'Compra e unisci · ':'Compra · ')+price+' ⚜');b.disabled=!!why;if(why)b.title=why;
   b.onclick=()=>{if(buy(run,i)){sfx('buy');draw();}};
   const lk=h('button','lock'+(run.shop.locked[i]?' on':''),run.shop.locked[i]?'🔒':'🔓');lk.title='Tieni questa offerta per il prossimo giro';lk.onclick=()=>{toggleLock(run,i);sfx('click');draw();};
   btns.append(b,lk);const c=card(run,o.kind,o.id,o.tier,btns);if(run.shop.locked[i])c.classList.add('locked');offers.appendChild(c);});
  box.appendChild(offers);
  const bottom=h('div','sbottom');const inv=h('div','inv');
  inv.appendChild(h('h3','','Armi <span class="dim">'+run.weapons.length+' / '+MAX_WEAPONS+'</span>'));
  const wrow=h('div','slots');
  for(let i=0;i<MAX_WEAPONS;i++){const w=run.weapons[i],sl=h('div','slot'+(w?' t'+w.tier:' empty'));
   if(w){sl.appendChild(canvasEl(weaponIcon(w.id,run.ch.fac,w.tier,52)));sl.appendChild(h('span','tier',TIER_NAMES[w.tier]));
    if(combineTarget(run,i)>=0)sl.appendChild(h('span','merge','unisci'));
    tipOn(sl,()=>card(run,'w',w.id,w.tier));
    sl.onclick=ev=>{ev.stopPropagation();weaponMenu(run,i,sl,draw);};}
   wrow.appendChild(sl);}
  inv.appendChild(wrow);
  const fams=Object.entries(familyCounts(run)).filter(([,n])=>n>=2);
  if(fams.length)inv.appendChild(h('div','fams',fams.map(([f,n])=>`${FAMILIES[f].ic} ${f} ×${n}: ${fmtStat(FAMILIES[f].s,FAMILIES[f].v[Math.min(n,6)-2])}`).join(' · ')));
  inv.appendChild(h('h3','','Oggetti'));const irow=h('div','items');
  for(const [id,n] of Object.entries(run.items)){if(!n)continue;const it=h('div','item t'+ITEMS[id].t);it.appendChild(canvasEl(itemIcon(id,40)));if(n>1)it.appendChild(h('span','cnt','×'+n));
   tipOn(it,()=>card(run,'i',id,ITEMS[id].t));irow.appendChild(it);}
  if(!Object.values(run.items).some(n=>n))irow.appendChild(h('span','dim','nessuno, per ora'));
  inv.appendChild(irow);bottom.appendChild(inv);bottom.appendChild(statsPanel(run));box.appendChild(bottom);
  const go=h('button','go big',(GAME.mode==='solo'?'Avanti: ondata ':'Pronto per l\'ondata ')+(run.wave+1)+' ▶');go.onclick=onGo;box.appendChild(go);};
 draw();showUI(box,'full');UI.keyHandler=e=>{if(e.key==='Enter')onGo();if(e.key==='r'||e.key==='R'){if(reroll(run)){sfx('click');draw();}}};}
function weaponMenu(run,i,anchor,redraw){document.querySelectorAll('.wmenu').forEach(x=>x.remove());const w=run.weapons[i];const m=h('div','wmenu');
 const j=combineTarget(run,i);
 if(j>=0){const b=h('button','','Unisci → '+WEAPONS[w.id].n+' '+TIER_NAMES[w.tier+1]);b.onclick=()=>{combine(run,i);sfx('buy');redraw();};m.appendChild(b);}
 const s=h('button','','Ricicla (+'+recycleOf(run,weaponVal(w))+' ⚜)');s.disabled=run.weapons.length<=1;s.onclick=()=>{sellWeapon(run,i);sfx('coin');redraw();};m.appendChild(s);
 const c=h('button','dim','Annulla');c.onclick=()=>m.remove();m.appendChild(c);
 anchor.appendChild(m);setTimeout(()=>addEventListener('click',()=>m.remove(),{once:true}),0);}

// ---------- pausa e fine ----------
function showPause(G,onResume,onQuit){const box=h('div','panel pause');box.appendChild(h('h2','','Pausa'));
 const r=h('button','go','Riprendi');r.onclick=onResume;box.appendChild(r);
 const det=h('details','cheats');det.appendChild(h('summary','','Trucchi di prova'));
 const add=(t,fn)=>{const b=h('button','',t);b.onclick=()=>{fn();sfx('click');};det.appendChild(b);};
 add('Salta l\'ondata',()=>{if(G.W){G.W.t=G.W.dur;}onResume();});
 add('+100 fiorini',()=>{G.run.gold+=100;});
 add('+1 livello',()=>{addXp(G.run,xpNeeded(G.run.level)-G.run.xp);});
 add(G.W&&G.W.cheat.god?'Invincibile: sì':'Invincibile: no',()=>{G.W.cheat.god=!G.W.cheat.god;showPause(G,onResume,onQuit);});
 add('Vai all\'ondata 10',()=>{G.jumpTo=10;G.W.t=G.W.dur;onResume();});
 box.appendChild(det);box.appendChild(statsPanel(G.run));
 const q=h('button','dim','Abbandona la partita');q.onclick=onQuit;box.appendChild(q);showUI(box);
 UI.keyHandler=e=>{if(e.key==='Escape')onResume();};}
function showEnd(run,won,onAgain){const box=h('div','panel end');
 box.appendChild(h('h2','',won?'Vittoria!':'Sei caduto'));
 box.appendChild(h('p','sub',won?'Hai superato la ventesima ondata della Compagnia.':'La Compagnia ti ha sopraffatto all\'ondata '+run.wave+'.'));
 box.appendChild(h('p','',`${isEndless(run)?'Endless · ':''}${run.ch.n} · livello ${run.level} · ${run.kills} nemici abbattuti · pericolo ${DANGER[run.danger].n}`));
 const wr=h('div','slots');for(const w of run.weapons){const sl=h('div','slot t'+w.tier);sl.appendChild(canvasEl(weaponIcon(w.id,run.ch.fac,w.tier,52)));tipOn(sl,()=>card(run,'w',w.id,w.tier));wr.appendChild(sl);}box.appendChild(wr);
 const ir=h('div','items');for(const [id,n] of Object.entries(run.items)){if(!n)continue;const it=h('div','item t'+ITEMS[id].t);it.appendChild(canvasEl(itemIcon(id,40)));if(n>1)it.appendChild(h('span','cnt','×'+n));tipOn(it,()=>card(run,'i',id,ITEMS[id].t));ir.appendChild(it);}box.appendChild(ir);
 const a=h('button','go','Nuova partita');a.onclick=onAgain;box.appendChild(a);showUI(box);
 UI.keyHandler=e=>{if(e.key==='Enter')onAgain();};}
