'use strict';
// ===================== l'ondata =====================
// Tempo fisso: 60 passi al secondo. Nessun disegno: gli eventi (danni, morti, esplosioni) finiscono in W.events
// e chi disegna li legge. Così la stessa simulazione gira anche senza schermo (tools/simula.js) e,
// in multigiocatore, solo sul PC di chi ospita: gli altri ricevono le "fotografie" della partita.
// Da 1 a 4 giocatori: W.P è l'elenco dei giocatori, ognuno con la sua partita (run), armi e statistiche.
const DT=1/60;

// Quanto crescono i nemici con più giocatori (per ogni giocatore oltre il primo).
// coin: in compagnia ogni fiorino vale giocatori/crescita dei nemici, così ognuno guadagna come da solo.
const COOP={count:.6,hp:.5,elite:1,boss:.75,cap:.45};

function newPlayer(run,i,n){const s=computeStats(run,0);const a=n>1?i/n*TAU+Math.PI/4:0,r=n>1?60:0;
 const P={i,run,x:ARENA.w/2+Math.cos(a)*r,y:ARENA.h/2+Math.sin(a)*r,r:PLAYER.r,hp:s.maxhp,iframes:0,face:1,moving:false,moveT:0,regenT:0,lsT:0,lsN:0,walkT:0,
  dead:false,charge:false,shots:0,meleeHits:0,lastSrc:null,lastSec:0,
  hasCharge:hasFlag(run,'charge'),hasThird:hasFlag(run,'third'),hasFerocia:hasFlag(run,'ferocia')};
 P.weapons=run.weapons.map((w,k)=>({w,d:WEAPONS[w.id],tier:w.tier,i:k,ang:-Math.PI/2+k,cd:.3+k*.07,anim:0,animDur:.2,reach:0,att:null,st:null,stRef:null}));
 return P;}
// runs: una partita per giocatore (indice = posto). rng: numeri casuali del mondo (in solitaria quelli della partita).
function newWorld(runs,rng){if(!Array.isArray(runs))runs=[runs];const n=runs.length,lead=runs[0],wave=WAVES[lead.wave-1];
 const W={runs,n,rng:rng||lead.rng,t:0,dur:wave.dur,wave:lead.wave,danger:lead.danger,over:null,cheat:{god:false},
  cmul:1+COOP.count*(n-1),hmul:1+COOP.hp*(n-1),bmul:1+COOP.elite*(n-1),bossMul:1+COOP.boss*(n-1),coinMul:n/(1+COOP.count*(n-1)),cap:Math.round(MAX_ENEMIES*(1+COOP.cap*(n-1))),
  enemies:[],projs:[],eprojs:[],pickups:[],structs:[],pending:[],events:[],nextId:1,
  groups:wave.g.map(g=>({...g,next:g.from}))};
 W.P=runs.map((r,i)=>newPlayer(r,i,n));W.p=W.P[0];
 for(const P of W.P)emit(P.run,'waveStart',{world:W,rng:W.rng,player:P});
 return W;}
const alive=W=>W.P.filter(P=>!P.dead);
function nearestPlayer(W,x,y){let best=null,bd=Infinity;for(const P of W.P){if(P.dead)continue;const d=hyp(P.x-x,P.y-y);if(d<bd){bd=d;best=P;}}return best;}

// ---------- statistiche di un'arma (rifatte solo quando cambiano le statistiche) ----------
function weaponStats(W,P,ws){const s=stats(P.run,W.t);if(ws.stRef===s)return ws.st;ws.st=calcWeaponStats(s,ws.d,ws.tier);ws.stRef=s;return ws.st;}
function calcWeaponStats(s,d,t){
 let base=byTier(d.dmg,t);for(const [k,c] of Object.entries(d.sc))base+=s[k]*c;
 const v=s.atkspd/100,cd0=byTier(d.cd,t);
 const st={dmg:Math.max(1,Math.round(Math.max(1,base)*(1+s.dmg/100))),
  cd:Math.max(.1,v>=0?cd0/(1+v):cd0*(1-v)),
  range:Math.max(40,d.range+(d.kind==='melee'?s.range/2:s.range)),
  crit:d.crit+s.crit/100,cm:d.cm,knock:d.knock+s.knock,
  pierce:d.proj?(d.proj.pierce||0)+s.pierce:0,pr:d.proj?.pr??.5,
  burn:d.burn?{dmg:Math.max(1,byTier(d.burn.dmg,t)+Math.round(s.elem*.5)),n:d.burn.n,scaled:1}:null,
  expl:d.expl?byTier(d.expl.r,t):0};
 return st;}
function weaponPos(P,ws){const n=P.weapons.length,a=ws.i/n*TAU-Math.PI/2,r=n>1?24:14;
 return [P.x+Math.cos(a)*r,P.y-10+Math.sin(a)*r*.7];}

// ---------- un passo ----------
// inputs: {x,y} in solitaria, oppure un elenco con un {x,y} per giocatore.
function step(W,inputs){if(W.over)return;W.t+=DT;
 // Il DPS medio usa solo il tempo simulato delle ondate, anche da caduti.
 for(const P of W.P)if(!P.gone)P.run.combatTime+=DT;
 if(!Array.isArray(inputs))inputs=[inputs];
 W.P.forEach((P,i)=>{if(!P.dead)updatePlayer(W,P,inputs[i]||{x:0,y:0});});
 spawning(W);
 for(const e of W.enemies)if(!e.dead)updateEnemy(W,e);
 separate(W);
 for(const P of W.P)if(!P.dead)for(const ws of P.weapons)updateWeapon(W,P,ws);
 for(const st of W.structs)updateStruct(W,st);
 updateProjs(W);updateEnemyProjs(W);updatePickups(W);
 if(W.enemies.some(e=>e.dead))W.enemies=W.enemies.filter(e=>!e.dead);
 for(const P of W.P)if(!P.dead&&P.hp<=0){P.dead=true;P.hp=0;W.events.push({k:'pdead',x:P.x,y:P.y,pl:P.i});}
 if(W.over)return;
 if(!alive(W).length){W.over='dead';W.events.push({k:'dead'});return;}
 if(W.t>=W.dur)finishWave(W);}
function updatePlayer(W,P,inp){const run=P.run,s=stats(run,W.t);
 let mx=inp.x||0,my=inp.y||0;const ml=Math.hypot(mx,my);if(ml>1){mx/=ml;my/=ml;}
 const spd=PLAYER.speed*Math.max(.25,1+s.speed/100);
 P.x=clamp(P.x+mx*spd*DT,20,ARENA.w-20);P.y=clamp(P.y+my*spd*DT,24,ARENA.h-14);
 P.moving=ml>.1;if(mx>.1)P.face=1;else if(mx<-.1)P.face=-1;
 if(P.moving){P.moveT+=DT;P.walkT+=DT;}else P.moveT=Math.max(0,P.moveT-DT*3);
 P.charge=P.hasCharge&&P.moveT>=1;
 P.iframes-=DT;
 if(P.hp>s.maxhp)P.hp=s.maxhp;
 if(s.regen>0){P.regenT+=DT;const iv=5/(1+(s.regen-1)/2.25);if(P.regenT>=iv){P.regenT=0;healPlayer(W,P,1,true);}}
 P.lsT-=DT;if(P.lsT<=0){P.lsT=1;P.lsN=0;}
 // ganci a intervallo
 const sec=Math.floor(W.t);if(sec>P.lastSec){P.lastSec=sec;for(const t of run.trig.interval||[])if(sec%t.fx.every===0)for(let c=0;c<t.count;c++)doAction(run,t.fx.do,t.tier,{world:W,rng:W.rng,player:P});}}

// ---------- comparsa dei nemici (con il segno rosso di avviso) ----------
function spawning(W){const rng=W.rng;
 for(const g of W.groups){while(W.t>=g.next&&g.next<g.to){const D=ENEMIES[g.e];
  if(W.enemies.length+W.pending.length<W.cap||D.boss||D.elite){
   // con più giocatori arrivano più nemici (i capitani e il boss restano uno, ma più robusti)
   let n=rng.int(g.n[0],g.n[1]);if(!D.boss&&!D.elite){const f=n*W.cmul;n=Math.floor(f)+(rng.next()<f%1?1:0);}
   if(!D.boss&&!D.elite)n=Math.min(n,Math.max(0,W.cap-W.enemies.length-W.pending.length));
   let cx,cy,best=-1;
   for(let k=0;k<14;k++){const x=rng.range(70,ARENA.w-70),y=rng.range(70,ARENA.h-70),distance=Math.min(...alive(W).map(P=>hyp(x-P.x,y-P.y)));
    if(distance>best){best=distance;cx=x;cy=y;}if(distance>300)break;}
   for(let i=0;i<n;i++)W.pending.push({type:g.e,x:clamp(cx+rng.range(-55,55),30,ARENA.w-30),y:clamp(cy+rng.range(-55,55),30,ARENA.h-30),t:D.boss?1.8:.9});}
  g.next=g.once?Infinity:g.next+Math.max(.5,g.every);}}
 for(const q of W.pending){q.t-=DT;if(q.t<=0)spawnEnemy(W,q.type,q.x,q.y);}
 W.pending=W.pending.filter(q=>q.t>0);}
function spawnEnemy(W,type,x,y){const d=ENEMIES[type],w=W.wave,D=DANGER[W.danger],rng=W.rng;
 const hp=Math.max(1,Math.round((d.hp+d.hpW*(w-1))*D.hp*(d.boss?W.bossMul:d.elite?W.bmul:W.hmul)*lateEnemyHp(w,d)));
 const e={id:W.nextId++,type,d,x,y,hp,maxhp:hp,dmg:Math.max(1,Math.round((d.dmg+d.dmgW*(w-1))*D.dmg)),spd:d.spd*rng.range(.92,1.08),r:d.r,
  kx:0,ky:0,t:0,cd:d.cd?rng.range(.4,1)*d.cd:2,cd2:4,state:'walk',st:0,dx:0,dy:0,burn:null,flash:0,buff:0,face:1,anim:rng.next()*4,dead:false,
  wander:rng.next()*TAU,phase:0};
 W.enemies.push(e);return e;}

// ---------- nemici ----------
function updateEnemy(W,e){const rng=W.rng;e.t+=DT;e.flash-=DT;e.cd-=DT;e.cd2-=DT;
 const p=nearestPlayer(W,e.x,e.y);if(!p)return;
 let dx=p.x-e.x,dy=p.y-e.y;const dist=Math.hypot(dx,dy)||1;dx/=dist;dy/=dist;
 let vx=0,vy=0;const spd=e.spd*(e.buff?1.25:1);
 switch(e.d.beh){
  case 'chase':vx=dx*spd;vy=dy*spd;break;
  case 'shooter':{const R=e.d.range;if(dist>R*.9){vx=dx*spd;vy=dy*spd;}else if(dist<R*.55){vx=-dx*spd;vy=-dy*spd;}else{vx=-dy*spd*.35;vy=dx*spd*.35;}
   if(e.cd<=0&&dist<R*1.15){e.cd=e.d.cd;shootAt(W,e.x,e.y-14,Math.atan2(p.y-e.y,p.x-e.x),e.dmg,260);e.state='shoot';e.st=.3;}break;}
  case 'charger':
   if(e.state==='aim'){e.st-=DT;if(e.st<=0){e.state='dash';e.st=.65;}}
   else if(e.state==='dash'){vx=e.dx*spd*3.3;vy=e.dy*spd*3.3;e.st-=DT;if(e.st<=0){e.state='walk';e.cd=2.2;}}
   else{vx=dx*spd*.8;vy=dy*spd*.8;if(dist<330&&e.cd<=0){e.state='aim';e.st=.55;e.dx=dx;e.dy=dy;}}break;
  case 'healer':
   if(dist<330){vx=-dx*spd;vy=-dy*spd;}else{e.wander+=rng.range(-.1,.1);vx=Math.cos(e.wander)*spd*.4;vy=Math.sin(e.wander)*spd*.4;}
   if(e.cd<=0){e.cd=3.5;for(const o of W.enemies)if(o!==e&&!o.dead&&o.hp<o.maxhp&&hyp(o.x-e.x,o.y-e.y)<170){o.hp=Math.min(o.maxhp,o.hp+Math.ceil(o.maxhp*.3));W.events.push({k:'heal',x:o.x,y:o.y});}
    W.events.push({k:'aura',x:e.x,y:e.y,r:170,col:'#9be07a'});}break;
  case 'buffer':vx=dx*spd;vy=dy*spd;
   if(e.cd<=0){e.cd=5;for(const o of W.enemies)if(o!==e&&!o.dead&&!o.buff&&!o.d.boss&&hyp(o.x-e.x,o.y-e.y)<180){o.buff=1;o.maxhp=Math.round(o.maxhp*1.3);o.hp=Math.round(o.hp*1.3);o.dmg+=1;}
    W.events.push({k:'aura',x:e.x,y:e.y,r:180,col:'#e0b030'});}break;
  case 'spawner':
   if(dist<280){vx=-dx*spd;vy=-dy*spd;}else{vx=dx*spd*.5;vy=dy*spd*.5;}
   if(e.cd<=0){e.cd=5;for(let i=0;i<2;i++)if(W.enemies.length<W.cap)spawnEnemy(W,'brigante',e.x+rng.range(-25,25),e.y+rng.range(-25,25));}break;
  case 'elite':case 'boss':{const boss=e.d.boss;
   if(e.state==='aim'){e.st-=DT;if(e.st<=0){e.state='dash';e.st=.6;}}
   else if(e.state==='dash'){vx=e.dx*spd*3.4;vy=e.dy*spd*3.4;e.st-=DT;if(e.st<=0){e.state='walk';}}
   else{vx=dx*spd;vy=dy*spd;if(!boss&&e.cd2<=0&&dist<380){e.state='aim';e.st=.7;e.dx=dx;e.dy=dy;e.cd2=7;}}
   if(e.cd<=0){const angry=e.hp<e.maxhp*.5,n=boss?(angry?24:18):12;e.cd=boss?(angry?3:4.2):5;e.phase+=.13;
    for(let i=0;i<n;i++)shootAt(W,e.x,e.y-20,e.phase+i/n*TAU,Math.max(1,Math.round(e.dmg*.7)),boss?190:210);}
   if(boss&&e.cd2<=0){e.cd2=8;const k=Math.round(4*W.cmul);for(let i=0;i<k;i++)if(W.enemies.length<W.cap)spawnEnemy(W,i%2?'tagliagole':'brigante',e.x+rng.range(-60,60),e.y+rng.range(-40,40));}
   break;}
 }
 if(e.state==='shoot'){e.st-=DT;if(e.st<=0)e.state='walk';}
 e.kx*=Math.exp(-9*DT);e.ky*=Math.exp(-9*DT);
 e.x=clamp(e.x+(vx+e.kx)*DT,14,ARENA.w-14);e.y=clamp(e.y+(vy+e.ky)*DT,18,ARENA.h-10);
 if(Math.abs(vx)>5)e.face=vx>0?1:-1;
 e.anim+=DT*(Math.hypot(vx,vy)/60);
 if(e.burn){e.burn.t-=DT;if(e.burn.t<=0){e.burn.t=.5;e.burn.n--;damageEnemy(W,e,e.burn.dmg,{src:'burn',owner:e.burn.owner});if(e.burn&&e.burn.n<=0)e.burn=null;}}
 if(!e.dead)for(const P of W.P)if(!P.dead&&hyp(P.x-e.x,P.y-e.y)<e.r+P.r)hurtPlayer(W,P,e.dmg,e.type);}
// Spinta morbida fra nemici, così non si ammucchiano in un punto.
function separate(W){const E=W.enemies,n=E.length;
 for(let i=0;i<n;i++){const a=E[i];if(a.dead)continue;
  for(let j=i+1;j<n;j++){const b=E[j];if(b.dead)continue;const dx=b.x-a.x,dy=b.y-a.y,R=(a.r+b.r)*.8;
   if(dx>R||dx<-R||dy>R||dy<-R)continue;const d=Math.hypot(dx,dy)||.01;if(d>=R)continue;
   const push=(R-d)*.5,ux=dx/d,uy=dy/d,wa=b.d.boss?1:a.d.boss?0:.5;a.x-=ux*push*wa;a.y-=uy*push*wa;b.x+=ux*push*(1-wa);b.y+=uy*push*(1-wa);}}}
function shootAt(W,x,y,ang,dmg,speed){W.eprojs.push({x,y,vx:Math.cos(ang)*speed,vy:Math.sin(ang)*speed,dmg,life:4.5});}

// ---------- giocatori ----------
const armorCoef=a=>a>=0?10/(10+a/1.5):2-10/(10+(-a)/1.5);
function hurtPlayer(W,P,dmg,src){if(P.dead||P.iframes>0||W.over||W.cheat.god)return;P.lastSrc=src;const run=P.run,s=stats(run,W.t);
 if(W.rng.next()<s.dodge/100){P.iframes=.2;W.events.push({k:'text',x:P.x,y:P.y-34,t:'schivato',col:'#cfe8ff'});emit(run,'dodge',{world:W,rng:W.rng,player:P,x:P.x,y:P.y});return;}
 const taken=Math.max(1,Math.round(dmg*armorCoef(s.armor)));P.hp-=taken;
 if(P.hp<=0){P.hp=0;P.dead=true;W.events.push({k:'pdead',x:P.x,y:P.y,pl:P.i});}
 P.iframes=clamp(taken/s.maxhp*.4/.15,.2,.4);
 W.events.push({k:'hurt',x:P.x,y:P.y,v:taken,pl:P.i});
 emit(run,'hurt',{world:W,rng:W.rng,player:P,x:P.x,y:P.y});}
function healPlayer(W,P,n,quiet){if(!W||!P||P.dead||P.hp<=0)return;const s=stats(P.run,W.t);
 const v=Math.max(1,Math.round(n*(1+s.heal/100)));const before=P.hp;P.hp=Math.min(s.maxhp,P.hp+v);
 if(P.hp>before&&!quiet)W.events.push({k:'text',x:P.x,y:P.y-34,t:'+'+(P.hp-before),col:'#7fe07a'});
 if(P.hp>before&&quiet)W.events.push({k:'regen',x:P.x,y:P.y});}
// Respinge tutti i nemici vicini (Muro di picche di Milano).
function repel(W,P,r){W.events.push({k:'aura',x:P.x,y:P.y,r,col:'#f4efe2'});
 for(const e of W.enemies){if(e.dead)continue;const dx=e.x-P.x,dy=e.y-P.y,d=Math.hypot(dx,dy)||1;if(d>r+e.r)continue;const k=700*(1-(e.d.knockRes||0)*.7);e.kx+=dx/d*k;e.ky+=dy/d*k;}}

// ---------- armi ----------
function nearestEnemy(W,x,y,range){let best=null,bd=Infinity;
 for(const e of W.enemies){if(e.dead)continue;const d=hyp(e.x-x,e.y-y)-e.r;if(d<range&&d<bd){bd=d;best=e;}}return best;}
function updateWeapon(W,P,ws){const st=weaponStats(W,P,ws);ws.cd-=DT;if(ws.anim>0)ws.anim-=DT;
 const [wx,wy]=weaponPos(P,ws);const tg=nearestEnemy(W,wx,wy,st.range);
 if(tg){const a=Math.atan2(tg.y-12-wy,tg.x-wx);if(ws.anim<=0)ws.ang+=angDiff(ws.ang,a)*Math.min(1,DT*18);}
 else if(ws.anim<=0)ws.ang+=angDiff(ws.ang,P.face>0?-.35:Math.PI+.35)*DT*4;
 if(ws.cd>0||!tg)return;
 ws.cd=st.cd;const a=Math.atan2(tg.y-12-wy,tg.x-wx);ws.ang=a;const d=ws.d;
 const mul=P.charge?1.6:1;let hits=0;
 // Napoli: ogni terzo attacco in mischia è un critico sicuro
 let crit=st.crit;if(d.kind==='melee'&&P.hasFerocia){P.meleeHits++;if(P.meleeHits%3===0)crit=1;}
 if(d.att==='thrust'){const reach=Math.min(st.range,hyp(tg.x-wx,tg.y-12-wy));const ux=Math.cos(a),uy=Math.sin(a);
  ws.reach=reach;ws.anim=ws.animDur=Math.min(.22,st.cd*.6);ws.att='thrust';
  for(const e of W.enemies){if(e.dead)continue;const ex=e.x-wx,ey=e.y-12-wy,along=clamp(ex*ux+ey*uy,0,reach);
   if(hyp(ex-ux*along,ey-uy*along)<e.r+10){hitWithWeapon(W,P,st,e,mul,ux,uy,crit);hits++;}}}
 else if(d.att==='sweep'){ws.reach=st.range;ws.anim=ws.animDur=Math.min(.26,st.cd*.6);ws.att='sweep';
  for(const e of W.enemies){if(e.dead)continue;const ex=e.x-wx,ey=e.y-12-wy,dd=hyp(ex,ey);
   if(dd<=st.range+e.r&&Math.abs(angDiff(a,Math.atan2(ey,ex)))<=1.1){hitWithWeapon(W,P,st,e,mul,ex/(dd||1),ey/(dd||1),crit);hits++;}}
  W.events.push({k:'swing',x:wx,y:wy,a,r:st.range,fire:!!st.burn});}
 else{ws.anim=ws.animDur=.12;ws.att='shot';const Pj=d.proj;
  if(d.att==='lob'){W.projs.push({lob:1,x:wx,y:wy,sx:wx,sy:wy,tx:tg.x,ty:tg.y,t:0,fl:Pj.flight,st,look:Pj.look,mul,owner:P});}
  else{P.shots++;const third=P.hasThird&&P.shots%3===0,sp=Pj.speed;
   W.projs.push({x:wx,y:wy,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,life:st.range*1.3/sp,pierce:st.pierce+(third?2:0),pr:st.pr,
    dmgMul:mul*(third?1.3:1),st,hit:new Set(),look:Pj.look,gold:third,owner:P});}
  W.events.push({k:'shot',x:wx,y:wy,look:Pj.look});
  if(mul>1){P.moveT=0;P.charge=false;W.events.push({k:'charge',x:P.x,y:P.y});}}
 if(hits&&mul>1){P.moveT=0;P.charge=false;W.events.push({k:'charge',x:P.x,y:P.y});}}
function hitWithWeapon(W,P,st,e,mul,ux,uy,crit){
 damageEnemy(W,e,st.dmg*mul,{weapon:1,owner:P,crit:crit??st.crit,cm:st.cm,knock:st.knock,ux,uy,burn:st.burn});}

// Danno a un nemico. opts: owner (giocatore che lo infligge), weapon (colpo d'arma: attiva ganci e furto di vita),
// crit, cm, knock, ux/uy, burn, src
function damageEnemy(W,e,dmg,o){if(e.dead)return;const P=o.owner||W.P[0],run=P.run,rng=W.rng;let crit=false;
 if(o.crit&&rng.next()<o.crit){dmg*=o.cm||2;crit=true;}
 dmg=Math.max(1,Math.round(dmg));
 // Conta la vita rimossa, prima dei ganci che possono infliggere altri danni.
 run.totalDamage+=Math.min(Math.max(0,e.hp),dmg);e.hp-=dmg;e.flash=.1;
 W.events.push({k:'dmg',x:e.x,y:e.y-e.r-18,v:dmg,crit,burn:o.src==='burn'});
 if(o.knock&&o.ux!=null){const k=o.knock*38*(1-(e.d.knockRes||0));e.kx+=o.ux*k;e.ky+=o.uy*k;}
 if(o.weapon){const s=stats(run,W.t);
  if(s.lifesteal>0&&P.lsN<10&&rng.next()<s.lifesteal/100){P.lsN++;healPlayer(W,P,1,true);}
  if(o.burn)igniteEnemy(W,P,e,o.burn,0);
  emit(run,'hit',{world:W,rng,player:P,enemy:e,x:e.x,y:e.y});
  if(crit)emit(run,'crit',{world:W,rng,player:P,enemy:e,x:e.x,y:e.y});}
 if(e.hp<=0)killEnemy(W,e,P);}
function igniteEnemy(W,P,e,burn,tier){if(e.dead)return;const s=stats(P.run,W.t);
 const dmg=byTier(burn.dmg,tier)+(burn.scaled?0:Math.round(s.elem*.5)),n=Math.round(byTier(burn.n,tier)*(1+s.burnx/100));
 if(!e.burn)e.burn={dmg,n,t:.5,owner:P};else{e.burn.dmg=Math.max(e.burn.dmg,dmg);e.burn.n=Math.max(e.burn.n,n);}}
function explosion(W,P,x,y,dmg,r,raw){const s=stats(P.run,W.t);
 if(!raw)dmg=(dmg+s.elem)*(1+s.dmg/100);dmg*=1+s.expl/100;
 W.events.push({k:'expl',x,y,r});
 for(const e of W.enemies)if(!e.dead&&hyp(e.x-x,e.y-y)<r+e.r)damageEnemy(W,e,dmg,{src:'expl',owner:P,crit:raw?raw.crit:0,cm:raw?raw.cm:2,burn:null});}
function killEnemy(W,e,P){if(e.dead)return;e.dead=true;const run=P.run,rng=W.rng,s=stats(run,W.t);run.kills++;
 W.events.push({k:'death',x:e.x,y:e.y,type:e.type,face:e.face});
 for(let i=0;i<e.d.val;i++)dropPickup(W,'gold',e.x,e.y);
 const luck=1+s.luck/100;
 if(e.d.elite||rng.next()<.012*luck)dropPickup(W,'crate',e.x,e.y);
 else if(rng.next()<.02*luck)dropPickup(W,'bread',e.x,e.y);
 emit(run,'kill',{world:W,rng,player:P,enemy:e,x:e.x,y:e.y});
 if(e.d.boss){W.bossDead=true;finishWave(W);}}

// ---------- costruzioni (balestre da muro, trabucchetti) ----------
const STRUCTS={balestra:{dmg:5,sc:1,cd:1.3,range:330,look:'dardo'},trabucco:{dmg:12,sc:1.5,cd:3.2,range:420,lob:1,r:65}};
function summon(W,P,type){const rng=W.rng;let x,y;
 for(let k=0;k<10;k++){const a=rng.next()*TAU,d=rng.range(60,170);x=clamp(P.x+Math.cos(a)*d,30,ARENA.w-30);y=clamp(P.y+Math.sin(a)*d,40,ARENA.h-20);
  if(!W.structs.some(o=>hyp(o.x-x,o.y-y)<40))break;}
 W.structs.push({type,x,y,cd:rng.range(.3,1),ang:0,anim:0,owner:P});}
function updateStruct(W,o){if(o.owner.gone)return;const D=STRUCTS[o.type],s=stats(o.owner.run,W.t);o.cd-=DT;if(o.anim>0)o.anim-=DT;
 const tg=nearestEnemy(W,o.x,o.y,D.range);if(!tg)return;o.ang=Math.atan2(tg.y-o.y,tg.x-o.x);if(o.cd>0)return;o.cd=D.cd;o.anim=.25;
 const dmg=Math.max(1,D.dmg+s.eng*D.sc),st={dmg,crit:.03,cm:2,knock:3,pierce:0,pr:.5,burn:null,expl:D.r||0};
 if(D.lob)W.projs.push({lob:1,x:o.x,y:o.y-20,sx:o.x,sy:o.y-20,tx:tg.x,ty:tg.y,t:0,fl:.9,st,look:'sasso',mul:1,struct:1,owner:o.owner});
 else{const sp=900;W.projs.push({x:o.x,y:o.y-14,vx:Math.cos(o.ang)*sp,vy:Math.sin(o.ang)*sp,life:D.range*1.3/sp,pierce:0,pr:.5,dmgMul:1,st,hit:new Set(),look:'dardo',struct:1,owner:o.owner});}}

// ---------- proiettili ----------
// Primo punto d'impatto sul segmento percorso durante questo passo (evita di saltare i bersagli).
function segmentHit(x0,y0,x1,y1,cx,cy,r){const dx=x1-x0,dy=y1-y0,ox=x0-cx,oy=y0-cy,c=ox*ox+oy*oy-r*r;
 if(c<=0)return 0;const a=dx*dx+dy*dy;if(!a)return null;const b=ox*dx+oy*dy,disc=b*b-a*c;
 if(disc<0)return null;const t=(-b-Math.sqrt(disc))/a;return t>=0&&t<=1?t:null;}

function updateProjs(W){for(const q of W.projs){
  if(q.lob){q.t+=DT;const u=Math.min(1,q.t/q.fl);q.x=lerp(q.sx,q.tx,u);q.y=lerp(q.sy,q.ty,u);q.h=Math.sin(u*Math.PI)*60;
   if(u>=1){q.dead=true;explosion(W,q.owner,q.tx,q.ty,q.st.dmg*q.mul,q.st.expl,{crit:q.st.crit,cm:q.st.cm});
    if(q.st.burn)for(const e of W.enemies)if(!e.dead&&hyp(e.x-q.tx,e.y-q.ty)<q.st.expl+e.r)igniteEnemy(W,q.owner,e,q.st.burn,0);}continue;}
  const x0=q.x,y0=q.y,travel=Math.max(0,Math.min(DT,q.life));q.x+=q.vx*travel;q.y+=q.vy*travel;q.life-=DT;
  const hits=[];for(const e of W.enemies){if(e.dead||q.hit.has(e))continue;const t=segmentHit(x0,y0,q.x,q.y,e.x,e.y-12,e.r+5);if(t!=null)hits.push({e,t});}
  hits.sort((a,b)=>a.t-b.t||a.e.id-b.e.id);
  for(const {e} of hits){if(e.dead)continue;
   q.hit.add(e);const sp=Math.hypot(q.vx,q.vy);
   damageEnemy(W,e,q.st.dmg*q.dmgMul,{weapon:!q.struct,owner:q.owner,crit:q.st.crit,cm:q.st.cm,knock:q.st.knock,ux:q.vx/sp,uy:q.vy/sp,burn:q.st.burn});
   if(q.pierce>0){q.pierce--;q.dmgMul*=1-q.pr;}else{q.dead=true;break;}}
  if(q.life<=0||q.x<-20||q.y<-20||q.x>ARENA.w+20||q.y>ARENA.h+20)q.dead=true;}
 if(W.projs.some(q=>q.dead))W.projs=W.projs.filter(q=>!q.dead);}
function updateEnemyProjs(W){for(const q of W.eprojs){const x0=q.x,y0=q.y,travel=Math.max(0,Math.min(DT,q.life));q.x+=q.vx*travel;q.y+=q.vy*travel;q.life-=DT;
  const hits=[];for(const P of W.P){if(P.dead)continue;const t=segmentHit(x0,y0,q.x,q.y,P.x,P.y-12,P.r+5);if(t!=null)hits.push({P,t});}
  hits.sort((a,b)=>a.t-b.t||a.P.i-b.P.i);
  if(hits.length){q.dead=true;hurtPlayer(W,hits[0].P,q.dmg,'dardo');}
  if(q.life<=0||q.x<-20||q.y<-20||q.x>ARENA.w+20||q.y>ARENA.h+20)q.dead=true;}
 if(W.eprojs.some(q=>q.dead))W.eprojs=W.eprojs.filter(q=>!q.dead);}

// ---------- fiorini, bottini, pane ----------
// I fiorini volano verso il giocatore vicino, ma il ricavato va a tutta la squadra.
function dropPickup(W,kind,x,y){const rng=W.rng,a=rng.next()*TAU,v=rng.range(40,140);
 W.pickups.push({kind,x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v,to:null,t:0});}
// Un fiorino raccolto vale W.coinMul XP base per la squadra (1 da soli), ripartita fra tutti
// i connessi (anche caduti). Bonus XP applicato soltanto alla propria quota.
// La Raccolta di fine ondata resta personale; i ganci si attivano una sola volta sul raccoglitore.
function sharePickupXp(W){const recipients=W.P.filter(P=>!P.gone),n=recipients.length;
 if(!n)return;for(const P of recipients)addXp(P.run,(1+stats(P.run,W.t).xp/100)*W.coinMul/n,W.n>1?1e-9:0);}
// Quote intere: i resti ruotano per posto, anche fra ondate. Nessun portafoglio
// comune da spendere: ogni giocatore conserva e usa la propria quota.
const rewardSlot=P=>P.slot??P.i;
function rewardStart(players,next){const i=players.findIndex(P=>rewardSlot(P)>=next);return i<0?0:i;}
function shareCombatGold(W,amount){const players=W.P.filter(P=>!P.gone).sort((a,b)=>rewardSlot(a)-rewardSlot(b)),n=players.length;
 if(!n||amount<=0)return;const lead=W.P[0].run,start=rewardStart(players,lead.goldTurn||0),base=Math.floor(amount/n),rest=amount%n;
 players.forEach((P,i)=>{P.run.gold+=base+((i-start+n)%n<rest?1:0);});
 if(n>1)lead.goldTurn=rewardSlot(players[(start+rest)%n]);}
function collectGold(W){const players=W.P.filter(P=>!P.gone).sort((a,b)=>rewardSlot(a)-rewardSlot(b)),n=players.length;
 if(!n)return;const lead=W.P[0].run,start=rewardStart(players,lead.bagTurn||0);let amount=1;
 // Al massimo un fiorino di riserva per moneta raccolta, anche con quattro borse.
 for(let k=0;k<n;k++){const P=players[(start+k)%n];if(P.run.bag<=0)continue;
  P.run.bag--;amount++;if(n>1)lead.bagTurn=rewardSlot(players[(start+k+1)%n]);break;}
 // in compagnia la moneta vale W.coinMul: le frazioni restano da parte (goldFrac) finché non fanno un fiorino intero
 if(W.coinMul!==1){const v=amount*W.coinMul+(lead.goldFrac||0);amount=Math.floor(v+1e-9);lead.goldFrac=v-amount;}
 shareCombatGold(W,amount);}
function updatePickups(W){const radius=W.P.map(P=>PLAYER.pickup*(1+stats(P.run,W.t).pickup/100));
 for(const k of W.pickups){k.t+=DT;
  if(k.to&&k.to.dead)k.to=null;
  if(!k.to&&k.kind!=='bread'){let bd=Infinity;for(const P of W.P){if(P.dead)continue;const d=hyp(P.x-k.x,P.y-8-k.y);if(d<radius[P.i]&&d<bd){bd=d;k.to=P;}}}
  if(k.to){const P=k.to,dx=P.x-k.x,dy=P.y-8-k.y,d=Math.hypot(dx,dy)||1,v=420+k.t*200;const travel=Math.min(d,v*DT);k.x+=dx/d*travel;k.y+=dy/d*travel;}
  else{k.x+=k.vx*DT;k.y+=k.vy*DT;k.vx*=Math.exp(-6*DT);k.vy*=Math.exp(-6*DT);}
  for(const P of W.P){if(P.dead||hyp(P.x-k.x,P.y-8-k.y)>=P.r+8)continue;const run=P.run;k.dead=true;
   if(k.kind==='gold'){collectGold(W);sharePickupXp(W);W.events.push({k:'coin',x:k.x,y:k.y,pl:P.i});emit(run,'pickup',{world:W,rng:W.rng,player:P,x:k.x,y:k.y});}
   else if(k.kind==='crate'){run.cratesPending++;W.events.push({k:'text',x:P.x,y:P.y-40,t:'Bottino!',col:'#f0c040'});}
   else healPlayer(W,P,3);
   break;}}
 if(W.pickups.some(k=>k.dead))W.pickups=W.pickups.filter(k=>!k.dead);}

// ---------- fine ondata ----------
// I fiorini rimasti a terra si dividono fra le borse di tutti; i bottini a turno.
function finishWave(W){if(W.over)return;if(!alive(W).length){W.over='dead';W.events.push({k:'dead'});return;}W.over='win';let gold=0,c=0;
 const recipients=W.P.filter(P=>!P.gone),n=recipients.length;
 for(const k of W.pickups){if(k.kind==='gold')gold++;else if(k.kind==='crate')recipients[(W.wave-1+c++)%n].run.cratesPending++;}
 recipients.forEach((P,i)=>{P.run.bag+=Math.floor(gold/n)+((i-(W.wave-1)%n+n)%n<gold%n?1:0);});
 W.pickups=[];for(const e of W.enemies)if(!e.dead){e.dead=true;W.events.push({k:'death',x:e.x,y:e.y,type:e.type,face:e.face,quiet:1});}
 for(const P of recipients)emit(P.run,'waveEnd',{world:W,rng:W.rng,player:P});W.events.push({k:'waveEnd'});}
