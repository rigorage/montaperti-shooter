'use strict';
// ===================== l'ondata =====================
// Tempo fisso: 60 passi al secondo. Nessun disegno: gli eventi (danni, morti, esplosioni) finiscono in W.events
// e chi disegna li legge. Così la stessa simulazione gira anche senza schermo (tools/simula.js).
const DT=1/60;

function newWorld(run){computeStats(run,0);const s=run.stats,wave=WAVES[run.wave-1];
 const W={run,rng:run.rng,t:0,dur:wave.dur,wave:run.wave,over:null,cheat:{god:false},
  p:{x:ARENA.w/2,y:ARENA.h/2,r:PLAYER.r,hp:s.maxhp,iframes:0,face:1,moving:false,moveT:0,regenT:0,lsT:0,lsN:0,walkT:0},
  enemies:[],projs:[],eprojs:[],pickups:[],structs:[],pending:[],events:[],
  groups:wave.g.map(g=>({...g,next:g.from})),shots:0,lastSec:0,
  weapons:run.weapons.map((w,i)=>({w,d:WEAPONS[w.id],tier:w.tier,i,ang:-Math.PI/2+i,cd:.3+i*.07,anim:0,animDur:.2,reach:0,att:null,st:null,stRef:null}))};
 W.hasCharge=hasFlag(run,'charge');W.hasThird=hasFlag(run,'third');
 emit(run,'waveStart',{world:W,rng:W.rng});
 return W;}

// ---------- statistiche di un'arma (rifatte solo quando cambiano le statistiche) ----------
function weaponStats(W,ws){const s=stats(W.run,W.t);if(ws.stRef===s)return ws.st;ws.st=calcWeaponStats(s,ws.d,ws.tier);ws.stRef=s;return ws.st;}
function calcWeaponStats(s,d,t){
 let base=byTier(d.dmg,t);for(const [k,c] of Object.entries(d.sc))base+=s[k]*c;
 const v=s.atkspd/100,cd0=byTier(d.cd,t);
 const st={dmg:Math.max(1,Math.round(Math.max(1,base)*(1+s.dmg/100))),
  cd:Math.max(.1,v>=0?cd0/(1+v):cd0*(1-v)),
  range:Math.max(40,d.range+(d.kind==='melee'?s.range/2:s.range)),
  crit:d.crit+s.crit/100,cm:d.cm,knock:d.knock+s.knock,
  pierce:d.proj?(d.proj.pierce||0)+s.pierce:0,pr:d.proj?.pr??.5,
  burn:d.burn?{dmg:Math.max(1,byTier(d.burn.dmg,t)+Math.round(s.elem*.5)),n:d.burn.n,scaled:1}:null,
  expl:d.expl?byTier(d.expl.r,t):0};
 return st;}
function weaponPos(W,ws){const n=W.weapons.length,a=ws.i/n*TAU-Math.PI/2+(n>1?.0:0),r=n>1?24:14;
 return [W.p.x+Math.cos(a)*r,W.p.y-10+Math.sin(a)*r*.7];}

// ---------- un passo ----------
function step(W,inp){if(W.over)return;W.t+=DT;const run=W.run,s=stats(run,W.t),p=W.p;
 // giocatore
 let mx=inp.x||0,my=inp.y||0;const ml=Math.hypot(mx,my);if(ml>1){mx/=ml;my/=ml;}
 const spd=PLAYER.speed*Math.max(.25,1+s.speed/100);
 p.x=clamp(p.x+mx*spd*DT,20,ARENA.w-20);p.y=clamp(p.y+my*spd*DT,24,ARENA.h-14);
 p.moving=ml>.1;if(mx>.1)p.face=1;else if(mx<-.1)p.face=-1;
 if(p.moving){p.moveT+=DT;p.walkT+=DT;}else p.moveT=Math.max(0,p.moveT-DT*3);
 p.charge=W.hasCharge&&p.moveT>=1;
 p.iframes-=DT;
 if(p.hp>s.maxhp)p.hp=s.maxhp;
 if(s.regen>0){p.regenT+=DT;const iv=5/(1+(s.regen-1)/2.25);if(p.regenT>=iv){p.regenT=0;healPlayer(W,1,true);}}
 p.lsT-=DT;if(p.lsT<=0){p.lsT=1;p.lsN=0;}
 // ganci a intervallo
 const sec=Math.floor(W.t);if(sec>W.lastSec){W.lastSec=sec;for(const t of run.trig.interval||[])if(sec%t.fx.every===0)for(let c=0;c<t.count;c++)doAction(run,t.fx.do,t.tier,{world:W,rng:W.rng});}
 spawning(W);
 for(const e of W.enemies)if(!e.dead)updateEnemy(W,e);
 separate(W);
 for(const ws of W.weapons)updateWeapon(W,ws);
 for(const st of W.structs)updateStruct(W,st);
 updateProjs(W);updateEnemyProjs(W);updatePickups(W);
 if(W.enemies.some(e=>e.dead))W.enemies=W.enemies.filter(e=>!e.dead);
 if(p.hp<=0){W.over='dead';W.events.push({k:'dead',x:p.x,y:p.y});return;}
 if(W.t>=W.dur)finishWave(W);}

// ---------- comparsa dei nemici (con il segno rosso di avviso) ----------
function spawning(W){const rng=W.rng;
 for(const g of W.groups){while(W.t>=g.next&&g.next<g.to){
  if(W.enemies.length+W.pending.length<MAX_ENEMIES||ENEMIES[g.e].boss||ENEMIES[g.e].elite){
   const n=rng.int(g.n[0],g.n[1]);let cx,cy;
   for(let k=0;k<12;k++){cx=rng.range(70,ARENA.w-70);cy=rng.range(70,ARENA.h-70);if(hyp(cx-W.p.x,cy-W.p.y)>300)break;}
   for(let i=0;i<n;i++)W.pending.push({type:g.e,x:clamp(cx+rng.range(-55,55),30,ARENA.w-30),y:clamp(cy+rng.range(-55,55),30,ARENA.h-30),t:ENEMIES[g.e].boss?1.8:.9});}
  g.next=g.once?Infinity:g.next+Math.max(.5,g.every);}}
 for(const q of W.pending){q.t-=DT;if(q.t<=0)spawnEnemy(W,q.type,q.x,q.y);}
 W.pending=W.pending.filter(q=>q.t>0);}
function spawnEnemy(W,type,x,y){const d=ENEMIES[type],w=W.wave,D=DANGER[W.run.danger],rng=W.rng;
 const hp=Math.max(1,Math.round((d.hp+d.hpW*(w-1))*D.hp));
 const e={type,d,x,y,hp,maxhp:hp,dmg:Math.max(1,Math.round((d.dmg+d.dmgW*(w-1))*D.dmg)),spd:d.spd*rng.range(.92,1.08),r:d.r,
  kx:0,ky:0,t:0,cd:d.cd?rng.range(.4,1)*d.cd:2,cd2:4,state:'walk',st:0,dx:0,dy:0,burn:null,flash:0,buff:0,face:1,anim:rng.next()*4,dead:false,
  wander:rng.next()*TAU,phase:0};
 W.enemies.push(e);return e;}

// ---------- nemici ----------
function updateEnemy(W,e){const p=W.p,rng=W.rng;e.t+=DT;e.flash-=DT;e.cd-=DT;e.cd2-=DT;
 let dx=p.x-e.x,dy=p.y-e.y;const dist=Math.hypot(dx,dy)||1;dx/=dist;dy/=dist;
 let vx=0,vy=0;const spd=e.spd*(e.buff?1.25:1);
 switch(e.d.beh){
  case 'chase':vx=dx*spd;vy=dy*spd;break;
  case 'shooter':{const R=e.d.range;if(dist>R*.9){vx=dx*spd;vy=dy*spd;}else if(dist<R*.55){vx=-dx*spd;vy=-dy*spd;}else{vx=-dy*spd*.35;vy=dx*spd*.35;}
   if(e.cd<=0&&dist<R*1.15){e.cd=e.d.cd;shootAt(W,e.x,e.y-14,Math.atan2(p.y-e.y,p.x-e.x),e.dmg,260);e.state='shoot';e.st=.3;}break;}
  case 'charger':
   if(e.state==='aim'){e.st-=DT;if(e.st<=0){e.state='dash';e.st=.65;}}
   else if(e.state==='dash'){vx=e.dx*spd*3.3;vy=e.dy*spd*3.3;e.st-=DT;if(e.st<=0){e.state='walk';e.cd=2.2;}}
   else{vx=dx*spd*.8;vy=dy*spd*.8;if(dist<330&&e.cd<=0){e.state='aim';e.st=.55;e.dx=dx;e.dy=dy;}}break;
  case 'healer':
   if(dist<330){vx=-dx*spd;vy=-dy*spd;}else{e.wander+=rng.range(-.1,.1);vx=Math.cos(e.wander)*spd*.4;vy=Math.sin(e.wander)*spd*.4;}
   if(e.cd<=0){e.cd=3.5;for(const o of W.enemies)if(o!==e&&!o.dead&&o.hp<o.maxhp&&hyp(o.x-e.x,o.y-e.y)<170){o.hp=Math.min(o.maxhp,o.hp+Math.ceil(o.maxhp*.3));W.events.push({k:'heal',x:o.x,y:o.y});}
    W.events.push({k:'aura',x:e.x,y:e.y,r:170,col:'#9be07a'});}break;
  case 'buffer':vx=dx*spd;vy=dy*spd;
   if(e.cd<=0){e.cd=5;for(const o of W.enemies)if(o!==e&&!o.dead&&!o.buff&&!o.d.boss&&hyp(o.x-e.x,o.y-e.y)<180){o.buff=1;o.maxhp=Math.round(o.maxhp*1.3);o.hp=Math.round(o.hp*1.3);o.dmg+=1;}
    W.events.push({k:'aura',x:e.x,y:e.y,r:180,col:'#e0b030'});}break;
  case 'spawner':
   if(dist<280){vx=-dx*spd;vy=-dy*spd;}else{vx=dx*spd*.5;vy=dy*spd*.5;}
   if(e.cd<=0){e.cd=5;for(let i=0;i<2;i++)if(W.enemies.length<MAX_ENEMIES)spawnEnemy(W,'brigante',e.x+rng.range(-25,25),e.y+rng.range(-25,25));}break;
  case 'elite':case 'boss':{const boss=e.d.boss;
   if(e.state==='aim'){e.st-=DT;if(e.st<=0){e.state='dash';e.st=.6;}}
   else if(e.state==='dash'){vx=e.dx*spd*3.4;vy=e.dy*spd*3.4;e.st-=DT;if(e.st<=0){e.state='walk';}}
   else{vx=dx*spd;vy=dy*spd;if(!boss&&e.cd2<=0&&dist<380){e.state='aim';e.st=.7;e.dx=dx;e.dy=dy;e.cd2=7;}}
   if(e.cd<=0){const angry=e.hp<e.maxhp*.5,n=boss?(angry?24:18):12;e.cd=boss?(angry?3:4.2):5;e.phase+=.13;
    for(let i=0;i<n;i++)shootAt(W,e.x,e.y-20,e.phase+i/n*TAU,Math.max(1,Math.round(e.dmg*.7)),boss?190:210);}
   if(boss&&e.cd2<=0){e.cd2=8;for(let i=0;i<4;i++)if(W.enemies.length<MAX_ENEMIES)spawnEnemy(W,i%2?'tagliagole':'brigante',e.x+rng.range(-60,60),e.y+rng.range(-40,40));}
   break;}
 }
 if(e.state==='shoot'){e.st-=DT;if(e.st<=0)e.state='walk';}
 e.kx*=Math.exp(-9*DT);e.ky*=Math.exp(-9*DT);
 e.x=clamp(e.x+(vx+e.kx)*DT,14,ARENA.w-14);e.y=clamp(e.y+(vy+e.ky)*DT,18,ARENA.h-10);
 if(Math.abs(vx)>5)e.face=vx>0?1:-1;
 e.anim+=DT*(Math.hypot(vx,vy)/60);
 if(e.burn){e.burn.t-=DT;if(e.burn.t<=0){e.burn.t=.5;e.burn.n--;damageEnemy(W,e,e.burn.dmg,{src:'burn'});if(e.burn&&e.burn.n<=0)e.burn=null;}}
 if(!e.dead&&dist<e.r+p.r)hurtPlayer(W,e.dmg,e.type);}
// Spinta morbida fra nemici, così non si ammucchiano in un punto.
function separate(W){const E=W.enemies,n=E.length;
 for(let i=0;i<n;i++){const a=E[i];if(a.dead)continue;
  for(let j=i+1;j<n;j++){const b=E[j];if(b.dead)continue;const dx=b.x-a.x,dy=b.y-a.y,R=(a.r+b.r)*.8;
   if(dx>R||dx<-R||dy>R||dy<-R)continue;const d=Math.hypot(dx,dy)||.01;if(d>=R)continue;
   const push=(R-d)*.5,ux=dx/d,uy=dy/d,wa=b.d.boss?1:a.d.boss?0:.5;a.x-=ux*push*wa;a.y-=uy*push*wa;b.x+=ux*push*(1-wa);b.y+=uy*push*(1-wa);}}}
function shootAt(W,x,y,ang,dmg,speed,src){W.eprojs.push({x,y,vx:Math.cos(ang)*speed,vy:Math.sin(ang)*speed,dmg,life:4.5,src});}

// ---------- giocatore ----------
const armorCoef=a=>a>=0?10/(10+a/1.5):2-10/(10+(-a)/1.5);
function hurtPlayer(W,dmg,src){const p=W.p;if(p.iframes>0||W.over||W.cheat.god)return;p.lastSrc=src;const run=W.run,s=stats(run,W.t);
 if(W.rng.next()<s.dodge/100){p.iframes=.2;W.events.push({k:'text',x:p.x,y:p.y-34,t:'schivato',col:'#cfe8ff'});emit(run,'dodge',{world:W,rng:W.rng,x:p.x,y:p.y});return;}
 const taken=Math.max(1,Math.round(dmg*armorCoef(s.armor)));p.hp-=taken;
 p.iframes=clamp(taken/s.maxhp*.4/.15,.2,.4);
 W.events.push({k:'hurt',x:p.x,y:p.y,v:taken});
 emit(run,'hurt',{world:W,rng:W.rng,x:p.x,y:p.y});}
function healPlayer(W,n,quiet){if(!W)return;const s=stats(W.run,W.t),p=W.p;
 const v=Math.max(1,Math.round(n*(1+s.heal/100)));const before=p.hp;p.hp=Math.min(s.maxhp,p.hp+v);
 if(p.hp>before&&!quiet)W.events.push({k:'text',x:p.x,y:p.y-34,t:'+'+(p.hp-before),col:'#7fe07a'});
 if(p.hp>before&&quiet)W.events.push({k:'regen',x:p.x,y:p.y});}

// ---------- armi ----------
function nearestEnemy(W,x,y,range){let best=null,bd=Infinity;
 for(const e of W.enemies){if(e.dead)continue;const d=hyp(e.x-x,e.y-y)-e.r;if(d<range&&d<bd){bd=d;best=e;}}return best;}
function updateWeapon(W,ws){const st=weaponStats(W,ws);ws.cd-=DT;if(ws.anim>0)ws.anim-=DT;
 const [wx,wy]=weaponPos(W,ws);const tg=nearestEnemy(W,wx,wy,st.range);
 if(tg){const a=Math.atan2(tg.y-12-wy,tg.x-wx);if(ws.anim<=0)ws.ang+=angDiff(ws.ang,a)*Math.min(1,DT*18);}
 else if(ws.anim<=0)ws.ang+=angDiff(ws.ang,W.p.face>0?-.35:Math.PI+.35)*DT*4;
 if(ws.cd>0||!tg)return;
 ws.cd=st.cd;const a=Math.atan2(tg.y-12-wy,tg.x-wx);ws.ang=a;const d=ws.d;
 const mul=W.p.charge?1.6:1;let hits=0;
 if(d.att==='thrust'){const reach=Math.min(st.range,hyp(tg.x-wx,tg.y-12-wy));const ux=Math.cos(a),uy=Math.sin(a);
  ws.reach=reach;ws.anim=ws.animDur=Math.min(.22,st.cd*.6);ws.att='thrust';
  for(const e of W.enemies){if(e.dead)continue;const ex=e.x-wx,ey=e.y-12-wy,along=clamp(ex*ux+ey*uy,0,reach);
   if(hyp(ex-ux*along,ey-uy*along)<e.r+10){hitWithWeapon(W,ws,st,e,mul,ux,uy);hits++;}}}
 else if(d.att==='sweep'){ws.reach=st.range;ws.anim=ws.animDur=Math.min(.26,st.cd*.6);ws.att='sweep';
  for(const e of W.enemies){if(e.dead)continue;const ex=e.x-wx,ey=e.y-12-wy,dd=hyp(ex,ey);
   if(dd<=st.range+e.r&&Math.abs(angDiff(a,Math.atan2(ey,ex)))<=1.1){hitWithWeapon(W,ws,st,e,mul,ex/(dd||1),ey/(dd||1));hits++;}}
  W.events.push({k:'swing',x:wx,y:wy,a,r:st.range,fire:!!st.burn});}
 else{ws.anim=ws.animDur=.12;ws.att='shot';const P=d.proj;
  if(d.att==='lob'){const tx=tg.x,ty=tg.y;W.projs.push({lob:1,x:wx,y:wy,sx:wx,sy:wy,tx,ty,t:0,fl:P.flight,ws,st,look:P.look,mul});}
  else{W.shots++;const third=W.hasThird&&W.shots%3===0,sp=P.speed;
   W.projs.push({x:wx,y:wy,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,life:st.range*1.3/sp,pierce:st.pierce+(third?2:0),pr:st.pr,
    dmgMul:mul*(third?1.3:1),ws,st,hit:new Set(),look:P.look,gold:third});}
  W.events.push({k:'shot',x:wx,y:wy,look:P.look});
  if(mul>1){W.p.moveT=0;W.events.push({k:'charge',x:W.p.x,y:W.p.y});}}
 if(hits&&mul>1){W.p.moveT=0;W.events.push({k:'charge',x:W.p.x,y:W.p.y});}}
function hitWithWeapon(W,ws,st,e,mul,ux,uy){
 damageEnemy(W,e,st.dmg*mul,{weapon:1,crit:st.crit,cm:st.cm,knock:st.knock,ux,uy,burn:st.burn});}

// Danno a un nemico. opts: weapon (colpo d'arma: attiva ganci e furto di vita), crit, cm, knock, ux/uy, burn, src
function damageEnemy(W,e,dmg,o){if(e.dead)return;const run=W.run,rng=W.rng;let crit=false;
 if(o.crit&&rng.next()<o.crit){dmg*=o.cm||2;crit=true;}
 dmg=Math.max(1,Math.round(dmg));e.hp-=dmg;e.flash=.1;
 W.events.push({k:'dmg',x:e.x,y:e.y-e.r-18,v:dmg,crit,burn:o.src==='burn'});
 if(o.knock&&o.ux!=null){const k=o.knock*38*(1-(e.d.knockRes||0));e.kx+=o.ux*k;e.ky+=o.uy*k;}
 if(o.weapon){const s=stats(run,W.t);
  if(s.lifesteal>0&&W.p.lsN<10&&rng.next()<s.lifesteal/100){W.p.lsN++;healPlayer(W,1,true);}
  if(o.burn)igniteEnemy(W,e,o.burn,0);
  emit(run,'hit',{world:W,rng,enemy:e,x:e.x,y:e.y});
  if(crit)emit(run,'crit',{world:W,rng,enemy:e,x:e.x,y:e.y});}
 if(e.hp<=0)killEnemy(W,e);}
function igniteEnemy(W,e,burn,tier){if(e.dead)return;const s=stats(W.run,W.t);
 const dmg=byTier(burn.dmg,tier)+(burn.scaled?0:Math.round(s.elem*.5)),n=Math.round(byTier(burn.n,tier)*(1+s.burnx/100));
 if(!e.burn)e.burn={dmg,n,t:.5};else{e.burn.dmg=Math.max(e.burn.dmg,dmg);e.burn.n=Math.max(e.burn.n,n);}}
function explosion(W,x,y,dmg,r,raw){const s=stats(W.run,W.t);
 if(!raw)dmg=(dmg+s.elem)*(1+s.dmg/100);dmg*=1+s.expl/100;
 W.events.push({k:'expl',x,y,r});
 for(const e of W.enemies)if(!e.dead&&hyp(e.x-x,e.y-y)<r+e.r)damageEnemy(W,e,dmg,{src:'expl',crit:raw?raw.crit:0,cm:raw?raw.cm:2,burn:null});}
function killEnemy(W,e){if(e.dead)return;e.dead=true;const run=W.run,rng=W.rng,s=stats(run,W.t);run.kills++;
 W.events.push({k:'death',x:e.x,y:e.y,e});
 for(let i=0;i<e.d.val;i++)dropPickup(W,'gold',e.x,e.y);
 const luck=1+s.luck/100;
 if(e.d.elite||rng.next()<.012*luck)dropPickup(W,'crate',e.x,e.y);
 else if(rng.next()<.02*luck)dropPickup(W,'bread',e.x,e.y);
 emit(run,'kill',{world:W,rng,enemy:e,x:e.x,y:e.y});
 if(e.d.boss){W.bossDead=true;finishWave(W);}}

// ---------- costruzioni (balestre da muro, trabucchetti) ----------
const STRUCTS={balestra:{dmg:5,sc:1,cd:1.3,range:330,look:'dardo'},trabucco:{dmg:12,sc:1.5,cd:3.2,range:420,lob:1,r:65}};
function summon(W,type){const rng=W.rng;let x,y;
 for(let k=0;k<10;k++){const a=rng.next()*TAU,d=rng.range(60,170);x=clamp(W.p.x+Math.cos(a)*d,30,ARENA.w-30);y=clamp(W.p.y+Math.sin(a)*d,40,ARENA.h-20);
  if(!W.structs.some(o=>hyp(o.x-x,o.y-y)<40))break;}
 W.structs.push({type,x,y,cd:rng.range(.3,1),ang:0,anim:0});}
function updateStruct(W,o){const D=STRUCTS[o.type],s=stats(W.run,W.t);o.cd-=DT;if(o.anim>0)o.anim-=DT;
 const tg=nearestEnemy(W,o.x,o.y,D.range);if(!tg)return;o.ang=Math.atan2(tg.y-o.y,tg.x-o.x);if(o.cd>0)return;o.cd=D.cd;o.anim=.25;
 const dmg=Math.max(1,D.dmg+s.eng*D.sc),st={dmg,crit:.03,cm:2,knock:3,pierce:0,pr:.5,burn:null,expl:D.r||0};
 if(D.lob)W.projs.push({lob:1,x:o.x,y:o.y-20,sx:o.x,sy:o.y-20,tx:tg.x,ty:tg.y,t:0,fl:.9,st,look:'sasso',mul:1,struct:1});
 else{const sp=900;W.projs.push({x:o.x,y:o.y-14,vx:Math.cos(o.ang)*sp,vy:Math.sin(o.ang)*sp,life:D.range*1.3/sp,pierce:0,pr:.5,dmgMul:1,st,hit:new Set(),look:'dardo',struct:1});}}

// ---------- proiettili ----------
function updateProjs(W){for(const q of W.projs){
  if(q.lob){q.t+=DT;const u=Math.min(1,q.t/q.fl);q.x=lerp(q.sx,q.tx,u);q.y=lerp(q.sy,q.ty,u);q.h=Math.sin(u*Math.PI)*60;
   if(u>=1){q.dead=true;explosion(W,q.tx,q.ty,q.st.dmg*q.mul,q.st.expl,{crit:q.st.crit,cm:q.st.cm});
    if(q.st.burn)for(const e of W.enemies)if(!e.dead&&hyp(e.x-q.tx,e.y-q.ty)<q.st.expl+e.r)igniteEnemy(W,e,q.st.burn,0);}continue;}
  q.x+=q.vx*DT;q.y+=q.vy*DT;q.life-=DT;if(q.life<=0||q.x<-20||q.y<-20||q.x>ARENA.w+20||q.y>ARENA.h+20){q.dead=true;continue;}
  for(const e of W.enemies){if(e.dead||q.hit.has(e))continue;if(hyp(e.x-q.x,e.y-12-q.y)>e.r+5)continue;
   q.hit.add(e);const sp=Math.hypot(q.vx,q.vy);
   damageEnemy(W,e,q.st.dmg*q.dmgMul,{weapon:!q.struct,crit:q.st.crit,cm:q.st.cm,knock:q.st.knock,ux:q.vx/sp,uy:q.vy/sp,burn:q.st.burn});
   if(q.pierce>0){q.pierce--;q.dmgMul*=1-q.pr;}else{q.dead=true;break;}}}
 if(W.projs.some(q=>q.dead))W.projs=W.projs.filter(q=>!q.dead);}
function updateEnemyProjs(W){const p=W.p;for(const q of W.eprojs){q.x+=q.vx*DT;q.y+=q.vy*DT;q.life-=DT;
  if(q.life<=0||q.x<-20||q.y<-20||q.x>ARENA.w+20||q.y>ARENA.h+20){q.dead=true;continue;}
  if(hyp(q.x-p.x,q.y-(p.y-12))<p.r+5){q.dead=true;hurtPlayer(W,q.dmg,'dardo');}}
 if(W.eprojs.some(q=>q.dead))W.eprojs=W.eprojs.filter(q=>!q.dead);}

// ---------- fiorini, bottini, pane ----------
function dropPickup(W,kind,x,y){const rng=W.rng,a=rng.next()*TAU,v=rng.range(40,140);
 W.pickups.push({kind,x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v,pull:false,t:0});}
function updatePickups(W){const p=W.p,run=W.run,s=stats(run,W.t),R=PLAYER.pickup*(1+s.pickup/100);
 for(const k of W.pickups){k.t+=DT;
  const dx=p.x-k.x,dy=p.y-8-k.y,d=Math.hypot(dx,dy)||1;
  if(k.kind!=='bread'&&d<R)k.pull=true;
  if(k.pull){const v=420+k.t*200;k.x+=dx/d*v*DT;k.y+=dy/d*v*DT;}
  else{k.x+=k.vx*DT;k.y+=k.vy*DT;k.vx*=Math.exp(-6*DT);k.vy*=Math.exp(-6*DT);}
  if(d<p.r+8){k.dead=true;
   if(k.kind==='gold'){run.gold++;if(run.bag>0){run.gold++;run.bag--;}addXp(run,1+s.xp/100);W.events.push({k:'coin',x:k.x,y:k.y});emit(run,'pickup',{world:W,rng:W.rng,x:k.x,y:k.y});}
   else if(k.kind==='crate'){run.cratesPending++;W.events.push({k:'text',x:p.x,y:p.y-40,t:'Bottino!',col:'#f0c040'});}
   else healPlayer(W,3);}}
 if(W.pickups.some(k=>k.dead))W.pickups=W.pickups.filter(k=>!k.dead);}

// ---------- fine ondata ----------
function finishWave(W){if(W.over)return;W.over='win';const run=W.run;
 for(const k of W.pickups){if(k.kind==='gold')run.bag++;else if(k.kind==='crate')run.cratesPending++;}
 W.pickups=[];for(const e of W.enemies)if(!e.dead){e.dead=true;W.events.push({k:'death',x:e.x,y:e.y,e,quiet:1});}
 emit(run,'waveEnd',{world:W,rng:W.rng});W.events.push({k:'waveEnd'});}
