'use strict';
// Deve coincidere con "version" in package.json (lo controlla tools/verify.cjs).
const GAME_VERSION='1.3.1';
