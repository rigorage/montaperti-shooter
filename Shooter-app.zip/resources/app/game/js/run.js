'use strict';
// ===================== la partita fra un'ondata e l'altra =====================
// Soldi, esperienza, livelli, bottega, inventario, bottini. Niente disegno e niente tempo reale.
const MAX_WEAPONS=6;
const LAST_WAVE=WAVES.length;

function newRun(charId,seed,danger=0){const ch=CHARS[charId];
 const run={charId,ch,seed,danger,rng:makeRng(seed),wave:1,gold:0,xp:0,level:0,levelsPending:0,
  weapons:[],items:{},gains:{},temp:[],counters:{},bag:0,kills:0,cratesPending:0,
  shop:{offers:[null,null,null,null],locked:[false,false,false,false],rerolls:0},
  dirty:true,stats:null,result:null,log:[]};
 for(const id of ch.start)run.weapons.push({id,tier:0});
 computeStats(run,0);return run;}

// ---------- esperienza ----------
const xpNeeded=level=>(4+level)**2; // per passare dal livello L al livello L+1 (Brotato: (3+L)²)
function addXp(run,v){run.xp+=v;while(run.xp>=xpNeeded(run.level)){run.xp-=xpNeeded(run.level);run.level++;run.levelsPending++;run.dirty=true;}}

// ---------- rarità (soglie per ondata e Fortuna, come in Brotato) ----------
const TIER_TAB=[null,{min:0,per:.06,cap:.6},{min:2,per:.02,cap:.25},{min:6,per:.0023,cap:.08}];
function tierChances(wave,luck){const th=[0,0,0,0];
 for(let t=1;t<4;t++){const T=TIER_TAB[t];th[t]=Math.min(T.cap,Math.max(0,(wave-1-T.min)*T.per)*(1+luck/100));}
 return th;}
function rollTier(run,wave,luck){const r=run.rng.next(),th=tierChances(wave,luck);
 for(let t=3;t>=1;t--)if(r<th[t])return t;return 0;}

// ---------- prezzi ----------
function priceOf(run,val){const s=stats(run);const w=run.wave;
 return Math.max(1,Math.round((val+w+val*w*.1)*(1+s.price/100)));}
const recycleOf=(run,val)=>Math.max(1,Math.floor(priceOf(run,val)*.25));
const weaponVal=w=>WEAPONS[w.id].val[w.tier];
function rerollPrice(run){const w=run.wave;return Math.floor(.75*w)+Math.max(1,Math.floor(.4*w))*(1+run.shop.rerolls);}

// ---------- bottega ----------
function rollOffer(run){const s=stats(run),tier=rollTier(run,run.wave,s.luck);
 if(run.rng.chance(.35)){
  let pool=Object.values(WEAPONS).filter(d=>d.minT<=tier);
  const owned=[...new Set(run.weapons.map(w=>w.id))].filter(id=>WEAPONS[id].minT<=tier);
  if(owned.length&&run.rng.chance(.3))pool=owned.map(id=>WEAPONS[id]);
  const d=run.rng.pick(pool);return {kind:'w',id:d.id,tier};}
 const ok=it=>it.max==null||(run.items[it.id]||0)<it.max;
 let pool=Object.values(ITEMS).filter(it=>it.t===tier&&ok(it));
 if(!pool.length)pool=Object.values(ITEMS).filter(it=>it.t<=tier&&ok(it));
 const it=run.rng.pick(pool);return {kind:'i',id:it.id,tier:it.t};}
function offerVal(o){return o.kind==='w'?WEAPONS[o.id].val[o.tier]:ITEMS[o.id].val;}
function offerPrice(run,o){return priceOf(run,offerVal(o));}
function openShop(run){run.shop.rerolls=0;const S=run.shop;
 for(let i=0;i<4;i++)if(!(S.locked[i]&&S.offers[i]))S.offers[i]=rollOffer(run);}
function reroll(run){const p=rerollPrice(run);if(run.gold<p)return false;run.gold-=p;run.shop.rerolls++;
 for(let i=0;i<4;i++)if(!run.shop.locked[i])run.shop.offers[i]=rollOffer(run);return true;}
function toggleLock(run,i){if(run.shop.offers[i])run.shop.locked[i]=!run.shop.locked[i];}
// Perché un'offerta non si può comprare (null = si può).
function cantBuy(run,i){const o=run.shop.offers[i];if(!o)return 'venduto';
 if(run.gold<offerPrice(run,o))return 'fiorini insufficienti';
 if(o.kind==='w'&&run.weapons.length>=MAX_WEAPONS&&!run.weapons.some(w=>w.id===o.id&&w.tier===o.tier&&w.tier<3))return 'posti per le armi pieni';
 if(o.kind==='i'){const it=ITEMS[o.id];if(it.max!=null&&(run.items[o.id]||0)>=it.max)return 'ne hai già il massimo';}
 return null;}
function buy(run,i){if(cantBuy(run,i))return false;const o=run.shop.offers[i];run.gold-=offerPrice(run,o);
 if(o.kind==='w')addWeapon(run,o.id,o.tier);else run.items[o.id]=(run.items[o.id]||0)+1;
 run.shop.offers[i]=null;run.shop.locked[i]=false;run.dirty=true;run.log.push((o.kind==='w'?'arma ':'')+o.id+(o.kind==='w'?' '+TIER_NAMES[o.tier]:''));return true;}

// ---------- armi ----------
function addWeapon(run,id,tier){
 if(run.weapons.length<MAX_WEAPONS){run.weapons.push({id,tier});run.dirty=true;return true;}
 const same=run.weapons.find(w=>w.id===id&&w.tier===tier&&w.tier<3); // posti pieni: si fonde da sola
 if(same){same.tier++;run.dirty=true;return true;}return false;}
function combineTarget(run,idx){const a=run.weapons[idx];if(!a||a.tier>=3)return -1;
 return run.weapons.findIndex((w,j)=>j!==idx&&w.id===a.id&&w.tier===a.tier);}
function combine(run,idx){const j=combineTarget(run,idx);if(j<0)return false;run.weapons[idx].tier++;run.weapons.splice(j,1);run.dirty=true;return true;}
function sellWeapon(run,idx){if(run.weapons.length<=1)return false;const w=run.weapons[idx];run.gold+=recycleOf(run,weaponVal(w));run.weapons.splice(idx,1);run.dirty=true;return true;}

// ---------- livelli ----------
function levelChoices(run){const s=stats(run),keys=Object.keys(UPGRADES),out=[];
 while(out.length<4){const k=run.rng.pick(keys);if(out.some(o=>o.s===k))continue;
  const t=rollTier(run,run.wave,s.luck);out.push({s:k,v:UPGRADES[k][t],tier:t});}
 return out;}
function applyUpgrade(run,c){run.gains[c.s]=(run.gains[c.s]||0)+c.v;run.levelsPending--;run.dirty=true;}

// ---------- bottini ----------
function openCrate(run){const s=stats(run);const t=Math.min(3,rollTier(run,run.wave+2,s.luck));
 const ok=it=>it.max==null||(run.items[it.id]||0)<it.max;
 let pool=Object.values(ITEMS).filter(it=>it.t===t&&ok(it));if(!pool.length)pool=Object.values(ITEMS).filter(ok);
 run.cratesPending--;return run.rng.pick(pool).id;}
function takeItem(run,id){run.items[id]=(run.items[id]||0)+1;run.dirty=true;}
function recycleItem(run,id){run.gold+=recycleOf(run,ITEMS[id].val);}

// ---------- fine ondata ----------
// Chiamata dopo che l'ondata è finita (vinta). Raccolta, pulizia degli effetti a tempo.
function endWave(run){run.temp=[];run.dirty=true;const s=stats(run);
 if(s.harvest>0){run.gold+=Math.floor(s.harvest);addXp(run,Math.floor(s.harvest));
  run.gains.harvest=(run.gains.harvest||0)+Math.ceil(s.harvest*.05);run.dirty=true;}
 if(run.wave>=LAST_WAVE){run.result='win';return;}
 openShop(run);}
function nextWave(run){run.wave++;run.dirty=true;}

// ---------- multigiocatore ----------
// Ogni giocatore gestisce bottega e livelli sul suo PC. A inizio ondata manda a chi ospita la sua "scheda"
// (personaggio, armi, oggetti, potenziamenti); chi ospita la simula e a fine ondata rimanda indietro
// quello che è cambiato (fiorini, esperienza, livelli, bottini, uccisioni).
const RESULT_KEYS=['gold','bag','xp','level','levelsPending','kills','cratesPending','gains','counters'];
function runSnapshot(run){return {charId:run.charId,danger:run.danger,wave:run.wave,weapons:run.weapons.map(w=>({id:w.id,tier:w.tier})),
 items:{...run.items},...runResult(run)};}
function runFromSnapshot(s){const ch=CHARS[s.charId];if(!ch)throw Error('Personaggio sconosciuto');
 const run={charId:s.charId,ch,danger:s.danger|0,wave:s.wave|0,rng:makeRng(1),weapons:[],items:{},temp:[],counters:{},gains:{},
  shop:{offers:[],locked:[],rerolls:0},dirty:true,stats:null,result:null,log:[]};
 for(const w of s.weapons||[])if(WEAPONS[w.id]&&w.tier>=0&&w.tier<=3&&run.weapons.length<MAX_WEAPONS)run.weapons.push({id:w.id,tier:w.tier|0});
 for(const [id,n] of Object.entries(s.items||{}))if(ITEMS[id])run.items[id]=Math.max(0,n|0);
 applyResult(run,s);return run;}
function runResult(run){const r={};for(const k of RESULT_KEYS)r[k]=typeof run[k]==='object'?JSON.parse(JSON.stringify(run[k])):run[k];return r;}
function applyResult(run,r){for(const k of RESULT_KEYS){if(r[k]===undefined)continue;
  if(k==='gains'||k==='counters'){const o={};for(const [a,v] of Object.entries(r[k]||{}))if(Number.isFinite(v))o[a]=v;run[k]=o;}
  else if(Number.isFinite(r[k]))run[k]=r[k];}
 run.dirty=true;}
