'use strict';
// ===================== sistema degli effetti =====================
// Cinque forme (vedi PROGETTO.md): modifica {s,v}, proporzione {per,of,each}, tetto {cap,v},
// gancio {on,chance,every,do}, regola speciale {flag}. Qui c'è l'unico punto che le interpreta.

// Tutte le fonti di effetti attive in questo momento, ciascuna con la sua qualità e il numero di copie.
function activeSources(run){const out=[];
 out.push({key:'char',fx:run.ch.fx,tier:0,count:1});
 for(const [id,n] of Object.entries(run.items))if(n>0)out.push({key:'item:'+id,fx:ITEMS[id].fx,tier:0,count:n});
 run.weapons.forEach((w,i)=>{const d=WEAPONS[w.id];if(d.fx)out.push({key:'wpn:'+i+':'+w.id,fx:d.fx,tier:w.tier,count:1});});
 for(const [fam,n] of Object.entries(familyCounts(run))){if(n<2)continue;const F=FAMILIES[fam];
  out.push({key:'fam:'+fam,fx:[{s:F.s,v:F.v[Math.min(n,6)-2]}],tier:0,count:1});}
 if(hasFlag(run,'popolo')){const m=run.weapons.filter(w=>WEAPONS[w.id].kind==='melee').length;
  if(m)out.push({key:'popolo',fx:[{s:'armor',v:m}],tier:0,count:1});}
 return out;}
function familyCounts(run){const c={};for(const w of run.weapons)for(const f of WEAPONS[w.id].fam)c[f]=(c[f]||0)+1;return c;}
function hasFlag(run,flag){return run.ch.fx.some(f=>f.flag===flag);}

// Ricalcola statistiche e ganci. Si chiama solo quando qualcosa cambia (run.dirty).
function computeStats(run,now){
 const s={},caps={},pers=[],trig={};
 for(const k of STAT_KEYS){s[k]=STATS[k].base||0;caps[k]=STATS[k].cap;}
 s.maxhp+=run.level; // +1 vita massima per livello
 for(const src of activeSources(run))for(const fx of src.fx){
  if(fx.s!=null)s[fx.s]+=byTier(fx.v,src.tier)*src.count;
  else if(fx.cap!=null)caps[fx.cap]=(caps[fx.cap]||0)+byTier(fx.v,src.tier)*src.count;
  else if(fx.per)pers.push({fx,count:src.count,tier:src.tier});
  else if(fx.on)(trig[fx.on]=trig[fx.on]||[]).push({fx,count:src.count,tier:src.tier,key:src.key});}
 for(const [k,v] of Object.entries(run.gains))s[k]+=v;
 for(const t of run.temp)if(t.until>now)s[t.s]+=t.v;
 const raw={...s};
 for(const p of pers){const fx=p.fx;s[fx.per.s]+=Math.floor(raw[fx.of]/fx.each)*byTier(fx.per.v,p.tier)*p.count;}
 for(const [k,c] of Object.entries(caps))if(c!=null&&s[k]>c)s[k]=c;
 s.maxhp=Math.max(1,Math.round(s.maxhp));
 run.stats=s;run.capsNow=caps;run.trig=trig;run.dirty=false;
 run.nextTempEnd=Math.min(Infinity,...run.temp.filter(t=>t.until>now).map(t=>t.until));
 return s;}
function stats(run,now=0){if(run.dirty||now>=run.nextTempEnd)computeStats(run,now);return run.stats;}

// Un evento è successo: esegue i ganci che lo ascoltano. ctx porta il mondo e il luogo (x,y, nemico...).
function emit(run,ev,ctx){const list=run.trig&&run.trig[ev];if(!list)return;
 for(const t of list){const fx=t.fx;
  for(let c=0;c<t.count;c++){
   if(fx.every){const k=t.key+':'+ev+':'+c;run.counters[k]=(run.counters[k]||0)+1;if(run.counters[k]%fx.every)continue;}
   if(fx.chance!=null&&!ctx.rng.chance(byTier(fx.chance,t.tier)))continue;
   doAction(run,fx.do,t.tier,ctx);}}}

// ctx.player è il giocatore a cui appartiene l'effetto (in multigiocatore ognuno ha i suoi).
function doAction(run,act,tier,ctx){const W=ctx.world,P=ctx.player;
 if(act.heal)healPlayer(W,P,byTier(act.heal,tier));
 // i fiorini degli oggetti vanno a chi possiede l'oggetto (chi l'ha pagato)
 if(act.gold){const amount=byTier(act.gold,tier);run.gold+=amount;if(P)W.events.push({k:'gold',x:P.x,y:P.y-30,v:amount});}
 if(act.gain){run.gains[act.gain.s]=(run.gains[act.gain.s]||0)+byTier(act.gain.v,tier);run.dirty=true;
  if(P)W.events.push({k:'text',x:P.x,y:P.y-40,t:'+'+act.gain.v+' '+STATS[act.gain.s].n,col:'#9be07a'});}
 if(act.temp){run.temp.push({s:act.temp.s,v:byTier(act.temp.v,tier),until:W.t+act.dur});run.dirty=true;}
 if(act.explode&&P){const x=ctx.x??P.x,y=ctx.y??P.y;explosion(W,P,x,y,byTier(act.explode.dmg,tier),byTier(act.explode.r,tier));}
 if(act.burn&&P&&ctx.enemy)igniteEnemy(W,P,ctx.enemy,act.burn,tier);
 if(act.repel&&P)repel(W,P,act.repel);
 if(act.summon&&P)for(let i=0;i<byTier(act.n??1,tier);i++)summon(W,P,act.summon);}

// ===================== testi automatici =====================
const ON_TXT={kill:'Quando uccidi un nemico',hit:'Quando colpisci',crit:'Con un colpo critico',hurt:'Quando vieni colpito',
 dodge:'Quando schivi',pickup:'Quando raccogli un fiorino',waveStart:'A inizio ondata',waveEnd:'A fine ondata'};
const SUMMON_TXT={balestra:'una Balestra da muro',trabucco:'un Trabucchetto'};
function fmtStat(k,v){const d=STATS[k];return (v>0?'+':'')+v+(d.pct?'%':'')+' '+d.n;}
function goodStat(k,v){return STATS[k].bad?v<0:v>0;}
function actionText(a,tier){const r=[];
 if(a.heal)r.push('curi '+byTier(a.heal,tier)+' PV');
 if(a.gold)r.push('ottieni '+byTier(a.gold,tier)+' fiorino');
 if(a.gain)r.push(fmtStat(a.gain.s,byTier(a.gain.v,tier))+' per sempre');
 if(a.temp)r.push(fmtStat(a.temp.s,byTier(a.temp.v,tier))+' per '+a.dur+' s');
 if(a.explode)r.push('esplosione da '+byTier(a.explode.dmg,tier)+' danni (+ Danno del fuoco)');
 if(a.burn)r.push('incendi il nemico ('+byTier(a.burn.dmg,tier)+' × '+a.burn.n+')');
 if(a.repel)r.push('respingi tutti i nemici vicini');
 if(a.summon){const n=byTier(a.n??1,tier);r.push('compare '+(n>1?n+' × ':'')+SUMMON_TXT[a.summon]);}
 return r.join(', ');}
// Restituisce un elenco di righe {t, good} per un elenco di effetti.
function describeFx(fxList,tier=0){const out=[];
 for(const fx of fxList||[]){
  if(fx.s!=null){const v=byTier(fx.v,tier);out.push({t:fmtStat(fx.s,v),good:goodStat(fx.s,v)});}
  else if(fx.per)out.push({t:fmtStat(fx.per.s,byTier(fx.per.v,tier))+' ogni '+fx.each+(STATS[fx.of].pct?'%':'')+' di '+STATS[fx.of].n,good:true});
  else if(fx.cap)out.push({t:'Tetto di '+STATS[fx.cap].n+' '+(fx.v>0?'+':'')+fx.v+'%',good:fx.v>0});
  else if(fx.flag)out.push({t:fx.t,good:true,flag:1});
  else if(fx.on){let pre=fx.on==='interval'?'Ogni '+fx.every+' secondi':ON_TXT[fx.on];
   if(fx.every&&fx.on!=='interval')pre=({kill:'Ogni '+fx.every+' nemici uccisi',hit:'Ogni '+fx.every+' colpi'}[fx.on]||pre);
   const ch=fx.chance!=null?Math.round(byTier(fx.chance,tier)*100)+'% di probabilità: ':'';
   out.push({t:pre+': '+ch+actionText(fx.do,tier),good:true});}}
 return out;}
