'use strict';
// Suoni sintetizzati al volo (nessun file audio). M per togliere o rimettere l'audio.
const AUDIO={ctx:null,on:true,last:{},vol:.22};
function audioCtx(){if(!AUDIO.ctx){try{AUDIO.ctx=new (window.AudioContext||window.webkitAudioContext)();}catch(e){AUDIO.on=false;}}return AUDIO.ctx;}
function tone(type,f0,f1,dur,vol,delay=0){const a=AUDIO.ctx,t=a.currentTime+delay,o=a.createOscillator(),gn=a.createGain();
 o.type=type;o.frequency.setValueAtTime(f0,t);o.frequency.exponentialRampToValueAtTime(Math.max(20,f1),t+dur);
 gn.gain.setValueAtTime(vol*AUDIO.vol,t);gn.gain.exponentialRampToValueAtTime(.0001,t+dur);o.connect(gn).connect(a.destination);o.start(t);o.stop(t+dur+.02);}
function noise(dur,vol,hp=800){const a=AUDIO.ctx,n=Math.floor(a.sampleRate*dur),b=a.createBuffer(1,n,a.sampleRate),d=b.getChannelData(0);
 for(let i=0;i<n;i++)d[i]=(Math.random()*2-1)*(1-i/n);const s=a.createBufferSource(),f=a.createBiquadFilter(),gn=a.createGain();
 s.buffer=b;f.type='highpass';f.frequency.value=hp;gn.gain.value=vol*AUDIO.vol;s.connect(f).connect(gn).connect(a.destination);s.start();}
const SFX={
 hit:()=>noise(.05,.35,1800),
 crit:()=>{noise(.06,.45,1200);tone('square',900,500,.08,.12);},
 coin:()=>{tone('triangle',1320,1760,.06,.18);},
 hurt:()=>{tone('sawtooth',220,90,.18,.3);noise(.12,.3,400);},
 shot:()=>{tone('triangle',520,220,.07,.16);noise(.04,.15,2500);},
 lob:()=>tone('sine',300,600,.15,.15),
 expl:()=>{noise(.3,.5,200);tone('sine',120,40,.3,.35);},
 death:()=>noise(.08,.18,900),
 wave:()=>{[523,659,784].forEach((f,i)=>tone('triangle',f,f,.18,.25,i*.09));},
 level:()=>{[392,523,659,784].forEach((f,i)=>tone('square',f,f,.1,.12,i*.07));},
 buy:()=>{tone('triangle',880,1320,.08,.2);tone('triangle',1320,1760,.08,.15,.06);},
 click:()=>tone('triangle',700,600,.04,.12),
 bell:()=>{tone('sine',440,438,1.2,.35);tone('sine',1100,1090,.8,.12);},
};
const SFX_GAP={hit:.035,coin:.03,death:.04,shot:.05,crit:.05};
function sfx(name){if(!AUDIO.on)return;const a=audioCtx();if(!a)return;if(a.state==='suspended')a.resume();
 const now=a.currentTime,gap=SFX_GAP[name]||0;if(gap&&now-(AUDIO.last[name]||0)<gap)return;AUDIO.last[name]=now;
 try{SFX[name]();}catch(e){}}
