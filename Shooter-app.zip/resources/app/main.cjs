'use strict';
// Finestra Electron di Montaperti Shooter. Ripresa dal client di Montaperti (desktop/main.cjs, client 1.1.1):
// stesso protocollo interno, stessa protezione dalle chiusure accidentali, nessun accesso alla rete.
const {app,BrowserWindow,Menu,ipcMain,protocol}=require('electron');
const fs=require('node:fs'),path=require('node:path');
const {ExitGuard,protectedKey}=require('./exit-guard.cjs');
const HOME='shooter://game/index.html';
protocol.registerSchemesAsPrivileged([{scheme:'shooter',privileges:{standard:true,secure:true,supportFetchAPI:true,corsEnabled:true}}]);
app.setName('Montaperti Shooter');
let win,guard,ready=false;
function reportStartup(status){
 const nonce=process.argv.find(a=>/^--shooter-ready=[a-f0-9]{32}$/.test(a))?.split('=')[1];
 if(nonce&&process.env.LOCALAPPDATA){const dir=path.join(process.env.LOCALAPPDATA,'MontapertiShooterClient','health');try{fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,nonce+'.ready'),status==='ready'?nonce:status);}catch(error){console.error('Verifica avvio:',error.message);}}
}
const first=app.requestSingleInstanceLock();
if(!first){reportStartup('busy');app.quit();}
else{
 app.on('second-instance',()=>{if(win&&!win.isDestroyed()){if(win.isMinimized())win.restore();win.show();win.focus();}});
 app.on('before-quit',e=>{if(win&&!win.isDestroyed()&&!guard.allowed){e.preventDefault();guard.request('quit');}});
 app.on('window-all-closed',()=>app.quit());
 app.whenReady().then(()=>{
  Menu.setApplicationMenu(null);
  const assets=JSON.parse(fs.readFileSync(path.join(__dirname,'assets.json'),'utf8'));
  protocol.handle('shooter',request=>{
   const url=new URL(request.url),asset=url.hostname==='game'&&assets[url.pathname];
   if(!asset||request.method!=='GET')return new Response('Not found',{status:404});
   return new Response(fs.readFileSync(path.join(__dirname,'game',asset.file)),{headers:{'Content-Type':asset.type,'Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self' https://0.peerjs.com wss://0.peerjs.com; media-src 'self' data: blob:; object-src 'none'; frame-src 'none'; base-uri 'none'; form-action 'none'",'X-Content-Type-Options':'nosniff'}});
  });
  win=new BrowserWindow({width:1360,height:850,minWidth:960,minHeight:640,show:false,backgroundColor:'#3b4a2c',title:'Montaperti Shooter',autoHideMenuBar:true,icon:path.join(__dirname,'shooter.ico'),
   webPreferences:{preload:path.join(__dirname,'preload.cjs'),nodeIntegration:false,contextIsolation:true,sandbox:true,webSecurity:true,backgroundThrottling:false,devTools:false}});
  guard=new ExitGuard(request=>{if(ready)win.webContents.send('client:exit-request',request);});
  const trusted=e=>e.sender===win.webContents&&e.senderFrame===win.webContents.mainFrame&&e.senderFrame.url===HOME;
  ipcMain.on('client:ready',e=>{if(!trusted(e))return;ready=true;
   // Il launcher firmato promuove una versione scaricata solo dopo che il gioco vero si è caricato.
   reportStartup('ready');
   if(guard.pending)win.webContents.send('client:exit-request',guard.pending);});
  ipcMain.on('client:menu',e=>{if(trusted(e))guard.request('menu');});
  ipcMain.on('client:cancel',(e,id)=>{if(trusted(e)&&Number.isSafeInteger(id))guard.cancel(id);});
  ipcMain.on('client:finish',(e,id)=>{if(!trusted(e)||!Number.isSafeInteger(id))return;const action=guard.finish(id);
   if(action==='quit')win.close();else if(action==='menu'){ready=false;win.webContents.reload();}});
  win.on('close',e=>{if(!guard.allowed){e.preventDefault();guard.request('quit');}});
  win.webContents.on('before-input-event',(e,input)=>{const action=protectedKey(input);if(!action)return;e.preventDefault();if(input.isAutoRepeat)return;
   if(action==='fullscreen')win.setFullScreen(!win.isFullScreen());else if(action!=='block')guard.request(action);});
  win.webContents.on('will-navigate',e=>e.preventDefault());
  win.webContents.on('will-redirect',e=>e.preventDefault());
  win.webContents.setWindowOpenHandler(()=>({action:'deny'}));
  win.webContents.session.setPermissionRequestHandler((_wc,_permission,callback)=>callback(false));
  win.webContents.session.setPermissionCheckHandler(()=>false);
  win.webContents.on('did-fail-load',(_e,code,description)=>{if(code!==-3)console.error('Caricamento client:',code,description);});
  win.webContents.on('render-process-gone',()=>{ready=false;guard.allowed=true;win.close();});
  win.once('ready-to-show',()=>win.show());
  win.loadURL(HOME);
 }).catch(error=>{console.error(error);app.exit(1);});
}
